import { REHYDRATE } from 'redux-persist';
import {LoginResponseObject} from '../../utility/models/login/LoginResponseObject'

export const setUser = (user: LoginResponseObject) => ({
  type: 'SET_USER',
  payload: user,
});

export const clearUser = () => ({
  type: 'CLEAR_USER',
});

export const rehydrateUser = (persistedUser: LoginResponseObject | null) => ({
  type: REHYDRATE,
  payload: { user: { user: persistedUser } },
});

export const updateUserDetails = (newDetails:LoginResponseObject | null) => ({
  type: 'UPDATE_USER_DETAILS',
  payload: newDetails,
});