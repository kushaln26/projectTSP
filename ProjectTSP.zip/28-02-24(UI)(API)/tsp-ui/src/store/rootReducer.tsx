import { combineReducers } from 'redux';
import userReducer from './userReducer/userReducer';
import userProfileReducer from './userProfileReducer/userProfileReducer';

const rootReducer = combineReducers({
  user: userReducer,
  userProfile:userProfileReducer
});

export default rootReducer;

export type RootState = ReturnType<typeof rootReducer>;