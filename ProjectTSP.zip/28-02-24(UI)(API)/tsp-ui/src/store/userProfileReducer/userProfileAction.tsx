
import { UserProfileDetails } from "../../utility/models/ViewProfile/viewProfileResponse";
import { UserProfilemodel } from "../../utility/models/userProfile/UserProfilemodel";

export const setUserProfile= (userProfile:UserProfileDetails)=>({
    type:"SET_USER_PROFILE",
    payload: userProfile,
});


