import { UserProfileDetails } from "../../utility/models/ViewProfile/viewProfileResponse";
import { UserProfilemodel } from "../../utility/models/userProfile/UserProfilemodel";

interface UserProfileState {
  userProfile: UserProfileDetails | null;
}

const initialState: UserProfileState = {
  userProfile: null,
};

const userProfileReducer = (state = initialState, action: any): UserProfileState => {
  switch (action.type) {
    case 'SET_USER_PROFILE':
      return {
        ...state,
        userProfile: action.payload,
      };
    default:
      return state;
  }
};

export default userProfileReducer;
