export interface ArrayOfUserResponse{
    menteeRequests:menteeResponse[]
}

export interface menteeResponse {
    name: string;
    emailId:string;
   
}