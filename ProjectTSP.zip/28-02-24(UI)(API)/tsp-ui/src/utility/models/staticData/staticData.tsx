export interface StaticData{
    userGroups:Array<{ label: string | number; value: string }>
    bussinessUnits:Array<{ label: string | number; value: string }>;
   
}

export interface UpdateProfileStaticData
{
    technicalskills:Array<{ label: string; value: string }>;
    domains:Array<{ label: string; value: string }>;
    skillcategories:Array<{label:number |string; value :string}>
}

export interface SkillCategory
{
    skillCategories:Array<{label:number |string; value :string}>
}