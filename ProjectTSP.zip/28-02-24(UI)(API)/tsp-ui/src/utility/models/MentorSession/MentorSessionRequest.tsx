export interface MentorSessionRequest {
    localStartDate:string ;
    localEndDate: string ;
    businessUnit: string;
}