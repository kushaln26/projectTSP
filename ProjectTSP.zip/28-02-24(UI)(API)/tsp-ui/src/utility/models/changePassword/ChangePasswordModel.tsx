export interface ChangePasswordModel {
    emailId:string |  undefined;
    newPassword: string;
    confirmPassword: string;
}
  