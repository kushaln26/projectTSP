export interface ResetResponseObject {
  status:string,
  code:number,
  message:string,
  payload: string
}

export interface Payload {
  message:string
}




