export interface ChangePassword {
    emailId:string |  undefined;
    newPassword: string;
    confirmPassword: string;
}
  