export interface PaginationResponse{
    name:string, 
    emailId:string, 
    userGroup:string
}