    export interface RegisterUser {
        firstName: string, 
        lastName:string, 
        emailId: string, 
        empId:number, 
        userGroup: string, 
        businessUnit: string, 
        createdBy: string|undefined
    }


    export interface RegisterUserConstructedForBackend {
        name: string,
        emailId: string | undefined,
        userGroup: userGroup,
        departmentUnit: departmentUnit,
        createdBy: string | undefined
    }

    export interface departmentUnit {
        buName: string
    }

    export interface userGroup {
        ugname: string
        active:boolean
    }
