export interface RegisterResponse{
    message:string
}