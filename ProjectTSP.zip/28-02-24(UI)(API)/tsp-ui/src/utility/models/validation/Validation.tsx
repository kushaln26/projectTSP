export interface Validation{
    isValid:boolean,
    errorMessage:string,
    inputFieldName:string
}