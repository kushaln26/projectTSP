export interface LoginUser{
    emailId:string,
    password:string,
}