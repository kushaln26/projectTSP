export interface LoginResponseObject {
  businessUnit:string
  createdBy:string
  emailId:string
  empId:number
  firstName:string
  lastName:string
  passwordReset:boolean
  status:boolean
  userGroup:string
  createdDateTime:string
}

export interface UserGroup {
  ugname: string;
  active: boolean
}

export interface DepartmentUnit {
  buName: string;
}

export interface userProfile {
  Location: string,
  professionalSummary: string,
  SkillCategory: SkillCategory;
  technicalSkill: string[],
  photo: File | null
}

export interface SkillCategory {
  categoryName: string
}


