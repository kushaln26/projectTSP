export interface DeleteUser {
    userMailId: string;
    exitDate: string;
}