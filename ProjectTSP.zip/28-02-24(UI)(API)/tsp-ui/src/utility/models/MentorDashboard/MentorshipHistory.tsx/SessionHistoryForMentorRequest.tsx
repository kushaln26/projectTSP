import { boolean } from "yup";

export interface SessionHistoryOfMentorRequest {
    localStartDate:string ;
    localEndDate: string ;
    mailId: string | undefined;
}

export interface SessionHistoryOfMentorResponse
{
  sessionId: 1,
  mentorEmailId: string,
  menteeEmailId: string,
  sessionTopic: string,
  fromDate: string,
  toDate: string,
  managerApproval: boolean,
  mentorApproval: boolean,
  managerComments: string,
  requestCurrentlyWith: string,
  mentorComments: string,
  sessionStatus: string,
  requestStatus: string,
  mentorshipStatus: string,
  mentorName: string,
  menteeName: string,
  updatedDate: string,
  availableDate_1: string,
  availableDate_2: string
}

export interface ArrayOfSessionHistoryOfMentorResponse
{
  mentorshipHistoryRequests:SessionHistoryOfMentorResponse[]
}

export interface SessionRequestsOfMentorResponse
{
      sessionId: number,
      mentorEmailId: string,
      menteeEmailId: string,
      sessionTopic: string,
      fromDate: string,
      toDate: string,
      managerApproval: boolean,
      mentorApproval: boolean,
      managerComments: string,
      requestCurrentlyWith: string,
      mentorComments: string,
      sessionStatus: string,
      requestStatus: string,
      mentorshipStatus: string,
      mentorName: string,
      menteeName: string,
      updatedDate: string
}

export interface ArrayOfSessionRequestsOfMentorResponse{
    mentorshipRequests:SessionRequestsOfMentorResponse[]
}


export interface SessionHistoryOfMentorTableData 
{
  sessionId:number
  mentorShipSession:string,
  topic:string,
  menteeName:string,
  date:string,
  requestStatus:string,
  sessionStatus:string
}

export interface ArrayOfSessionHistoryOfMentorTableData
{
  mentorshipHistoryTableDataValues:SessionHistoryOfMentorTableData[]
}

