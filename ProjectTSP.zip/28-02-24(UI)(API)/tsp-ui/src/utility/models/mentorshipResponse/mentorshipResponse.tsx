export interface ArrayOfMentorshipResponse{
    mentorshipRequests:mentorshipResponse[]
}

export interface mentorshipResponse {
    sessionId:number;
    name: string;
    sessionTopic: string;
    menteeMailId:string;
    mentorApproval:boolean;
}