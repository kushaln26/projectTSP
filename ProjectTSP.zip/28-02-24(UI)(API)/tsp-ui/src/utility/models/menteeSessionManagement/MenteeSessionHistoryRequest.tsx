export interface MenteeSessionHistoryRequest {
    localStartDate: string;
    localEndDate: string;
    mailId: string | undefined;
}

export interface SessionCompletionDetails {
    sessionId:number
    totalSessionCovered: number
    sessionDuration: number
    sessionTopic: string
    startDate: string
}

export interface MenteeSessionHistoryResponse {
    sessionId: number,
    mentorEmailId: string,
    menteeEmailId: string,
    sessionTopic: string,
    fromDate: string,
    toDate: string,
    managerApproval: boolean,
    mentorApproval: boolean,
    managerComments: string,
    requestCurrentlyWith: string,
    mentorComments: string,
    sessionStatus: string,
    requestStatus: string,
    mentorshipStatus: string,
    mentorName: string,
    menteeName: string,
    updatedDate: string,
    availableDate_1: string,
    availableDate_2: string,
    scheduledDate:string
  }

export interface datesToChooseProps {
    date_1:string;
    date_2:string;
    sessionId:number;
  }

export interface teamsBlockRequestBody
{
  sessionId:number;
  sessionScheduledDate:string;
}
        

export interface ArrayOfMenteeSessionHistoryResponse {
    mentorshipHistoryRequests: MenteeSessionHistoryResponse[]
}
