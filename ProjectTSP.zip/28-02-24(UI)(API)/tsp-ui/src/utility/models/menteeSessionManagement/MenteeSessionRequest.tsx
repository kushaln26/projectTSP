export interface SendMentorRequest{
    mentorEmailId:string,
    menteeEmailId:string,
    sessionTopic:string
 }