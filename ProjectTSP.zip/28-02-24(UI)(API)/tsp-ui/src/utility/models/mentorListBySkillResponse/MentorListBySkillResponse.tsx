export interface MentorListBySkillResponse {
    departmentUnit: string,
    emailId: string,
    location: string,
    name: string,
    professionalSummary: string,
    skillCategory: string,
    technicalSkills: string[]

}

export interface MentorList {

    emailId: string,
    professionalSummary: string,
    designation: string,
    totalExperience: number,
    profileStatus: boolean,
    skillCategory: string,
    managerMailId: string,
    technicalSkillList: string[],
    userProjectExperienceList:
    {
        projectName: string,
        role: string,
        roleDescription: string,
        duration: number,
        toolsAndFramework: string,
        client: string
    }[],
    domainList: string[]

}

