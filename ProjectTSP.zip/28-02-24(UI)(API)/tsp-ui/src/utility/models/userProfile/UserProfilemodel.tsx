export interface UserProfilemodel{
    name:string,
    emailId:string,
    departmentUnit:string,
    location:string,
    professionalSummary:string,
    skillCategory:string,
    technicalSkills:string[],
}

export interface UserProfilemodelwithPhoto{
    name:string,
    emailId:string,
    departmentUnit:string,
    location:string,
    professionalSummary:string,
    skillCategory:string,
    technicalSkills:string[],
    photo:File | null
}

export interface UserProfileDetailmodel
{
    name:string,
    emailId:string,
    departmentUnit:string,
    location:string,
    professionalSummary:string,
    skillCategory:string,
    technicalSkill:string[],
    photo:Blob | null,
    EmployeeId:string,
    Manager:string,
    Experience:number,
    Designation:string,
    JoiningDate:Date,
    Projects:Project[]
}

export interface Project 
{
    Project:string,
    Description:string,
    Role:string,
    Duration:number, 
    ToolsAndFramework:string[],
    Client:string 
}

export interface UserProfileStatus {
    emailId: String|undefined,
    status:String
  }