export interface UserProfilPhoto{
    emailId: String,
    photo: Blob | null
}