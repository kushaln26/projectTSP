export interface usersReport {
    empId: number;
    emailId: string;
    firstName: string;
    lastName: string;
    userGroup: string;
    businessUnit: string;
    status: boolean;
    passwordReset: boolean;
    createdBy: string;
    exitDate:string,
    createdDateTime: Date,
    managerName:string, 
    professionalSummary: string;
    designation: string;
    totalExperience: number;
    profileStatus: boolean;
    skillCategory: string;
    managerMailId: string;
    technicalSkillList: string[];
    userProjectExperienceList: userProjectExperience[];
    domainList: string[];
  }


  export interface userProjectExperience{
    id:number
    projectName: string,
    role: string,
    roleDescription: string,
    duration: number,
    toolsAndFramework: string,
    client: string
}


