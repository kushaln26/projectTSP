export interface MasterDataResponse{
    businessUnits:string[],
    userGroups:string[],
    technicalskills:string[],
    domains:string[],
    skillcategories:string[]

}