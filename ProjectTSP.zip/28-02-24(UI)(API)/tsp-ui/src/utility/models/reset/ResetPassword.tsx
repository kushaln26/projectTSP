export interface ResetPassword {
    emailId:string |  undefined;
    newPassword: string;
    confirmPassword: string;
}
  