export interface ArchiveRequest {
    localStartDate: string;
    localEndDate: string;
    departmentUnit: string;
}