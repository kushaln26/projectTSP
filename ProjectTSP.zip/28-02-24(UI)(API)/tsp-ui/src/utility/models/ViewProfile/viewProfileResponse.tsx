import { number } from "yup";

export interface UserProfileDetails{
    firstName:string,
    lastName:string,
    empId:number,
    emailId:string,
    userGroup:string,
    businessUnit:string,
    profileStatus:boolean,
    location:string,
    professionalSummary:string,
    skillCategory:string,
    technicalSkill:string[],
    EmployeeId:string,
    Manager:string,
    totalExperience:number,
    Designation:string,
    Projects:UserProjectExperience[]  
}

export interface ViewProfileResponseModal
{
    emailId:string;
    empId:number;
    firstName:string;
    lastName:string;
    managerName:string;
    userGroup:string;
    businessUnit:string|undefined;
    professionalSummary:string;
    designation:string;
    totalExperience:number;
    profileStatus:boolean;
    skillCategory:string;
    managerMailId:string;
    technicalSkillList:string[];
    userProjectExperienceList:UserProjectExperience[];
    domainList:string[];
}

  export interface UpdateProfileResponseModal{
    emailId: string ,
    empId: number,
    firstName: string,
    lastName: string,
    managerName: string | null,
    userGroup: string,
    businessUnit:string|undefined,
    professionalSummary: string | null,
    designation: string | null,
    totalExperience: number | null,
    profileStatus: boolean | null,
    skillCategory: string | null,
    managerMailId: string | null,
    technicalSkillList: string[] | null,
    userProjectExperienceList: UserProjectExperience[] | null,
    domainList: string[] | null
  }



export interface UserProjectExperience
{
    id:number;
    projectName:string;
    role:string;
    roleDescription:string;
    duration:number;
    toolsAndFramework:string;
    client:string;
}



export interface ArrayOfUserProjectExperienceDto
{
    projectsArray:UserProjectExperience[]
}

// export interface UserModel{
//     emailId: string,
//     empId: number,
//     firstName: string,
//     lastName: string,
//     managerName: string,
//     userGroup: string,
//     professionalSummary: string,
//     designation: string,
//     totalExperience: number,
//     profileStatus: boolean,
//     skillCategory: string,
//     managerMailId: string,
//     technicalSkillList: string[],
//     userProjectExperienceList: UserProjectExperience[],
//     domainList: string[]
//   }

  export interface UserModel{
    emailId: string ,
    empId: number,
    firstName: string,
    lastName: string,
    managerName: string | null,
    userGroup: string,
    professionalSummary: string | null,
    designation: string | null,
    totalExperience: number | null,
    profileStatus: boolean | null,
    skillCategory: string | null,
    managerMailId: string | null,
    technicalSkillList: string[] | null,
    userProjectExperienceList: UserProjectExperience[] | null,
    domainList: string[] | null
  }
  