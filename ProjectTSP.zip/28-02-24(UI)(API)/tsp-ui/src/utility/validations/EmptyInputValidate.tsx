export const EmptyInputValidate = (fielData: string | number): string | null => {
    if (!fielData) {
        return "Field Can not be empty";
    }
    return null;
}

export const IsContainsOnlyNumbers = (fielData: string ): string | null => {
    if( !(/^[0-9]*$/.test(fielData))){
        return "Enter only numbers"
    }
    return null;
}