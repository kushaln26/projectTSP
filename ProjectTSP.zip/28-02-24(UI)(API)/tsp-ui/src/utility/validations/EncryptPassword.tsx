export const EncryptPassword = (value:string):string=>{
    return btoa(value);
}

