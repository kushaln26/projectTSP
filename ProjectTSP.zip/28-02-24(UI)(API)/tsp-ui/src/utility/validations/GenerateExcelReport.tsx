

export function GenerateExcelReport(response:any,name:string){

    const blob = new Blob([response.data], { type: response.headers['content-type'] });
 
      const url = window.URL.createObjectURL(blob);
 
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${name}+.xlsx`);
      document.body.appendChild(link);
      link.click();
 
      URL.revokeObjectURL(url);
}
