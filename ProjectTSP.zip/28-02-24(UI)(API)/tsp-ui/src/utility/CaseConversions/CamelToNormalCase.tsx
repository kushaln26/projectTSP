const camelToNormalCase = (camelCaseString:string) =>{
    // Use regex to find all capital letters and add a space before them
    return camelCaseString.replace(/([A-Z])/g, ' $1')
                          // Capitalize the first letter and return
                          .replace(/^./, function(str){ return str.toUpperCase(); });
}

export default camelToNormalCase;