export const ConvertToCamelCase = (input: string): string => 
{
    if (input.includes('_')) {
      const words = input.toLowerCase().split('_');
      const camelCaseWords = words.map(word => word.charAt(0).toUpperCase() + word.slice(1));
      return camelCaseWords.join(' ');
    } else {
      return input.charAt(0).toUpperCase() + input.slice(1).toLowerCase();
    }
  }


