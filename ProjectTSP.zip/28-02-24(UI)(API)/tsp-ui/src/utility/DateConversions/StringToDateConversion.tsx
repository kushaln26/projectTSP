const convertStringToDate = (str:string) => {
    
    const dateObject = new Date(str);
    return dateObject;
  };

  export default convertStringToDate;