
import camelToNormalCase from '../CaseConversions/CamelToNormalCase';
import * as XLSX from 'xlsx';
import { usersReport, userProjectExperience } from '../models/usersReport/usersReport';

export const ExcelReportGeneration = (dataArrayType: usersReport[], fileName: string) => {
    const workBook: XLSX.WorkBook = XLSX.utils.book_new();

    const headers: string[] = Object.keys(dataArrayType[0]);

    const normalizedHeaders: string[] = headers.map(header => camelToNormalCase(header));

    const transformedData: any[] = dataArrayType.map((data: any) => {
        const transformedItem: any = {};
        for (const key in data) {
            const normalizedKey = camelToNormalCase(key);
            switch (key) {
                case 'profileStatus':
                    transformedItem[normalizedKey] = data[key] ? 'Available' : 'Unavailable';
                    break;
                case 'passwordReset':
                    transformedItem[normalizedKey] = data[key] ? 'Changed' : 'Unchanged';
                    break;
                case 'status':
                    transformedItem[normalizedKey] = data[key] ? 'Active' : 'Inactive';
                    break;
                default:
                    transformedItem[camelToNormalCase(key)] = Array.isArray(data[key]) ? (data[key] as Array<any>).join(', ') : data[key];
                
                }
                }
        return transformedItem;
    });
    
    const userDataSheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(transformedData, { header: normalizedHeaders });

    XLSX.utils.book_append_sheet(workBook, userDataSheet, "Users Data");

    const projectExperienceData: any[] = [];

    dataArrayType.forEach(user => {
        if (user.userProjectExperienceList !== null) {
            user.userProjectExperienceList.forEach((project: userProjectExperience) => {
                projectExperienceData.push([
                    user.emailId,
                    project.id,
                    project.projectName,
                    project.role,
                    project.roleDescription,
                    project.duration,
                    project.toolsAndFramework,
                    project.client
                ]);
            });
        }
    });

    const projectExperienceHeaders: string[] = ['User Email', 'ID', 'Project Name', 'Role', 'Role Description', 'Duration', 'Tools and Framework', 'Client'];
    projectExperienceData.unshift(projectExperienceHeaders);

    const projectExperienceSheet: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(projectExperienceData);

    XLSX.utils.book_append_sheet(workBook, projectExperienceSheet, "Project Experience");

    XLSX.writeFile(workBook, `${fileName}.xlsx`);
};
