import { BASE_URL } from './baseUrl';
import { RegisterUser } from '../utility/models/register/RegisterUser';
import { LoginUser } from '../utility/models/login/LoginUser';
import axios, { AxiosResponse } from 'axios';
import { ChangePasswordModel } from '../utility/models/changePassword/ChangePasswordModel';
import { RegisterUserConstructedForBackend } from '../utility/models/register/RegisterUser';
import { GlobalResponse } from '../utility/models/GlobalResponse';
import EndPoints from '../constants/RegisterServiceEndPoints';
import RegisterServiceEndPoints from '../constants/RegisterServiceEndPoints';
import { DeleteUser } from '../utility/models/deleteUsersRequest/deleteUsersRequest';
import userServiceEndpoints from '../constants/userServiceEndPoints'
import jwtToken from '../jwt/jwtToken';



const userApi = {

  registerUser: (registerUser: RegisterUser) => {
    return jwtToken.post(EndPoints.REGISTER_USER_BY_ADMIN, registerUser)
  },

  loginUser: (loginUser: LoginUser) => {
    const encryptedPassword = btoa(loginUser.password);
    const user = { ...loginUser, password: encryptedPassword }
      ;

    return jwtToken.post(EndPoints.LOGIN_USER, user)
  },

  changePassword: (changePassword: ChangePasswordModel) => {
    const encodedPassword = btoa(changePassword.newPassword);
    const encodedConformPassword = btoa(changePassword.confirmPassword);
    const newPasswordDetails = { ...changePassword, newPassword: encodedPassword, confirmPassword: encodedConformPassword }
    return jwtToken.post(EndPoints.CHANGEPASSWORD_USER, newPasswordDetails)
  },

  forgotPassword: (emailId: string) => {
    return jwtToken.get(EndPoints.FORGOTPASSWORD_USER + "/" + emailId);
  },

  deleteUser: (emailId: String) => {
    return jwtToken.delete(EndPoints.DELETE_USER + "/" + emailId)
  },

  fetchUserByMailId: (emailId: String) => {
    return jwtToken.get(RegisterServiceEndPoints.FETCH_USER_BY_EMAILID + emailId);
  },

  deleteUsers: (DeleteUsersdata: DeleteUser[]) => {
    return jwtToken.delete(EndPoints.DELETE_USERS, { data: DeleteUsersdata })
  },

  managerTagging: (formData: any) => {
    return jwtToken.post(userServiceEndpoints.MANAGER_TAGGING, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      responseType: 'blob',
    });
  },

  getUserReportActiveUnavailable:()=>{
    return jwtToken.get(userServiceEndpoints.FETCH_ACTIVE_UNAVAILABLE_USERS_COUNTS)
  },

  getAllActiveUsers:()=>{
    return jwtToken.get(RegisterServiceEndPoints.FETCH_ALL_USERS)
  }
}

export default userApi