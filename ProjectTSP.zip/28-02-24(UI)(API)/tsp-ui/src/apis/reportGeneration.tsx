import axios from "axios"
import ReportServiceEndPoints from "../constants/ReportServiceEndPoints"
import { MentorSessionRequest } from "../utility/models/MentorSession/MentorSessionRequest"
import { ArchiveRequest } from "../utility/models/archive/ArchiveRequest"
import jwtToken from "../jwt/jwtToken"


export const reportGeneration = {
    getUserReport: (getDataRange: ArchiveRequest | null) => {
        return jwtToken.post(ReportServiceEndPoints.POST_REQ_GET_ALL_USER_REPORT,getDataRange)
    }
}