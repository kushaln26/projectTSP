import axios from "axios"
import MentorshipServiceEndpoints from "../constants/MentorshipServiceEndpoints"
import { MenteeSessionHistoryRequest, SessionCompletionDetails, teamsBlockRequestBody } from "../utility/models/menteeSessionManagement/MenteeSessionHistoryRequest"
import jwtToken from "../jwt/jwtToken"


export const MentorShipSessionManagement = {

    getSessionRecordByEmailId: (sessionHistoryFromTo: MenteeSessionHistoryRequest) => {
        return jwtToken.get(MentorshipServiceEndpoints.GETREQ_FETCH_SESSION_RECORD_HISTORY + sessionHistoryFromTo.mailId, {
            params: {
                fromDate: sessionHistoryFromTo.localStartDate,
                toDate: sessionHistoryFromTo.localEndDate
            }
        })
    },


    menteeSessionStatusConclusion: (menteeSessionInfo: SessionCompletionDetails) => {
        return jwtToken.post(MentorshipServiceEndpoints.POSTREQ_CAPTURE_SESSION, menteeSessionInfo )
    },


    blockTeamsCalender:(teamsBlockRequest:teamsBlockRequestBody) =>
    {
        return jwtToken.post(MentorshipServiceEndpoints.POSTREQ_BLOCK_CALENDAR,teamsBlockRequest);
    }
    ,
    getSessionRecordForManagerByEmailId:(sessionHistoryFromTo: MenteeSessionHistoryRequest) => {
        return jwtToken.get(MentorshipServiceEndpoints.GETREQ_FETCH_SESSION_RECORD_FOR_MANAGER_HISTORY + sessionHistoryFromTo.mailId, {
            params: {
                fromDate: sessionHistoryFromTo.localStartDate,
                toDate: sessionHistoryFromTo.localEndDate
            }
        })
    },
    
}