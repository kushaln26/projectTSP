import axios from "axios"
import MediaServiceEndpoints from '../constants/MediaServiceEndpoints';
import jwtToken from "../jwt/jwtToken";
const MediaServiceApi=
{
    getProfilePhoto:(emailId:string|undefined)=>
    {
        return jwtToken.get(MediaServiceEndpoints.GETREQ_PROFILE_PHOTO_BY_EMIALID + emailId, { responseType: 'blob' })
    },

    updateProfilePhoto: (emailId: string | undefined, photoFileData: FormData) => {
        return jwtToken.put(MediaServiceEndpoints.POSTREQ_UPLOAD_PROFILE_PHOTO_BY_EMAIL_ID + emailId, 
            photoFileData, {
            headers: {
                'Content-Type': 'multipart/form-data',
                'Accept': 'application/json'
            }
        });
    }
      
}

export default MediaServiceApi;