import axios from "axios"
import { BASE_URL } from "./baseUrl";
import EndPoints from '../constants/RegisterServiceEndPoints';
import ProfileEndPoints from '../constants/userServiceEndPoints';
import jwtToken from "../jwt/jwtToken";

export const staticDataFetch = {
    url: BASE_URL,
    getUserGroups: () => {
        return jwtToken.get(EndPoints.FETCH_ALL_USER_GROUPS);
    },
    getBUGroups: () => {
        return jwtToken.get(EndPoints.FETCH_ALL_BUSINESS_UNITS);
    },

    getMaterData: () => {
        return jwtToken.get(EndPoints.FETCH_ALL_MASTERDATA)
    },

    getSkillCategories: () => {
        return jwtToken.get(staticDataFetch.url + '/getAllSkillCategory');
    },

    getAllProfileMasterData:()=>
    {
        return jwtToken.get(ProfileEndPoints.FETCH_ALL_PROFILE_STATIC_DATA)
    }
}