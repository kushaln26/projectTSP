import axios from "axios";
import { UserProfileStatus, UserProfilemodel } from "../utility/models/userProfile/UserProfilemodel";
import { BASE_URL } from "./baseUrl";
import { UserProfilPhoto } from "../utility/models/userProfile/UserProfilePhoto";
import UserServiceEndPoints from "../constants/userServiceEndPoints";
import RegisterServiceEndPoints from "../constants/RegisterServiceEndPoints";
import { UserModel, ViewProfileResponseModal } from "../utility/models/ViewProfile/viewProfileResponse";
import jwtToken from "../jwt/jwtToken";

const userProfileApi = {
  url: BASE_URL + "/admin/users/profile/",

  userProfileUpdate: (userProfile: UserModel | null) => {
    return jwtToken.put(UserServiceEndPoints.UPDATE_PROFILE_BY_EMAILID, userProfile)
  },

  userProfilePhoto:(userProfilePhoto:UserProfilPhoto)=>{
    return jwtToken.post(userProfileApi.url+"/update/profilePhoto",userProfilePhoto)
  },

  userStatusSet:(profileStatus:UserProfileStatus)=>
  {
    return jwtToken.put(userProfileApi.url+"update/profileStatus",profileStatus);
  },
    
  fetchUserProfileByMailId:(emailId:String | undefined)=>{
    
    return jwtToken.get(UserServiceEndPoints.FETCH_USER_BY_EMAILID+emailId);
  },
}
export default userProfileApi;

