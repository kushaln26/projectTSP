import axios from "axios";
import { BASE_URL } from "./baseUrl";
import { MenteeSessionHistoryRequest } from "../utility/models/menteeSessionManagement/MenteeSessionHistoryRequest";
import { SendMentorRequest } from "../utility/models/menteeSessionManagement/MenteeSessionRequest";
import userServiceEndpoints from "../constants/userServiceEndPoints";
import { POSTREQ_RAISE_REQUEST_FOR_MENTORSHIP } from "../constants/MentorshipServiceEndpoints";
import jwtToken from "../jwt/jwtToken";

export const MenteeSessionManagement = {
    url: BASE_URL+'/mentee',

    getMenteeSession: (sessionDateRange: MenteeSessionHistoryRequest) => {
        const fromDate = sessionDateRange.localStartDate;
        const toDate = sessionDateRange.localEndDate;
        return jwtToken.get(MenteeSessionManagement.url + "/session/details/"+sessionDateRange.mailId, { params: { fromDate: fromDate, toDate: toDate } })
    },

    sendMentorRequest: async (sendMentorRequest: SendMentorRequest) => {
        return jwtToken.post(POSTREQ_RAISE_REQUEST_FOR_MENTORSHIP, sendMentorRequest);
    },

    fetchMentorsBySkill: (skills: string | undefined) => {
        return jwtToken.get(userServiceEndpoints.SEARCH_MENTOR_BY_TECHNICAL_SKILL + skills);
    },

}