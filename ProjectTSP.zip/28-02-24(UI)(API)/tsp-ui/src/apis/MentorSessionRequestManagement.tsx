import axios from "axios"
import { BASE_URL } from "./baseUrl";
import { ApprovalPostRequest } from "../pages/mentor/MentorShipRequests/MentorShipRequests";
import MentorshipServiceEndpoints from '../constants/MentorshipServiceEndpoints';
import { SessionHistoryOfMentorRequest } from "../utility/models/MentorDashboard/MentorshipHistory.tsx/SessionHistoryForMentorRequest";
import jwtToken from "../jwt/jwtToken";

export const MentorSessionRequestManagement={
    
    getMentorSessionRequest:(emailId:string|undefined)=>{
        return jwtToken.get(MentorshipServiceEndpoints.GETREQ_GET_MENTORSHIP_REQUESTS+emailId);
    },

    raiseRequestForMentorshipSession:()=>
    {
        return jwtToken.post(MentorshipServiceEndpoints.POSTREQ_RAISE_REQUEST_FOR_MENTORSHIP);
    },

    fetchSessionRecordHistory:(SessionHistoryRequesyData:SessionHistoryOfMentorRequest)=>
    {
        const fromDate = SessionHistoryRequesyData.localStartDate;
        const toDate = SessionHistoryRequesyData.localEndDate;
        return jwtToken.get(MentorshipServiceEndpoints.GETREQ_FETCH_SESSION_RECORD_HISTORY+SessionHistoryRequesyData.mailId, 
            { params: { fromDate: fromDate, toDate: toDate } });
    },

   
    mentorShipApproval:(approvalData:ApprovalPostRequest)=>
    {
        return jwtToken.post(MentorshipServiceEndpoints.POSTREQ_MENTORSHIP_APPROVAL,approvalData);
    }

}