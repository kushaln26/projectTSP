import { BASE_URL } from "../apis/baseUrl";

const mentorShipDetailsApi = BASE_URL+'/mentorship/service'

export const POSTREQ_RAISE_REQUEST_FOR_MENTORSHIP = mentorShipDetailsApi + "/request/for/mentor-session";
export const GETREQ_FETCH_SESSION_RECORD_HISTORY = mentorShipDetailsApi + "/session/details/";
export const GETREQ_GET_MENTORSHIP_REQUESTS = mentorShipDetailsApi + "/mentorShip/requests/";
export const POSTREQ_CAPTURE_SESSION = mentorShipDetailsApi + "/capture/session/conclusion";
export const POSTREQ_MENTORSHIP_APPROVAL = mentorShipDetailsApi + "/mentorship/approval";
export const POSTREQ_BLOCK_CALENDAR = mentorShipDetailsApi + "/scheduled/date";
export const GETREQ_FETCH_SESSION_RECORD_FOR_MANAGER_HISTORY = mentorShipDetailsApi+"/session/manager/"

export default {
    POSTREQ_RAISE_REQUEST_FOR_MENTORSHIP,
    GETREQ_FETCH_SESSION_RECORD_HISTORY,
    GETREQ_FETCH_SESSION_RECORD_FOR_MANAGER_HISTORY,
    GETREQ_GET_MENTORSHIP_REQUESTS,
    POSTREQ_CAPTURE_SESSION,
    POSTREQ_MENTORSHIP_APPROVAL,
    POSTREQ_BLOCK_CALENDAR
}







