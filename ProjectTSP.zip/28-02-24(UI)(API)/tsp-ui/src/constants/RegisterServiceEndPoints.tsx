import { BASE_URL } from "../apis/baseUrl"

const UserDetailsUrl = BASE_URL + "/userDetails"

const REGISTER_USER_BY_ADMIN = UserDetailsUrl + "/register"
const LOGIN_USER = UserDetailsUrl + "/login"
const FORGOTPASSWORD_USER = UserDetailsUrl + "/forgotPassword"
const CHANGEPASSWORD_USER = UserDetailsUrl + "/reset"
const DELETE_USER = UserDetailsUrl + "/deleteUserDetails"
const FETCH_USER_BY_EMAILID = UserDetailsUrl + "/fetchUserByEmailId/"
const FETCH_USER_STATUS_BY_EMAILID = UserDetailsUrl + "/fetch/status"
const FETCH_ALL_USER_GROUPS = UserDetailsUrl + "/fetch/all/users/groups"
const FETCH_ALL_BUSINESS_UNITS = UserDetailsUrl + "/fetch/all/business/units"
const FETCH_ALL_MASTERDATA = UserDetailsUrl + "/fetch/all/masterdata"
const DELETE_USERS = UserDetailsUrl + "/delete/Users"
const FETCH_ALL_USERS = UserDetailsUrl + "/fetch/all/users"


export default {
    REGISTER_USER_BY_ADMIN, LOGIN_USER, FORGOTPASSWORD_USER, CHANGEPASSWORD_USER,
    DELETE_USER, FETCH_USER_BY_EMAILID, FETCH_USER_STATUS_BY_EMAILID, FETCH_ALL_USER_GROUPS,
    FETCH_ALL_BUSINESS_UNITS, FETCH_ALL_USERS,FETCH_ALL_MASTERDATA,DELETE_USERS
}