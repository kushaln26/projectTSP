import { BASE_URL } from "../apis/baseUrl";

const medaiServiceUrl = BASE_URL+'/media'

 const GETREQ_PROFILE_PHOTO_BY_EMIALID=medaiServiceUrl+'/getProfilePhoto/';
 const POSTREQ_UPLOAD_PROFILE_PHOTO_BY_EMAIL_ID=  medaiServiceUrl+'/upload/profilePhoto/';
 
 export default 
 {
    GETREQ_PROFILE_PHOTO_BY_EMIALID,
    POSTREQ_UPLOAD_PROFILE_PHOTO_BY_EMAIL_ID

 }