const VIEWING_FEEDBACK="https://forms.office.com/Pages/DesignPageV2.aspx?subpage=design&id=RbyHGSnm00eTJrUwDdFeNBlzusXkZpFPpiYR8I_-6ABUQTk4WTk4U0JZWjFLVE80VVZXSEFHQlQzTi4u&analysis=true";
const GIVING_FEEDBACK="https://forms.office.com/pages/responsepage.aspx?id=RbyHGSnm00eTJrUwDdFeNBlzusXkZpFPpiYR8I_-6ABUQTk4WTk4U0JZWjFLVE80VVZXSEFHQlQzTi4u";

export default {VIEWING_FEEDBACK, GIVING_FEEDBACK}