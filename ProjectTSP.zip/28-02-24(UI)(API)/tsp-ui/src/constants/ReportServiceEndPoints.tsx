
import { BASE_URL } from "../apis/baseUrl"

const POST_REQ_GET_ALL_USER_REPORT = BASE_URL+"/report/fetchAllUsers"

export default {POST_REQ_GET_ALL_USER_REPORT}