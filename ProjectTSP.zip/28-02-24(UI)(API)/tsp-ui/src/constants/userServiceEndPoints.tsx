import { BASE_URL } from "../apis/baseUrl"

const UserDetailsUrl = BASE_URL + "/profile"

const UPDATE_PROFILE_BY_EMAILID = UserDetailsUrl + "/update"
const UPDATE_PROFILE_STATUS_BY_EMAILID = UserDetailsUrl + "/update/profileStatus"
const MANAGER_TAGGING = UserDetailsUrl + "/manager/tagging"
const SEARCH_MENTOR_BY_TECHNICAL_SKILL = UserDetailsUrl + "/searchUser/by/skill/"
const FETCH_PROFILE_STATUS_BY_EMAILID=UserDetailsUrl+"/profile/status/by/email/"
const FETCH_USER_BY_EMAILID = UserDetailsUrl + "/by/email/"

const FETCH_ACTIVE_UNAVAILABLE_USERS_COUNTS = UserDetailsUrl + "/fetch/active/unavailable/users/counts"
const FETCH_ALL_PROFILE_STATIC_DATA = UserDetailsUrl + "/fetch/all/masterdata"


export default {
    FETCH_USER_BY_EMAILID,UPDATE_PROFILE_BY_EMAILID,UPDATE_PROFILE_STATUS_BY_EMAILID,
    MANAGER_TAGGING,SEARCH_MENTOR_BY_TECHNICAL_SKILL,FETCH_PROFILE_STATUS_BY_EMAILID,FETCH_ACTIVE_UNAVAILABLE_USERS_COUNTS,
    FETCH_ALL_PROFILE_STATIC_DATA
}