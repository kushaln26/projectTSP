
enum TechnicalSkills{
    JAVA="Java",
    REACT="React",
    SPRING_BOOT="Spring Boot",
    JAVA_SCRIPT="Java Script",
    MICROSERVICES="Microservices"
}
export default TechnicalSkills;