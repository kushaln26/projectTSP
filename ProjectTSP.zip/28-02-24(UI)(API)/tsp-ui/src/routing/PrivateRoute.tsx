import { Login } from '@mui/icons-material';
import React, {ComponentType} from 'react'
import { useSelector } from 'react-redux';
import { RootState } from '../store/rootReducer';
import { Navigate } from 'react-router-dom';

interface PrivateRouteProps{
    component: ComponentType;
    path?:string
}

function PrivateRoute({ component: Component, path, ...props }: PrivateRouteProps) {
    const user=useSelector((state:RootState)=>state.user.user)

    const token=localStorage.getItem('token');
    const isLoggedIn = !!user?.emailId;

    if (isLoggedIn) {
        return (
            <Component />
        )
    }
    return <Navigate to="/" replace />;
}

export default PrivateRoute