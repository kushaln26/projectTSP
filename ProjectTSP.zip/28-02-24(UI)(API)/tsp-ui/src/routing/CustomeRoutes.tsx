import { Suspense, useState } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import Login from '../pages/pagesCommon/login/Login';
import Dashboard from '../pages/pagesCommon/dashBoard/Dashboard';
import AdminUserManagement from '../pages/admin/adminUserManagement/AdminUserManagement';
import Admin from '../pages/admin/adminDashboard/Admin';
import Reset from '../pages/pagesCommon/changePassword/ChangePassword';
import Header from '../pages/pagesCommon/header/Header';
import ForgotPassword from '../pages/pagesCommon/forgotPassword/ForgotPassword';
import Archive from '../pages/admin/talentShareReport/TalentShareReports';
import ViewProfile from '../pages/mentee/ViewMenteeProfile/ViewMenteeProfile';
import SearchMentor from '../pages/mentee/searchMentor/SearchMentor';
import ChangePassword from '../pages/pagesCommon/changePassword/ChangePassword';
import MenteeSessionHistory from '../pages/mentee/sessionHistory/MenteeSessionHistory';
import MenteeDashboard from '../pages/mentee/menteeDashboard/MenteeDashboard';
import Mentor from '../pages/mentor/mentorDashboard/Mentor';
import MentorShipRequests from '../pages/mentor/MentorShipRequests/MentorShipRequests';
import MentorSessionRecord from '../pages/mentor/mentorSessionRecord/MentorSessionRecord';
import Profile from '../pages/pagesCommon/profile/Profile';
import ManagerDashboard from '../pages/manager/managerDashboard/managerDashboard';
import { Search } from '@mui/icons-material';
import TablePage from '../components/pagination/TablePage';
import DeleteUserDatePicker from '../pages/admin/deleteUserDatePicker/DeleteUserDatePicker';
import ManagerSessionHistory from '../pages/manager/sessionHistory/ManagerSessionHistory';
import ManagerViewMentorshipRequests from '../pages/manager/ManagerViewMentorshipRequests/ManagerViewMentorshipRequests';
import TokenInterceptor from '../jwt/TokenInterceptorFailure';
import PrivateRoute from './PrivateRoute';


function CustomeRoutes() {
    const location = useLocation();
    return (
        <Suspense>
            <TokenInterceptor />
            {location.pathname !== "/login" && location.pathname !== "/reset" && location.pathname !== "/forgot-password" && location.pathname !== "/" && <Header />}
            <Routes>
               <Route path='/' element={<Login />} />
               <Route path='/login' element={<Login />} />
               <Route path='/forgot-password' element={<ForgotPassword />} />
               <Route path='/reset' element={<PrivateRoute component={ChangePassword} />} />
               <Route path='/admin' element={<PrivateRoute component={Admin} />} />
               <Route path='/mentor-dashboard' element={<PrivateRoute component={Mentor} />} />
               <Route path='/mentee-dashboard' element={<PrivateRoute component={MenteeDashboard} />} />
               <Route path='/manager-dashboard' element={<PrivateRoute component={ManagerDashboard} />} />
            </Routes>
        </Suspense>
    )
}

export default CustomeRoutes