import React, { useState, useRef } from 'react';
import Button from '../../../components/button/Button';
import ErrorMessage from '../../../components/error/ErrorMessage';
import dragDrop from "../../../images/dragAndDrop.png";
import "./ManagerTaggingPopup.css"
import Loader from '../../../components/loader/Loader';
import userApi from '../../../apis/userManagement';

function ManagerTaggingPopup() {
  const [file, setFile] = useState<File | undefined>(undefined);
  const [loading, setLoading] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
    }
  };

  const handleBrowse = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const handleUpload = async () => {
    setLoading(true)
    if (!file) {
      setUploadError('Please select a file');
      setLoading(false);
      return;
    }
    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls')) {
      setUploadError('Please select a valid Excel file');
      setLoading(false);
      return;
    }

    try {
      const formData = new FormData();
      formData.append('file', file);
      const response = await userApi.managerTagging(formData);

      const blob = new Blob([response.data], { type: response.headers['content-type'] });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'DownloadedFile.xlsx';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

    } catch (error) {
      console.error('API Error:', error);
      setUploadError('Error uploading the file. Please try again.');
    } finally {
      setLoading(false);
      setFile(undefined);
    }
  };

  return (
    <>
      <Loader loading={loading} />
      <div className="managerTagFileContainer">
        <div className='browse-file'>
          <img className='dragDrop' src={dragDrop} alt="Drag and drop icon" />
          Drag and Drop here or
          <Button
            type="button"
            className="file-select-button"
            onClick={handleBrowse}
          >
            Browse
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx, .xls"
            onChange={handleFileChange}
            style={{ display: 'none' }}
          />
          your excel sheet
        </div>
      </div>
      <Button
        type="button"
        className='uploadButton'
        onClick={handleUpload}
        disabled={!file || loading}
        bootstrap_class_styles="btn-primary"
      >
        Upload
      </Button>
      {uploadError && <ErrorMessage message={uploadError} />}
    </>
  );
};

export default ManagerTaggingPopup;
