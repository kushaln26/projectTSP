import React, { useEffect, useState } from 'react';
import "./TalentShareReport.css"
import DateRange from '../../../components/dateRange/DateRange';
import { ArchiveRequest } from '../../../utility/models/archive/ArchiveRequest';
import { reportGeneration } from '../../../apis/reportGeneration';
import { ExcelReportGeneration } from '../../../utility/commonLogic/ExcelReportGeneration';
import { bool, date, number, string } from 'yup';
import { usersReport } from '../../../utility/models/usersReport/usersReport';
import Button from '../../../components/button/Button';
import CloudDownloadIcon from '@mui/icons-material/CloudDownload';
import CloudDownloadOutlinedIcon from '@mui/icons-material/CloudDownloadOutlined';
import { Row } from 'react-bootstrap';
import Loader from '../../../components/loader/Loader';
import { EmptyInputValidate } from '../../../utility/validations/EmptyInputValidate';
import { Validation } from '../../../utility/models/validation/Validation';
import ResponseDisplay from '../../../components/responseMessage/ResponseMessage';

const TalentShareReport = () => {

  const [userReport, setUsersReport] = useState<usersReport[]>([]);
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" });
  const [apiSuccess, setApiSuccess] = useState<string>("")
  const [apiError, setApiError] = useState<string>("")
  const [userReportRequestInput, setUserReportRequestInput] = useState<ArchiveRequest>({
    localStartDate: "",
    localEndDate: "",
    departmentUnit: "",
  });

  const handleSubmission = async (e: React.FormEvent<HTMLFormElement>) => {
    setLoading(true);
    const localStartDate = EmptyInputValidate(userReportRequestInput.localStartDate);
    const localEndDate = EmptyInputValidate(userReportRequestInput.localEndDate);
    const departmentUnit = EmptyInputValidate(userReportRequestInput.departmentUnit);

    if (localStartDate && localStartDate !== null) {
      setFeedback(() => ({ isValid: true, errorMessage: localStartDate, inputFieldName: "localStartDate" }))
    } else if (localEndDate && localEndDate !== null) {
      setFeedback(() => ({ isValid: true, errorMessage: localEndDate, inputFieldName: "localEndDate" }))
    }         

    else{
    try {
      const promise = await reportGeneration.getUserReport(userReportRequestInput);
      const response: usersReport[] = await promise.data.payLoad
      console.log("response", response);
      setUsersReport(response);
    } catch (error: any) {
      if(typeof error?.response.data.payLoad === "string"){
        setApiError(error?.response.data.payLoad)
      }else{
        setApiError(error.message)
      }
    } finally {
      setLoading(false);
    }
  }
  }

  const handleDownload = () => {
    ExcelReportGeneration(userReport, "usersReport")
  };

  const onClosePopup=()=>{
    setApiError("")
    setApiSuccess("")
  }

  return (
    <>
      {(apiSuccess && userReport.length < 0) && (
        <ResponseDisplay responseData={apiSuccess} className={"success"} showMessage={true} onClose={onClosePopup}/>
      )}

      {apiError && <ResponseDisplay responseData={apiError} className={"error"} showMessage={true} onClose={onClosePopup} />}
      <div>
        <div className='input-data-styles'>
            <DateRange 
              includeDropdown={true}
              handleSubmission={handleSubmission} 
              formData={userReportRequestInput} 
              setFormData={setUserReportRequestInput}
              feedback={feedback}
              setFeedback={setFeedback}
        />
        </div>
        <Loader loading={loading} />
        {userReport.length > 0 && (
          <div className='download-root'>
            <div onClick={handleDownload} className='download-styles'><CloudDownloadOutlinedIcon style={{ marginRight: "40" }} className='' />Download Talent Share Record </div>
          </div>
        )}
      </div>
    </>
  );
};

export default TalentShareReport;


export interface userProjectExperience {
  projectName: string,
  role: string,
  roleDescription: string,
  duration: number,
  toolsAndFramework: string,
  client: string
}

