import React, { useState } from 'react';
import { Row, Col, Table } from 'react-bootstrap';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import Button from '../../../components/button/Button';
import './deleteUserDatePicker.css'
import EditIcon from '@mui/icons-material/Edit';
import { DateCalendar, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs, { Dayjs } from 'dayjs';
import utc from 'dayjs/plugin/utc';
import customParseFormat from 'dayjs/plugin/customParseFormat';
import { DeleteUser } from '../../../utility/models/deleteUsersRequest/deleteUsersRequest';

dayjs.extend(utc);
dayjs.extend(customParseFormat);



interface DeleteUserDatePickerProps {
    deleteUsers: DeleteUser[];
    setDeleteUsers: (data: DeleteUser[]) => void;
    HandleCloseDatePick: () => void;
    setShowDeleteConfirmPopup: (value: boolean) => void
}

const DeleteUserDatePicker = ({ deleteUsers, setDeleteUsers, HandleCloseDatePick, setShowDeleteConfirmPopup }: DeleteUserDatePickerProps) => {
    const [selectedDate, setSelectedDate] = useState<Dayjs | null>(dayjs('2022-04-17'));
    const [selectedUser, setSelectedUser] = useState<DeleteUser | null>(null);

    const handleEditUser = (user: DeleteUser) => {
        setSelectedUser(user);
    };

    const convertDate = (dateString: string | undefined) => {
        const parsedDate = dayjs(dateString);
        const month = parsedDate.format('MMM');
        const day = parsedDate.format('D');
        const dayOfWeek = parsedDate.format('ddd');
        const formattedDate = `${month} ${day} ${dayOfWeek}`;
        return formattedDate;
    };

    const handleCalendarChange = (date: Dayjs) => {

        const utcDate = date.utc();
        setSelectedDate(utcDate.startOf('day'));

        if (selectedUser) {
            const updatedUsers = deleteUsers.map(user =>
                user.userMailId === selectedUser.userMailId ? { ...user, exitDate: utcDate.format('YYYY-MM-DD') } : user
            );
            setDeleteUsers(updatedUsers);
        }
        setSelectedUser(null)
    };

    const onConfirmDelete = () => {
        HandleCloseDatePick();
        setShowDeleteConfirmPopup(true)
    }

    return (
        <>
            <Row>
                <Col xs={6} className='d-flex flex-column'>
                    <div >
                        {selectedUser && <div className='user-data-styles d-flex justify-content-between'>
                            <span>{selectedUser?.userMailId + " "} Calendar</span>
                            <span>{selectedUser?.exitDate && convertDate(selectedUser?.exitDate) + " "}</span>
                            <span></span></div>
                        }
                    </div>
                    <div className='m-0 p-0'>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                            <DateCalendar
                                value={selectedDate}
                                onChange={
                                    handleCalendarChange
                                }
                                
                                disabled={!selectedUser}
                            />
                        </LocalizationProvider>
                    </div>
                </Col>
                <Col xs={6}>
                    <Table bordered={false}>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Exit Date</th>
                            </tr>
                        </thead>
                        <tbody className='fontSize'>
                            {deleteUsers.map(user => (
                                <tr key={user.userMailId}>
                                    <td>{user.userMailId}</td>
                                    <td>
                                        {!user.exitDate ?
                                            <Button
                                                className='fontSize nowrap button-styles'
                                                type='button'
                                                disabled={!!selectedUser}
                                                onClick={() => handleEditUser(user)}>
                                                Add Date
                                            </Button>
                                            :
                                            <>
                                                <span>{user.exitDate + " "}</span>
                                                <Button
                                                    className='fontSize edit-icon-size nowrap button-styles'
                                                    type='button'
                                                    onClick={() => handleEditUser(user)}
                                                    disabled={!!selectedUser}>
                                                    <EditIcon style={{ fontSize: "xx-small" }} />
                                                </Button>
                                            </>}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </Col>
            </Row>
            <hr />
            <div className=''>
                <Button type='button' onClick={onConfirmDelete} className='button-style'>Confirm</Button>
                <Button type='button' onClick={HandleCloseDatePick} className='button-style'>Cancel</Button>
            </div>
        </>
    );
};

export default DeleteUserDatePicker;
