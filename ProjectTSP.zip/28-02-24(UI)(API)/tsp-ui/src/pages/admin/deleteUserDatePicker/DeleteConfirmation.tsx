import React, { Dispatch, SetStateAction, useState } from 'react';
import { Button } from 'react-bootstrap';
import Modal from '../../../components/modal/Modal';
import userApi from '../../../apis/userManagement';
import { useNavigate } from 'react-router-dom';
import { DeleteUser } from '../../../utility/models/deleteUsersRequest/deleteUsersRequest';
import './DeleteConfirmation.css'

type SetApiResponseMessages = Dispatch<SetStateAction<{ success: string; error: string; }>>;
interface DeleteProps {
  showModal: boolean;
  onHide: () => void;
  deleteUsers: DeleteUser[];
  setFetchedUser?: any
  setApiResponseMessages:SetApiResponseMessages
}

function DeleteConfirmation({ showModal, onHide, deleteUsers, setFetchedUser, setApiResponseMessages }: DeleteProps) {
  const navigate = useNavigate();
  const handleDelete = async () => {
    console.log('deleteUsers', deleteUsers);
    try {
      const promise = await userApi.deleteUsers(deleteUsers)
      const response = await promise.data.payLoad
      setApiResponseMessages({success:response,error:""})
      onHide()
      setFetchedUser([])
    } catch (error:any) {
      const message=await error.response.data.payLoad
      if(typeof message==="string"){
        onHide()
        setApiResponseMessages({success:"",error:message})
      }
    }
  }

  return (
    <>
      <Modal
        modalBodyStyles={"customBody"}
        modalHeaderStyles={"customHeader"}
        modalFooterStyles={"customFooter"}
        modalContainerStyles={"customContainer"}
        centered={true}
        show={showModal}
        onHide={onHide}
        backdrop="static"
        keyboard={true}
        modalBody={
        <>
         <div className="delete-popup">
                <h5> Are you sure, You want to delete the user?</h5><p>If you delete the user, it will not be possible to recover again to the portal.</p>
              </div>
        </>}
        modalFooter={
          <>
                <div className='customButton'>
                  <Button type='button' className='yesButton' onClick={ handleDelete}> Yes </Button>
                  <Button type="button" className='noButton' onClick={onHide}> No </Button>
                </div>
              </>
        }
      />







    </>
  );
}

export default DeleteConfirmation;