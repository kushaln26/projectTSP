import React from 'react'
import Feedback from '../../../components/feedbackForm/FeedBack'
import MSFormLinks from '../../../constants/MSFormLinks'

function ViewFeedBacks() {

  return (
    <>
        <Feedback MSFormLink={MSFormLinks.VIEWING_FEEDBACK}/>
    </>
  )
}

export default ViewFeedBacks