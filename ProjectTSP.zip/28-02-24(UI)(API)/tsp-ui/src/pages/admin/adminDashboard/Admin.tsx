import { Link } from "react-router-dom";
import { useState } from "react";
import Button from "../../../components/button/Button";
import DownloadMSForm from "../../mentor/downloadMSForm/DownloadMSForm";
import Modal from "../../../components/modal/Modal";
import ManagerTaggingPopup from "../managerTagging/ManagerTaggingPopup";
import TabComponent from "../../../components/tabs/TabComponent";
import ViewProfile from "../../mentee/ViewMenteeProfile/ViewMenteeProfile";
import AdminUserManagement from "../adminUserManagement/AdminUserManagement";
import TalentShareReport from "../talentShareReport/TalentShareReports";
import FeedBack from "../../../components/feedbackForm/FeedBack";
import MentorshipSessionRecords from "../mentorShipRecords/MentorshipSessionRecords";
import ViewFeedBacks from "../ViewFeedBack/ViewFeedBacks";

function Admin() {
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const downloadLink = 'https://forms.office.com/Pages/DesignPageV2.aspx?subpage=design&FormId=RbyHGSnm00eTJrUwDdFeNBlzusXkZpFPpiYR8I_-6ABUQTk4WTk4U0JZWjFLVE80VVZXSEFHQlQzTi4u';

  const [show, setShow] = useState<boolean>(false)
  const handleClose = () => { setShow(false) }
  const handleShow = () => { setShow(true) };

  const handleShowDownloadModal = () => {
    setShowDownloadModal(true);
  };

  const handleHideDownloadModal = () => {
    setShowDownloadModal(false);
  };

  const tabsProps = [
    {
      label: 'User Management',
      content: <div className="m-3"><AdminUserManagement /></div>,
    }, 
    {
      label: 'Feedback',
      content: <div className="m-3"><ViewFeedBacks /></div>,
    }
    , 
    {
      label: 'Talent Share Report',
      content: <div className="m-3"><TalentShareReport/></div>,
    }
    
    , 
    {
      label: 'Manager Tagging',
      content: <div className="m-3"><ManagerTaggingPopup /></div>,
    }
  ]


  return (
    <>
      <div className='p-4'>
        <TabComponent dashboardOf={"Admin"} tabs={tabsProps} />
      </div>
    </>
  );
}

export default Admin;