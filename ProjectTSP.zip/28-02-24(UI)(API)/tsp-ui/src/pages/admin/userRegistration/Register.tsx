import React, { Dispatch, SetStateAction, useEffect, useState } from 'react';
import "./register.css"
import ReusableForm from '../../../components/form/Form';
import FormInput from '../../../components/input/Input';
import Button from '../../../components/button/Button';
import userApi from '../../../apis/userManagement';
import DropdownSelection from '../../../components/dropdown/dropdownSelection';
import { RegisterUser } from '../../../utility/models/register/RegisterUser';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom'
import { RegisterUserConstructedForBackend } from '../../../utility/models/register/RegisterUser';
import { RootState } from '../../../store/rootReducer';
import { Validation } from '../../../utility/models/validation/Validation';
import { EmptyInputValidate, IsContainsOnlyNumbers } from '../../../utility/validations/EmptyInputValidate';
import { AxiosResponse } from 'axios';
import ErrorMessage from '../../../components/error/ErrorMessage';
import { staticDataFetch } from '../../../apis/staticDataFetch';
import { StaticData } from '../../../utility/models/staticData/staticData';
import { MasterDataResponse } from '../../../utility/models/masterData/MasterDataResponse';
import "./register.css"
import ResponseDisplay from '../../../components/responseMessage/ResponseMessage'; // Import ResponseDisplay component


type SetApiResponseMessages = Dispatch<SetStateAction<{ success: string; error: string; }>>;

interface RegisterProps {
  setApiResponseMessages: SetApiResponseMessages;
  onHide: () => void
}

function Register({ setApiResponseMessages, onHide }: RegisterProps) {
  const user = useSelector((state: RootState) => state.user.user);
  const initialFormData = { firstName: "", lastName: "", emailId: "", empId: 0, userGroup: "", businessUnit: "", createdBy: user?.emailId }
  const [registerFormData, setRegisterFormData] = useState<RegisterUser>(initialFormData);
  const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" });
  const [dropDownData, setDropDownData] = useState<StaticData>({ userGroups: [], bussinessUnits: [] })
  const [apiErrors, setApiError] = useState<string>("");

  useEffect(() => {
    dropdownSelectionItems();
  }, [])

  const transformedArray = (data: Array<any>) => {
    return data.map(item => ({
      label: item,
      value: item
    }))
  }

  const setData = async (promise: any) => {
    const response = await promise;
    const res: MasterDataResponse = await response.data.payLoad;
    const bussinessUnits = res.businessUnits;
    setDropDownData((prevDropDownData) => ({ ...prevDropDownData, bussinessUnits: transformedArray(bussinessUnits) }))
    const userGroups = res.userGroups
    setDropDownData((prevDropDownData) => ({ ...prevDropDownData, userGroups: transformedArray(userGroups) }))
  }

  const dropdownSelectionItems = async () => {
    try {
      const promise = await staticDataFetch.getMaterData()
      await setData(promise);
    } catch (error: any) {
      setApiError(error?.message)
    }
  }

  const handleSubmit = async (registerFormData: RegisterUser) => {
    const mailIdMessage = EmptyInputValidate(registerFormData.emailId);
    const firstName = EmptyInputValidate(registerFormData.firstName);
    const lastName = EmptyInputValidate(registerFormData.lastName);
    const businessUnit = EmptyInputValidate(registerFormData.businessUnit);
    const userGroup = EmptyInputValidate(registerFormData.userGroup)
    const empId = EmptyInputValidate(registerFormData.empId) || IsContainsOnlyNumbers(registerFormData.empId.toString())

    if (firstName && firstName !== null) {
      setFeedback(() => ({ isValid: true, errorMessage: firstName, inputFieldName: "firstName" }))
    } else if (lastName && lastName !== null) {
      setFeedback(() => ({ isValid: true, errorMessage: lastName, inputFieldName: "lastName" }))
    } else if (empId && empId !== null) {
      setFeedback(() => ({ isValid: true, errorMessage: empId, inputFieldName: "empId" }))
    } else if (mailIdMessage && mailIdMessage !== null) {
      setFeedback(() => ({ isValid: true, errorMessage: mailIdMessage, inputFieldName: "emailId" }))
    } else if (userGroup && userGroup !== null) {
      setFeedback(() => ({ isValid: true, errorMessage: userGroup, inputFieldName: "userGroup" }))
    } else if (businessUnit && businessUnit !== null) {
      setFeedback(() => ({ isValid: true, errorMessage: businessUnit, inputFieldName: "businessUnit" }))
    } else {
      try {
        const promise: AxiosResponse = await userApi.registerUser(registerFormData)
        const res = await promise.data;
        if (res) {
          onHide()
          setApiResponseMessages({ success: res.message, error: '' })
        }

      }
      catch (error: any) {
        const message = error.response?.data?.payLoad;
        if (typeof message === 'string') {
          onHide();
          setApiResponseMessages({ success: '', error: message });
        }
        else {
          onHide();
          setApiResponseMessages({ success: '', error: message?.createdBy || message?.emailId })
        }
      }
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLSelectElement>) => {
    setApiResponseMessages({ success: "", error: "" })
    setFeedback({ ...feedback, isValid: false, inputFieldName: e.target.name, errorMessage: "" })
    setRegisterFormData({ ...registerFormData, [e.target.name]: e.target.value })
    const { name, value } = e.target
    const message = EmptyInputValidate(e.target.value);
    if (message && message !== null) {
      setFeedback((feedback) => ({ isValid: true, errorMessage: message, inputFieldName: name }))
    }
    if (name === "empId") {
      const empId = IsContainsOnlyNumbers(value)
      if (empId) {
        setFeedback(() => ({ isValid: true, errorMessage: empId, inputFieldName: "empId" }))
      }
    }
  }

  return (
    <>
      <div className='d-flex justify-content-center'>
      </div>
      <ReusableForm onSubmit={handleSubmit} formData={registerFormData} setFormData={setRegisterFormData}>
        <div className='m-auto '>
          <div className='FirstName p-1'>
            <FormInput feedback={feedback} setFeedback={setFeedback} label="First Name" name="firstName" type="text" value={registerFormData.firstName} onChange={handleChange} />
          </div>
          <div className='FirstName p-1'>
            <FormInput feedback={feedback} setFeedback={setFeedback} label="Last Name" name="lastName" type="text" value={registerFormData.lastName} onChange={handleChange} />
          </div>
          <div className='FirstName p-1'>
            <FormInput feedback={feedback} setFeedback={setFeedback} label="User Email" name="emailId" type="text" value={registerFormData.emailId} onChange={handleChange} />
          </div>
          <div className='FirstName p-1'>
            <FormInput feedback={feedback} setFeedback={setFeedback} label="Employee Id" name="empId" type="text" value={registerFormData.empId === 0 ? "" : registerFormData.empId} onChange={handleChange} />
          </div>
          <div className='dropDown p-1'>
            <DropdownSelection feedback={feedback} setFeedback={setFeedback} label="Select User Group" name="userGroup" value={registerFormData.userGroup}
              options={dropDownData?.userGroups}
              onChange={handleChange} />
          </div>
          <div className='dropDown p-1'>
            <DropdownSelection feedback={feedback} setFeedback={setFeedback}
              isRequired={true}
              label="Select BU Group"
              name="businessUnit"
              value={registerFormData.businessUnit}
              options={dropDownData?.bussinessUnits}
              onChange={handleChange} />
          </div>
          <div className='d-flex mt-5 flex-wrap justify-content-between'>
            <Button type="submit" >Create User</Button>
            <Button type="reset" onClick={() => { setRegisterFormData(initialFormData) }}>Clear</Button>
          </div>
        </div>
      </ReusableForm>
    </>
  );
}

export default Register;
