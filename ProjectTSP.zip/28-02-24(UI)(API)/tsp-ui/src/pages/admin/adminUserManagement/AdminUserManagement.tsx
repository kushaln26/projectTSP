import axios from "axios";
import { useEffect, useState } from "react";
import { PaginationResponse } from "../../../utility/models/pagination/PaginationResponse";
import DeleteConfirmation from "../deleteUserDatePicker/DeleteConfirmation";
import Register from "../userRegistration/Register";
import MyOffCanvas from "../../../components/offCanvas/MyOffCanvas";
import "./adminUserManagement.css"
import { InputAdornment, TextField } from "@mui/material";
import { Search } from "@mui/icons-material";
import Button from "../../../components/button/Button";
import DataTable from "../../../components/pagination/TablePage";
import { GridColDef } from "@mui/x-data-grid";
import { LoginResponseObject } from "../../../utility/models/login/LoginResponseObject";
import userApi from "../../../apis/userManagement";
import DeleteUserDatePicker from "../deleteUserDatePicker/DeleteUserDatePicker";
import Modal from "../../../components/modal/Modal";
import ErrorMessage from "../../../components/error/ErrorMessage";
import ResponseDisplay from "../../../components/responseMessage/ResponseMessage";
import Loader from '../../../components/loader/Loader';


function AdminUserManagement() {
    const [users, setUsers] = useState<PaginationResponse[]>([{ name: '', emailId: '', userGroup: '' }]);
    const [show, setShow] = useState<boolean>(false);
    const [showDatePickPopup, setShowDatePickPopup] = useState<boolean>(false);
    const [showDeleteConfirmPopup, setShowDeleteConfirmPopup] = useState<boolean>(false);
    const [loading, setLoading] = useState(false);
    const [usersStatus, setUsersStatus] = useState<{ activeUsers: number, userGroupsCount: number, unavailableUsers: number } | null>(null);

    const [searchInput, setSearchInput] = useState<string>("");
    const [fetchedUser, setFetchedUser] = useState<LoginResponseObject[]>([]);
    const [deleteUsers, setDeleteUsers] = useState<{ userMailId: string, exitDate: string }[]>([])

    const [apiErrors, setApiError] = useState<string>("");
    const [apiResponseMessages, setApiResponseMessages] = useState<{ success: string, error: string }>({ success: "", error: "" });
    const [showResponseBottomModal, setShowResponseBottomModal] = useState<boolean>(false);

    const deleteUsersArray = (users: string[]): { userMailId: string, exitDate: string }[] => {
        return users.map(row => ({
            userMailId: row,
            exitDate: ""
        }))
    }

    useEffect(()=>{
        fetchAllUserRecords()
    }, [apiResponseMessages.success, apiResponseMessages.error])

    const handleSelectionChange = async (selectionModel: any) => {
        setDeleteUsers(deleteUsersArray(selectionModel))
    };

    const handleClose = () => setShow(false);
    const handleShow = () => { setShow(true) };
    const HandleCloseDatePick = () => setShowDatePickPopup(false)

    const onSearchInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFetchedUser([])
        setSearchInput(e.target.value);
        fetchUserRecord(e.target.value)
    }

    const fetchAllUserRecords = async () => {
        try {
            const promise = await userApi.getAllActiveUsers();
            const response = await promise.data.payLoad;

            setFetchedUser(response);
        } catch (error: any) {
            setApiResponseMessages({success:"", error:error.response.data.payLoad})
        }
    }

    const fetchUserRecord = async (searchData: string) => {
        setLoading(true);
        setApiError("")
        setApiResponseMessages({ success: "", error: "" })
        try {
            const promise = await userApi.fetchUserByMailId(searchData)
            const response = await promise.data;
            setFetchedUser([response.payLoad]);
        } catch (error: any) {
            const message = error.response?.data?.payLoad;
            if (typeof message === 'string') {
                setApiError(message);
                setApiResponseMessages({ success: "", error: message })
            } else {
                setApiResponseMessages({ success: "", error: message?.createdBy });
            }
        } finally {
            setLoading(false);
        }
    }

    const getUsersStatus = async () => {
        try {
            const promise = await userApi.getUserReportActiveUnavailable();
            const response = promise.data.payLoad;
            setUsersStatus(response);
        } catch (error: any) {
            console.log(error.response.data.message);
            setApiResponseMessages({ success: "", error: error.response.data.message })
        }
    }

    useEffect(() => {
        getUsersStatus();
    }, [])

    const deleteUser = () => {
        setShowDatePickPopup(true);
    }

    const onCloseResponseMessage = () => {
        setApiResponseMessages({ success: "", error: "" })
    }

    const convertedUser = (fetchedUser: LoginResponseObject[]) => {
        const users = fetchedUser;
        const convertedUser =  users.map(user=>{
            return { ...user, empId: user.empId.toString() };
        })
        return convertedUser;
    }
    return (
        <>
            <div className='d-flex  justify-content-between'>
                <TextField
                    placeholder="Search..."
                    size="small"
                    style={{ height: "80%", maxHeight: "80px" }}
                    className='custom-search-input-style'
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <Search />
                            </InputAdornment>
                        ),
                    }}
                    name="searchInput"
                    onChange={onSearchInputChange}

                />
                {deleteUsers.length > 0 ?
                    <Button type="button" className='delete-btn-color btn-size text-nowrap' onClick={deleteUser}>Delete User</Button>
                    : <Button type='button' className='btn-primary btn-size text-nowrap' onClick={handleShow}>Add User</Button>
                }
            </div>
            <div className='d-flex justify-content-start p-1 m-2 '>
                <span className='span-stat font-color-family'>Active Users :  </span><span className='span-stat-value font-color-family'> {usersStatus?.activeUsers}</span>
                <span className='span-stat font-color-family'>User Group :  </span><span className='span-stat-value font-color-family'> {usersStatus?.userGroupsCount}</span>
                <span className='span-stat font-color-family'>Unavailable User : </span> <span className='span-stat-value font-color-family'> {usersStatus?.unavailableUsers}</span>
            </div>

            <div className='mt-5'>

                <DataTable checkboxSelection={true} handleSelectionChange={handleSelectionChange} getRowId={(rows: RowType) => rows.emailId} columns={columns} rows={convertedUser(fetchedUser)} />
                <Loader loading={loading} />

            </div>
            {apiResponseMessages.success &&
                <ResponseDisplay
                    responseData={apiResponseMessages.success}
                    className="success"
                    showMessage={true}
                    onClose={onCloseResponseMessage}
                />
            }
            {apiResponseMessages.error && <div>
                <ResponseDisplay
                    responseData={apiResponseMessages.error}
                    className="error"
                    showMessage={true}
                    onClose={onCloseResponseMessage} />
            </div>}

            <MyOffCanvas
                bodyStyle="canvas-body-style"
                headerStyle="canvas-header-style"
                show={show}
                onHide={handleClose}
                canvasTitle="Add User"
                canvasBody={
                    <Register onHide={handleClose}
                        setApiResponseMessages={setApiResponseMessages} />}
            />


            <DeleteConfirmation
                showModal={showDeleteConfirmPopup}
                onHide={() => setShowDeleteConfirmPopup(false)}
                deleteUsers={deleteUsers}
                setFetchedUser={setFetchedUser}
                setApiResponseMessages={setApiResponseMessages}
            ></DeleteConfirmation>


            <Modal
                size="lg"
                centered
                hr="true"
                show={showDatePickPopup}
                onHide={() => setShowDatePickPopup(false)}
                modalTitle={<div className="d-flex flex-column justify-content-start">
                    <h6>Delete User</h6>
                    <h6>Please provide the user exit date</h6></div>}
                modalBody={<DeleteUserDatePicker setShowDeleteConfirmPopup={setShowDeleteConfirmPopup} HandleCloseDatePick={HandleCloseDatePick} setDeleteUsers={setDeleteUsers} deleteUsers={deleteUsers} />}
            />


        </>
    );
}

export default AdminUserManagement

const columns: GridColDef[] = [
    { field: 'firstName', headerName: 'First name', type: 'text', width: 200, },
    { field: 'lastName', headerName: 'Last name', type: 'text', width: 180 },
    { field: 'empId', headerName: 'Employee ID', type: "number",headerAlign:"left", align:"left",width: 200 },
    { field: 'emailId', headerName: 'Email ID', type: 'text', width: 250, },
    { field: 'userGroup', headerName: 'User Group', type: 'text', width: 150, },
];



interface RowType {
    firstName: string,
    lastName: string,
    empId: number,
    emailId: string,
    userGroup: string,
    status: string,
}