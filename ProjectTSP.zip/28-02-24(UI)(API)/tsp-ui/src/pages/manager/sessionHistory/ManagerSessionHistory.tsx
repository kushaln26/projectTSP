import { ReactNode, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { RootState } from "../../../store/rootReducer";
import { ArrayOfMenteeSessionHistoryResponse, MenteeSessionHistoryRequest } from "../../../utility/models/menteeSessionManagement/MenteeSessionHistoryRequest";
import { Validation } from "../../../utility/models/validation/Validation";
import { MentorShipSessionManagement } from "../../../apis/MentorShipSessionManagement";
import { Button } from "react-bootstrap";
import { GridColDef } from "@mui/x-data-grid";
import DateRange from "../../../components/dateRange/DateRange1";
import DataTable from "../../../components/pagination/TablePage";
import SessionDetailsPopUp from "../../mentee/sessionHistory/SessionDetailsPopUp";
import MyOffCanvas from "../../../components/offCanvas/MyOffCanvas";
import FeedbackPopup from "../../mentee/sessionHistory/FeedBackPopup";
import MSFormLinks from "../../../constants/MSFormLinks";
import DropdownSelection from "../../../components/dropdown/dropdownSelection";
import editButton from "../../../images/editButton.png";
import ResponseDisplay from "../../../components/responseMessage/ResponseMessage";


export interface SessionHistoryOfManagerTableData {
    mentorShipSession: number,
    topic: string,
    mentorName: string,
    sesssionStatusUpdatedDate: string,
    sessionStatus: string,
    requestIsCurrentlyWith: string,
    mentorShipStatus: string | ReactNode
}
export interface ArrayOfSessionHistoryOfManagerTableData {
    mentorshipHistoryTableDataValues: SessionHistoryOfManagerTableData[]
}

function ManagerSessionHistory() {
    const mailId = useSelector((state: RootState) => state.user.user?.emailId);
    const [sessionDateRange, setSessionDateRange] = useState<MenteeSessionHistoryRequest>({ localStartDate: "", localEndDate: "", mailId: mailId })
    const [menteeHistSessionResponseData, setMenteeHistSessionResponseData] = useState<ArrayOfMenteeSessionHistoryResponse>({ mentorshipHistoryRequests: [] })
    const [menteeHistSessionTableData, setMenteeHistSessionTableData] = useState<ArrayOfSessionHistoryOfManagerTableData>({ mentorshipHistoryTableDataValues: [] })
    const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" })
    const [sessionId, setSessionId] = useState<number>(0)
    const [dropDownData, setDropDownData] = useState('')
    const [apiErrors, setApiError] = useState<string>("");
    const [apiSuccess, setApiSuccess] = useState<string>("");
    const [recordsAvailable, setRecordsAvailable] = useState<boolean>(true)

    const [showUpdateStatusCanvas, setShowUpdateStatusCanvas] = useState<boolean>(false)
    const [show, setShow] = useState<boolean>(false);
    const [showFeedBackPopup, setShowFeedBackPopup] = useState<boolean>(false);


    useEffect(() => {
        const transformedData = menteeHistSessionResponseData.mentorshipHistoryRequests.map((response) => ({
            mentorShipSession: response.sessionId,
            topic: response.sessionTopic,
            mentorName: response.mentorName,
            sessionStatus: response.sessionStatus,
            sesssionStatusUpdatedDate: response.updatedDate,
            requestIsCurrentlyWith: response.requestCurrentlyWith,
            mentorShipStatus: response.mentorshipStatus

        }));
        setMenteeHistSessionTableData({ mentorshipHistoryTableDataValues: transformedData });
        console.log("menteeHistSessionTableData", menteeHistSessionTableData.mentorshipHistoryTableDataValues);

    }, [menteeHistSessionResponseData.mentorshipHistoryRequests])

    const onHidePopup = () => {
        setShowFeedBackPopup(false)
    }

    const enableFeedBackPopup = () => {
        setShowFeedBackPopup(true)
    }

    const onHide = () => {
        setShow(false);
    }

    const handleChangeMentorShipStatus = (e: any, sessionId: number) => {
        setSessionId(sessionId);
        setShowUpdateStatusCanvas(true);
    }

    const handleChangeDropDown = (e: any) => {
        setDropDownData(e.target.value);
    }

    const handleUpdate = () => {
        if (dropDownData === "Close") {
            setShowUpdateStatusCanvas(false);
            setShow(true);
        }
    }


    const getRecords = async () => {
        setRecordsAvailable(true)
        try {
            const promise = await MentorShipSessionManagement.getSessionRecordByEmailId(sessionDateRange);
            const response = await promise.data;
           
            if (response.payLoad.length <= 0) {
                setRecordsAvailable(false)
            }
            setMenteeHistSessionResponseData((prevMentorshipResponseData) => ({ ...prevMentorshipResponseData, mentorshipHistoryRequests: response.payLoad }));
            setApiSuccess(response?.message)
        } catch (error: any) {
            if (typeof error?.response?.data?.payLoad === "string") {
                setApiError(error?.response?.data?.payLoad)
            } else {
                setApiError(error?.response.message)
            }
        }
    }


    const handleSelectionChange = async (selectionModel: any) => {
        console.log("selectionModel", selectionModel);

    };
    const onClickOnClosePopup = () => {
        setApiError("");
        setApiSuccess("");
    }

    return (
        <>
            <DateRange
                includeDropdown={false}
                handleSubmission={getRecords}
                formData={sessionDateRange}
                setFormData={setSessionDateRange}
            />


            {menteeHistSessionTableData.mentorshipHistoryTableDataValues.length > 0 &&
                <div className='mt-5'>
                    <DataTable  sortingField={"mentorShipSession"} getRowId={(rows) => rows.mentorShipSession} handleSelectionChange={handleSelectionChange}
                        columns={columns} rows={menteeHistSessionTableData.mentorshipHistoryTableDataValues} checkboxSelection={false} />
                </div>
            }

            {!recordsAvailable &&
                <>
                    <div className='mt-5 text-danger'>
                        There are no record available
                    </div>
                </>
            }

            <MyOffCanvas
                show={showUpdateStatusCanvas}
                onHide={() => { setShowUpdateStatusCanvas(false) }}
                canvasTitle="Update Mentorship Status"
                canvasBody=
                {
                    <>
                        <DropdownSelection
                            feedback={feedback}
                            setFeedback={setFeedback}
                            label="Status"
                            name="status"
                            value={dropDownData}
                            options={[{ label: 'Close', value: 'Close' }]}
                            onChange={handleChangeDropDown}
                        />
                        <Button className="StatusUpdateButton" onClick={handleUpdate} type="button" disabled={dropDownData !== 'Close'}>
                            Update
                        </Button>
                    </>

                }
            />
            {(menteeHistSessionTableData.mentorshipHistoryTableDataValues.length < 0 && apiSuccess) &&
                <ResponseDisplay responseData={apiSuccess} onClose={onClickOnClosePopup} showMessage={true} className={"success"} />
            }
            {apiErrors &&
                <ResponseDisplay responseData={apiErrors} onClose={onClickOnClosePopup} showMessage={true} className={"error"} />
            }
        </>
    )

}

export default ManagerSessionHistory;

const columns: GridColDef[] = [
    { field: 'mentorShipSession', headerName: "Session Id", width: 120 },
    { field: 'topic', headerName: "Topic", width: 150 },
    { field: 'mentorName', headerName: "Mentor Name", width: 150 },
    { field: 'sesssionStatusUpdatedDate', headerName: "Date", width: 120 },
    { field: 'sessionStatus', headerName: "Session Status", width: 150 },
    { field: 'requestIsCurrentlyWith', headerName: "Request Current With", width: 200 },
    { field: 'mentorShipStatus', headerName: "Mentorship Status", width: 200, renderCell: (params) => (<div>{params.value}</div>) }
]
