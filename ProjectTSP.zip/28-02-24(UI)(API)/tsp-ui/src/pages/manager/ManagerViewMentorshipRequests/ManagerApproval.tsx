import { Button } from "react-bootstrap";
import Form from "../../../components/form/Form"
import FormInput from '../../../components/input/Input';
import { ApprovalPostRequest } from "../../mentor/MentorShipRequests/MentorShipRequests";
import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { Validation } from "../../../utility/models/validation/Validation";
import { MentorSessionRequestManagement } from "../../../apis/MentorSessionRequestManagement";
import { AxiosResponse } from "axios";
import { useNavigate } from "react-router-dom";
import MyOffCanvas from "../../../components/offCanvas/MyOffCanvas";
import DateTimePicker from "../../../components/DateAndTimePicker/DateAndTimePicker";
import formatDateToDateTime from "../../../utility/DateConversions/DateConversions";
import ResponseDisplay from "../../../components/responseMessage/ResponseMessage";
import { EmptyInputValidate } from "../../../utility/validations/EmptyInputValidate";

type SetApiResponseMessages = Dispatch<SetStateAction<{ success: string; error: string; }>>;

interface requestApprovalProps {
    approvalData: ApprovalPostRequest;
    // setShowModal: (show:boolean)=>void;
    hideApproveOrRejectModal: () => void;
    // setSuccessBottomModal:(show:boolean)=>void
    // setFailureBottomModal:(show:boolean)=>void
    //  setApiResponse:SetApiResponseMessages
}

function ManagerApproval({  approvalData,hideApproveOrRejectModal}: requestApprovalProps) {
    const navigate = useNavigate();
    const [commentData, setCommentData] = useState<string>('');
    const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" });
    const [approvalDataNew, setApprovalDataNew] = useState<ApprovalPostRequest>(approvalData);
    const [apiErrors, setApiError] = useState<string>("");
    const [apiSuccessMessage, setApiSuccessMessage] = useState<string>("");
    const [disableAccept, setDisableAccept] = useState<boolean>(false);
    const [disableDecline, setDisableDecline] = useState<boolean>(false);
    // const [showModal, setShowModal] = useState<boolean>(false);
    const [successBottomModal, setSuccessBottomModal] = useState<boolean>(false);
    const [failureBottomModal, setFailureBottomModal] = useState<boolean>(false);

    const handleCommentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setCommentData(e.target.value);
        const { name, value } = e.target;
        setApprovalDataNew({ ...approvalDataNew, [name]: value });
    };

    useEffect(() => {
        if (approvalDataNew.actionBy) {
            sendMentorApprovalRequest();
        }
    }, [approvalDataNew.actionBy]);

    const handleAccept = () => {
        setApprovalDataNew({ ...approvalDataNew, approvalstatus: true, actionBy: 'MANAGER_ACCEPT' });
        setDisableAccept(true);
        setDisableDecline(true);
        
    }

    const handleReject = () => {
        const comments = EmptyInputValidate(approvalDataNew.comments);

        if (comments && comments !== null) {
            setFeedback(() => ({ isValid: true, errorMessage: comments, inputFieldName: "comments" }))
        }
        else {
            setApprovalDataNew({ ...approvalDataNew, approvalstatus: false, actionBy: 'MANAGER_REJECT' });
            console.log("approvalData New inside handleReject::" + approvalDataNew);
            setDisableAccept(true);
            setDisableDecline(true);
            // setShowModal(false);
            
        }
    }

    const sendMentorApprovalRequest = async () => {
        try {
            console.log("Hi i am inside api call for accepting or rejecting");
            const promise: AxiosResponse = await MentorSessionRequestManagement.mentorShipApproval(approvalDataNew);
            const response: any = await promise.data;
            if (response) {
                setApiSuccessMessage(response.payLoad);
                setSuccessBottomModal(true);
                console.log("successBottomModal:: value ",successBottomModal);
                // setApiResponse({success:response.payLoad, error:""});
            }

        }
        catch (error: any) {
            setApiError(error?.message);
            setFailureBottomModal(true);
            console.log("setFailureBottomModal:: value ",failureBottomModal);
            // setApiResponse({success:"", error:error?.message});
            // setShowModal(false)
        }
    }

    return (
        <>

            <FormInput feedback={feedback} setFeedback={setFeedback} label="Comments" name="comments" type="text" value={commentData} onChange={handleCommentChange} />
            <div className="d-flex mt-3"><span className="requiredValueStar pt-0 mr-2">*</span><p className="declineDisclaimer">If your wish to decline please provide comment</p></div>
            <div className='d-flex mt-3'>
                <Button className="ResponseButtons Approve" type="button" onClick={handleAccept} disabled={disableAccept}>Approve</Button>
                <Button className="ResponseButtons Decline" type="submit" onClick={handleReject} disabled={disableDecline}>Reject</Button>
            </div>


            <ResponseDisplay
                className={"success"}
                responseData={apiSuccessMessage}
                showMessage={successBottomModal}
                navigateTo={'/manager-dashboard'}
                onClose={() => {
                    setSuccessBottomModal(false);
                    hideApproveOrRejectModal()
                }}
            />



            <ResponseDisplay
                className={"error"}
                responseData={apiErrors}
                showMessage={failureBottomModal}
                navigateTo={'/manager-dashboard'}
                onClose={() => { 
                    setFailureBottomModal(false); 
                    hideApproveOrRejectModal() 
                }} 
            />
        </>
    )
}

export default ManagerApproval;