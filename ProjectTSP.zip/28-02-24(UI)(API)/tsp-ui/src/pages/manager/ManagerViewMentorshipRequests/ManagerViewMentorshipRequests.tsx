import React, { useState, useEffect, ReactNode } from 'react'
import { ArrayOfMentorshipResponse, mentorshipResponse } from '../../../utility/models/mentorshipResponse/mentorshipResponse';
import { MentorSessionRequestManagement } from '../../../apis/MentorSessionRequestManagement';
import { useSelector } from 'react-redux';
import axios, { AxiosResponse } from 'axios';
import { RootState } from '../../../store/rootReducer';
import CustomizedTables from '../../../components/table/reusableTable';
import { ColumnProps } from '../../../components/table/reusableTable';
import Pagination from '../../../components/pagination/Pagination';
import { useNavigate } from 'react-router-dom';
import Modal from '../../../components/modal/Modal';
import { Validation } from '../../../utility/models/validation/Validation';
import { Button as BootButton, Button } from 'react-bootstrap';
import FormInput from '../../../components/input/Input';
import { BASE_URL } from '../../../apis/baseUrl';
import Form from '../../../components/form/Form';
import MyOffCanvas from '../../../components/offCanvas/MyOffCanvas';
import "./ManagerViewMentorshipRequests.css";
import { InputAdornment, TextField } from "@mui/material";
import { Search } from "@mui/icons-material";
import DataTable from '../../../components/pagination/TablePage';
import { GridColDef } from "@mui/x-data-grid";
import { ArrayOfSessionRequestsOfMentorResponse } from '../../../utility/models/MentorDashboard/MentorshipHistory.tsx/SessionHistoryForMentorRequest';
import ViewProfile from '../../mentee/ViewMenteeProfile/ViewProfile';
import MentorShipRequestApproval from '../../mentor/MentorShipRequests/MentorShipRequestApproval';
import ManagerApproval from './ManagerApproval';


export interface mentorshipTableHeader {
    id:number
    menteeName: string;
    mentorName:string;
    sessionTopic: string;
    menteeProfile: ReactNode;
    sessionStatus: ReactNode;
}
export interface ArrayOfMentorshipTableData {
    mentorshipTableDataValues: mentorshipTableHeader[]
}

const columns:GridColDef[] = [
    { field:'id',headerName:'Id',flex:1 },
    { field: 'menteeName', headerName: 'Mentee Name',flex:1 },
    { field: 'mentorName', headerName: 'Mentor Name',flex:1 },
    { field: 'sessionTopic', headerName: 'MentorShip Session Requests',flex:1  },
    { field: 'menteeProfile', headerName:'Mentee Profile',flex:1,renderCell:(params)=>(<div>{params.value}</div>)},
    { field: 'sessionStatus', headerName: 'Manager Response', flex:1,renderCell:(params)=>(<div>{params.value}</div>)  }
];

export interface ApprovalPostRequest{
    sessionId: number,
    actionBy:string,
    approvalstatus: boolean,
    optionDate1:string,
    optionDate2:string,
    comments: string
}

export default function ManagerViewMentorshipRequests() {
    const [mentorshipResponseData, setMentorshipResponseData] = useState<ArrayOfSessionRequestsOfMentorResponse>({ mentorshipRequests: [] });
    const [mentorshipTableData, setMentorshipTableData] = useState<ArrayOfMentorshipTableData>({ mentorshipTableDataValues: [] });
    const user = useSelector((state: RootState) => state.user.user);
    const [showModal, setShowModal] = useState(false);
    const [approveOrRejectModal, setApproveOrRejectModal] = useState(false);
    const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" });
    const [approvalData, setApprovalData] = useState<ApprovalPostRequest>({ sessionId: 0,actionBy:'',approvalstatus:false,optionDate1:'',optionDate2:'',comments:''});
    const [apiErrors, setApiError] = useState<string>("");
    const [apiSuccessMessage, setApiSuccessMessage] = useState<string>("");
    const [modalShow, setModalShow] = useState(false);
    const [selectedMenteeEmailId, setSelecteedMenteeEmailId] = useState<string>('')
    const emailId = user?.emailId;
    const navigate = useNavigate();

    const handleViewProfile = (mailId: string) => {
        setSelecteedMenteeEmailId(mailId);
        setModalShow(true);
    }

    const handleResponseClick = (selectedSessionId: number) => {
        setShowModal(true);
        setApprovalData(prevState => ({ ...prevState, sessionId: selectedSessionId}));
    };

    const handleClose = () => {
        setShowModal(false);
    }

    const fetchData = async () => {
        try 
        {
            const promise = await MentorSessionRequestManagement.getMentorSessionRequest(user?.emailId);
            const response = await promise.data;
            setMentorshipResponseData((prevMentorshipResponseData) => ({ ...prevMentorshipResponseData, mentorshipRequests: response.payLoad }));
        } 
        catch (error) 
        {
            console.error("Error fetching mentorship requests:", error);
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    useEffect(() => {
        
        fetchData();
    }, [showModal]);

    useEffect(() => {
        const transformedData = mentorshipResponseData.mentorshipRequests.map((response) => ({
            id:response.sessionId,
            menteeName: response.menteeEmailId.split('@')[0],
            mentorName: response.mentorEmailId.split('@')[0],
            sessionTopic: response.sessionTopic,
            menteeProfile: <div className='MenteeViewProfile' onClick={() => handleViewProfile(response.menteeEmailId)}>View Profile</div>,
            sessionStatus: response.sessionStatus === "REQUESTED" ?
            <div className='MentorResponse' onClick={() => handleResponseClick(response.sessionId)}>Response to Session Request</div> :
            response.sessionStatus === "SCHEDULED" ?
                <div>Approved</div> : <div>Rejected</div>
        }));
        setMentorshipTableData((prevMentorshipTableData) => ({ ...prevMentorshipTableData, mentorshipTableDataValues: transformedData }));
    }, [mentorshipResponseData]);
    
    
    return (
        <>
        <div className="search d-flex">
            <TextField
                placeholder="Search..."
                size="small"
                style={{ height: "80%", maxHeight: "80px" }}
                className='custom-search-input-style'
                InputProps={{
                    startAdornment: (
                        <InputAdornment position="start">
                            <Search />
                        </InputAdornment>
                    ),
                }}
            />
            </div>
            { mentorshipTableData.mentorshipTableDataValues.length > 0 ? (
                <div className='mt-5'>
                    <DataTable getRowId={(rows: mentorshipTableHeader) => rows.id} 
                    columns={columns} 
                    rows={mentorshipTableData.mentorshipTableDataValues} 
                    checkboxSelection={false} />
                </div>
             ): <div className='mt-5'>There are currently no session requests</div>} 

            <MyOffCanvas
                show={showModal}
                onHide={() => { setShowModal(false) }}
                canvasTitle="Response to Mentorship"
                canvasBody=
                {   
                    <>
                        <ManagerApproval 
                            // setApiResponse={}
                            // setShowModal={()=>{setShowModal(true)}}
                            hideApproveOrRejectModal={handleClose}
                            approvalData={approvalData}
                            
                            />
                    </>
                }
            />
            <Modal
                show={modalShow}
                onHide={() => { setModalShow(false) }}
                backdrop="static"
                keyboard={true}
                fullscreen={true}
                modalTitle="Profile Info"
                modalBody={<ViewProfile userEmailId={selectedMenteeEmailId} />}
            />
        </>
    )
}