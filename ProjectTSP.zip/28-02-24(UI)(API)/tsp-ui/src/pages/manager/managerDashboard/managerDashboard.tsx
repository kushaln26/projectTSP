
import { Link } from "react-router-dom";
import Button from "../../../components/button/Button";
import ViewProfile from "../../mentee/ViewMenteeProfile/ViewProfile";
import ManagerViewMentorshipRequests from "../ManagerViewMentorshipRequests/ManagerViewMentorshipRequests";
import ManagerSessionHistory from "../sessionHistory/ManagerSessionHistory";
import TabComponent from "../../../components/tabs/TabComponent";
import { useSelector } from "react-redux";
import { RootState } from "../../../store/rootReducer";
import UserProfile from "../../pagesCommon/userProfile/UserProfile";

function Mentor() {
  const user = useSelector((state: RootState) => state.user.user);
  const userEmailId:string = user ? user.emailId : ''; 

  const tabsProps = [
    {
      label: 'Profile',
      content: <div className="m-3"><UserProfile/></div>,
    },
    {
      label: 'Response to Mentorship Session',
      content: <div className="m-3"><ManagerViewMentorshipRequests/></div>,
    }, {
      label: 'Mentorship Session History',
      content: <div className="m-3"><ManagerSessionHistory/></div>,
    }
  ]

  return (
    <>
      
      <div className='p-4'>
        <TabComponent dashboardOf={"Manager"} tabs={tabsProps} />
      </div>
    </>
  );
}

export default Mentor;

















































// import { Link } from "react-router-dom";
// import { useState } from "react";
// import Button from "../../../components/button/Button";
// import DownloadMSForm from "../../mentor/downloadMSForm/DownloadMSForm";
// import Modal from "../../../components/modal/Modal";


// function ManagerDashboard() {
//   const [showDownloadModal, setShowDownloadModal] = useState(false);
//   const downloadLink = 'https://forms.office.com/Pages/DesignPageV2.aspx?subpage=design&FormId=RbyHGSnm00eTJrUwDdFeNBlzusXkZpFPpiYR8I_-6ABUQTk4WTk4U0JZWjFLVE80VVZXSEFHQlQzTi4u';

//   const [show, setShow] = useState<boolean>(false)
//   const handleClose = () => { setShow(false) }
//   const handleShow = () => { setShow(true) };

//   const handleShowDownloadModal = () => {
//     setShowDownloadModal(true);
//   };

//   const handleHideDownloadModal = () => {
//     setShowDownloadModal(false);
//   };


//   return (
//     <>
//       <div className="mt-5 d-flex justify-content-center">
//       <div className="m-3"><Link to="/user-profile"><Button type="button">PROFILE</Button></Link></div>
//       <div className="m-3"><Button type="button">Response to Mentorship Session</Button></div>
//       <div className="m-3"><Button type="button">Mentorship session history</Button></div>
//         <div className="m-3">
//           <DownloadMSForm
//             show={showDownloadModal}
//             onHide={handleHideDownloadModal}
//             downloadLink={downloadLink}
//           />
//           <div className="d-flex justify-content-center"><Button type="button" onClick={handleShowDownloadModal}>Feedback</Button></div>
//         </div>
//       </div>
//     </>
//   );
// }

// export default ManagerDashboard;