import { ReactNode, useEffect, useState } from "react";
import Input from "../../../components/input/Input";
import { Validation } from "../../../utility/models/validation/Validation";
import { ArrayOfMenteeSessionHistoryResponse, MenteeSessionHistoryRequest, MenteeSessionHistoryResponse, datesToChooseProps } from "../../../utility/models/menteeSessionManagement/MenteeSessionHistoryRequest";
import { MenteeSessionManagement } from "../../../apis/MenteeSessionManagement";
import { useSelect } from "@mui/base";
import { RootState } from "../../../store/rootReducer";
import { useSelector } from "react-redux";
import SessionDetailsPopUp from "./SessionDetailsPopUp";
import FeedbackPopup from "./FeedBackPopup";
import { GridColDef } from "@mui/x-data-grid";
import DataTable from "../../../components/pagination/TablePage";
import editButton from "../../../images/editButton.png";
import DateRange from "../../../components/dateRange/DateRange";
import "./MenteeSessionHistory.css";
import MyOffCanvas from "../../../components/offCanvas/MyOffCanvas";
import DropdownSelection from "../../../components/dropdown/dropdownSelection";
import { Button } from "react-bootstrap";
import { MentorShipSessionManagement } from "../../../apis/MentorShipSessionManagement";
import MSFormLinks from "../../../constants/MSFormLinks";
import ChooseDate from "../chooseDateCanvas/ChooseDateCanvas";
import { RadioButtonCheckedOutlined } from "@mui/icons-material";
import ResponseDisplay from "../../../components/responseMessage/ResponseMessage";
import { EmptyInputValidate } from "../../../utility/validations/EmptyInputValidate";

export interface SessionHistoryOfMenteeTableData {
    mentorShipSession: number,
    topic: string,
    mentorName: string,
    sesssionStatusUpdatedDate: string,
    sessionStatus: string,
    requestIsCurrentlyWith: string,
    mentorShipStatus: string | ReactNode
}

export interface ArrayOfSessionHistoryOfMenteeTableData {
    mentorshipHistoryTableDataValues: SessionHistoryOfMenteeTableData[]
}

function MenteeSessionHistory() {
    const mailId = useSelector((state: RootState) => state.user.user?.emailId);
    const  initialSessionDateRangeInput={ localStartDate: "", localEndDate: "", mailId: mailId }
    const [sessionDateRange, setSessionDateRange] = useState<MenteeSessionHistoryRequest>(initialSessionDateRangeInput)
    const [menteeHistSessionResponseData, setMenteeHistSessionResponseData] = useState<ArrayOfMenteeSessionHistoryResponse>({ mentorshipHistoryRequests: [] })
    const [menteeHistSessionTableData, setMenteeHistSessionTableData] = useState<ArrayOfSessionHistoryOfMenteeTableData>({ mentorshipHistoryTableDataValues: [] })
    const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" })
    const [sessionId, setSessionId] = useState<number>(0)
    const [dropDownData, setDropDownData] = useState('')

    const [showUpdateStatusCanvas, setShowUpdateStatusCanvas] = useState<boolean>(false);
    const [showChoosedateCanvas, setShowChoosedateCanvas] = useState<boolean>(false);
    const [mentorAvailableDates, setMentorAvailableDates] = useState<datesToChooseProps>({ date_1: '', date_2: '', sessionId: 0 });
    const [show, setShow] = useState<boolean>(false);
    const [isSessionDetails, setIssSessionDetails] = useState<boolean>(false);
    const [showFeedBackPopup, setShowFeedBackPopup] = useState<boolean>(false);
    const [apiErrors, setApiError] = useState<string>("");
    const [apiSuccess, setApiSuccess] = useState<string>("");
    const [recordsAvailable, setRecordsAvailable] = useState<boolean>(true)

    const OnShowFeedback = ()=>{
        setIssSessionDetails(true)
    }

    useEffect(() => {
        const transformedData = menteeHistSessionResponseData.mentorshipHistoryRequests.map((response) => ({
            mentorShipSession: response.sessionId,
            topic: response.sessionTopic,
            mentorName: response.mentorName,
            sessionStatus: response.sessionStatus,
            sesssionStatusUpdatedDate: response.updatedDate,
            requestIsCurrentlyWith: response.requestCurrentlyWith,
            mentorShipStatus: (
                <>
                    <div className="mentorshipStatus" >
                        <div className={`p-1 ${((response.sessionStatus?.toLowerCase() === "completed" || response.sessionStatus?.toLowerCase() === "rejected") ? "disabled" : "")}`}>{(response.mentorshipStatus?.toLowerCase() == "active") ? "Active" : "Closed"}</div>
                        {!(response.sessionStatus?.toLowerCase() === "completed" || response.sessionStatus?.toLowerCase() === "rejected") && <img className={`p-1 ${((response.sessionStatus?.toLowerCase() === "completed" || response.sessionStatus?.toLowerCase() === "rejected") ? "disabled" : "")}`} src={editButton} alt="update mentorship status"
                            onClick={(e) => { handleChangeMentorShipStatus(e, response.sessionId) }} />}
                    </div >
                </>
            ),
            scheduleSession: response.availableDate_1 && response.availableDate_2 &&

                response.sessionStatus?.toLowerCase() === "approved"
                ? (
                    <div onClick={() => { handleChooseDate(response.availableDate_1, response.availableDate_2, response.sessionId) }}
                        className={`scheduling-session-button   ${!response.mentorApproval ? "disabled"
                            : ""
                            }`}
                    >Schedule Session</div>
                ) :
                (response?.sessionStatus?.toLowerCase() === "completed"
                    || response?.sessionStatus?.toLowerCase() === "scheduled".toLowerCase()
                    || response?.sessionStatus?.toLowerCase() === "rejected"
                    ?
                    <div>{response.sessionStatus.toLowerCase() !== "rejected"

                        ? response.scheduledDate : "Session Rejected"}</div>
                    : <div>Request yet to approve</div>
                )
        }));
        setMenteeHistSessionTableData({ mentorshipHistoryTableDataValues: transformedData });

    }, [menteeHistSessionResponseData.mentorshipHistoryRequests])


    const onHidePopup = () => {
        setShowFeedBackPopup(false)
    }

    const enableFeedBackPopup = () => {
        setShowFeedBackPopup(true)
    }
    const onHide = () => {
        setShow(false);
    }

    const handleChangeMentorShipStatus = (e: any, sessionId: number) => {
        setSessionId(sessionId);
        setShowUpdateStatusCanvas(true);
    }

    const handleChangeDropDown = (e: any) => {
        setDropDownData(e.target.value);
    }

    const handleUpdate = () => {
        if (dropDownData === "Close") {
            setShowUpdateStatusCanvas(false);
            setShow(true);
        }
        setDropDownData("")
    }

    const handleChooseDate = (date1: string, date2: string, session_id: number) => {
        setMentorAvailableDates({ ...mentorAvailableDates, date_1: date1, date_2: date2, sessionId: session_id });
        setShowChoosedateCanvas(true);
    }

    const getRecords = async () => {
        setMenteeHistSessionTableData({ mentorshipHistoryTableDataValues: [] })
        const localStartDate = EmptyInputValidate(sessionDateRange.localStartDate);
        const localEndDate = EmptyInputValidate(sessionDateRange.localEndDate);
        if (localStartDate && localStartDate !== null) {
            setFeedback(() => ({ isValid: true, errorMessage: localStartDate, inputFieldName: "localStartDate" }))
        }
        else if (localEndDate && localEndDate !== null) {
            setFeedback(() => ({ isValid: true, errorMessage: localEndDate, inputFieldName: "localEndDate" }))
        }
        else {
            setRecordsAvailable(true)
            try {
                const promise = await MentorShipSessionManagement.getSessionRecordByEmailId(sessionDateRange);
                const response = await promise.data;
                if (response.payLoad.length <= 0) {
                    setRecordsAvailable(false)
                }
                setMenteeHistSessionResponseData((prevMentorshipResponseData) => ({ ...prevMentorshipResponseData, mentorshipHistoryRequests: response.payLoad }));

            } catch (error) {
                console.log("error", error);
            }
        }
    }


    const handleSelectionChange = async (selectionModel: any) => {

    };

    const onClickOnClosePopup = () => {
        if(isSessionDetails){
            enableFeedBackPopup();
        }
        setApiError("");
        setApiSuccess("");
        getRecords()
    }

    return (
        <>
            <DateRange
                includeDropdown={false}
                handleSubmission={getRecords}
                formData={sessionDateRange}
                setFormData={setSessionDateRange}
                feedback={feedback}
                setFeedback={setFeedback}
            />

            {menteeHistSessionTableData.mentorshipHistoryTableDataValues.length > 0 &&
                <div className='mt-5'>
                    <DataTable sortingField={"mentorShipSession"} getRowId={(rows) => rows.mentorShipSession} handleSelectionChange={handleSelectionChange} columns={columns} rows={menteeHistSessionTableData.mentorshipHistoryTableDataValues} checkboxSelection={false} />
                </div>
            }

            {!recordsAvailable &&
                <>
                    <div className='mt-5 text-danger'>
                        There are no record available
                    </div>
                </>
            }

            <MyOffCanvas
                show={showUpdateStatusCanvas}
                onHide={() => { setShowUpdateStatusCanvas(false) }}
                canvasTitle="Update Mentorship Status"
                canvasBody=
                {
                    <>
                        <DropdownSelection
                            feedback={feedback}
                            setFeedback={setFeedback}
                            label="Status"
                            name="status"
                            value={dropDownData}
                            options={[{ label: 'Close', value: 'Close' }]}
                            onChange={handleChangeDropDown}
                        />
                        <Button className="StatusUpdateButton" onClick={handleUpdate} type="button" disabled={dropDownData !== 'Close'}>
                            Update
                        </Button>
                    </>

                }
            />

            <MyOffCanvas
                show={showChoosedateCanvas}
                onHide={() => { setShowChoosedateCanvas(false) }}
                canvasTitle={
                    <>
                        <div className="CanvasHeader">Schedule the session</div>
                        <div className="CanvasPara">Please provide the below details</div>
                    </>
                }
                canvasBody=
                {
                    <>
                        <ChooseDate
                            date_1={mentorAvailableDates.date_1}
                            date_2={mentorAvailableDates.date_2}
                            sessionId={mentorAvailableDates.sessionId}
                            setShowChoosedateCanvas={setShowChoosedateCanvas}
                            setApiError={setApiError}
                            setApiSuccess={setApiSuccess}
                        />
                    </>

                }
            />

            <SessionDetailsPopUp setIssSessionDetails={OnShowFeedback} setApiError={setApiError} setApiSuccess={setApiSuccess} menteeHistSessionTableData={menteeHistSessionTableData} setMenteeHistSessionTableData={setMenteeHistSessionTableData} sessionId={sessionId} showModal={show} onHide={onHide} setShowFeedBackPopup={enableFeedBackPopup} />
            <FeedbackPopup show={showFeedBackPopup} onHidePopup={onHidePopup} downloadLink={MSFormLinks.GIVING_FEEDBACK} />
            {apiSuccess &&
                <ResponseDisplay responseData={apiSuccess} onClose={onClickOnClosePopup} showMessage={true} className={"success"} />
            }
            {apiErrors &&
                <ResponseDisplay responseData={apiErrors} onClose={onClickOnClosePopup} showMessage={true} className={"error"} />
            }
        </>
    )

}

export default MenteeSessionHistory;



const columns: GridColDef[] = [
    { field: 'mentorShipSession', headerName: "Session Id", width: 120 , sortingOrder:["asc"]},
    { field: 'topic', headerName: "Topic", width: 150 },
    { field: 'mentorName', headerName: "Mentor Name", width: 150 },
    { field: 'sesssionStatusUpdatedDate', headerName: "Date", width: 120, sortingOrder:["desc"] },
    { field: 'sessionStatus', headerName: "Session Status", width: 150 },
    { field: 'requestIsCurrentlyWith', headerName: "Request Current With", width: 200 },
    { field: 'mentorShipStatus', headerName: "Mentorship Status", width: 200, renderCell: (params) => (<div>{params.value}</div>) },
    { field: 'scheduleSession', headerName: "Schedule Session", width: 230, renderCell: (params) => (<div>{params.value}</div>) }
]
