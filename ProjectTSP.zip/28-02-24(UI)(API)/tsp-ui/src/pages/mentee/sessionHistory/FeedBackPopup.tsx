import { Link } from 'react-router-dom';
import Modal from '../../../components/modal/Modal';
 
interface DownloadMSFormProps {
  show: boolean;
  onHidePopup: () => void;
  downloadLink: string;
}
 
function FeedbackPopup({ show, onHidePopup, downloadLink }: DownloadMSFormProps) {
  return (
    <>
      {show && (
        <div className='download-ms-form-container1'>
          <Modal
            show={show}
            onHide={onHidePopup}
            centered={true}
            modalBody={
              <div className='modal-content1 d-flex justify-content-center'>
                <p>
                  Please click{' '}
 
                  <a href={downloadLink} target="_blank" rel="noopener noreferrer" download>
                    here
                  </a>{' '}
                  to download the MS form.
                </p>
              </div>
            }
           
          />
        </div>
 
      )}
    </>
  );
}
 
export default FeedbackPopup;