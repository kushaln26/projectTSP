import React, { ChangeEvent, useEffect, useState } from "react";
import Button from "../../../components/button/Button";
import Modal from "../../../components/modal/Modal";
import ReusableForm from '../../../components/form/Form';
import FormInput from '../../../components/input/Input';
import { SessionCompletionDetails } from "../../../utility/models/menteeSessionManagement/MenteeSessionHistoryRequest";
import { Validation } from '../../../utility/models/validation/Validation';
import FeedbackPopup from "./FeedBackPopup";
import MyOffCanvas from "../../../components/offCanvas/MyOffCanvas";
import "./MenteeSessionHistory.css";
import { MentorShipSessionManagement } from "../../../apis/MentorShipSessionManagement";
import ErrorMessage from "../../../components/error/ErrorMessage";
import { AnyAaaaRecord } from "dns";
import { EmptyInputValidate, IsContainsOnlyNumbers } from "../../../utility/validations/EmptyInputValidate";

interface SessionDetailsProps {
    showModal: boolean;
    onHide: () => void;
    setShowFeedBackPopup: () => void
    sessionId: number
    setMenteeHistSessionTableData: any
    menteeHistSessionTableData: any,
    setApiSuccess?: (message: string) => void
    setApiError?: (message: string) => void
    setIssSessionDetails: () => void;
}



function SessionDetailsPopUp({ setIssSessionDetails, setApiSuccess, setApiError, menteeHistSessionTableData, setMenteeHistSessionTableData, showModal, onHide, setShowFeedBackPopup, sessionId }: SessionDetailsProps) {
    console.log("inside popup sessionId", sessionId);

    const initialFormData: SessionCompletionDetails = { sessionId: sessionId, totalSessionCovered: 0, sessionDuration: 0, sessionTopic: "", startDate: '' }
    const [sessionCompletionDetails, setSessionCompletionDetails] = useState<SessionCompletionDetails>(initialFormData);
    const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" });

    useEffect(()=>{
        setSessionCompletionDetails(initialFormData)
    },[showModal])

    async function handleSubmit(formData: any) {
        setSessionCompletionDetails({ ...sessionCompletionDetails, sessionId: sessionId })
        const data = sessionCompletionDetails;
        const updatedData = { ...data, sessionId: sessionId }

        const sessionIdMessage = EmptyInputValidate(updatedData?.sessionId) || IsContainsOnlyNumbers(updatedData?.sessionId.toString());
        const totalSessionCoveredMessage = EmptyInputValidate(updatedData.totalSessionCovered) || IsContainsOnlyNumbers(updatedData?.totalSessionCovered.toString());
        const sessionDurationMessage = EmptyInputValidate(updatedData.sessionDuration) || IsContainsOnlyNumbers(updatedData?.sessionDuration.toString());
        const sessionTopicMessage = EmptyInputValidate(updatedData.sessionTopic) ;
        const startDateMessage = EmptyInputValidate(updatedData.startDate);

        if (sessionIdMessage && sessionIdMessage !== null) {
            setFeedback(() => ({ isValid: true, errorMessage: sessionIdMessage, inputFieldName: "sessionId" }))
        } else if (totalSessionCoveredMessage && totalSessionCoveredMessage !== null) {
            setFeedback(() => ({ isValid: true, errorMessage: totalSessionCoveredMessage, inputFieldName: "totalSessionCovered" }))
        } else if (sessionDurationMessage && sessionDurationMessage !== null) {
            setFeedback(() => ({ isValid: true, errorMessage: sessionDurationMessage, inputFieldName: "sessionDuration" }))
        } else if (sessionTopicMessage && sessionTopicMessage !== null) {
            setFeedback(() => ({ isValid: true, errorMessage: sessionTopicMessage, inputFieldName: "sessionTopic" }))
        } else if (startDateMessage && startDateMessage !== null) {
            setFeedback(() => ({ isValid: true, errorMessage: startDateMessage, inputFieldName: "startDate" }))
        } else {
            try {
                const promise = await MentorShipSessionManagement.menteeSessionStatusConclusion(updatedData)
                const response = await promise.data.payLoad
                if (setApiSuccess) {
                    setApiSuccess(response)
                    setIssSessionDetails();
                }
                onHide();
            } catch (error: any) {
                if (setApiError) {
                    setApiError(error.response.data.payLoad)
                }
            }
        }
        setSessionCompletionDetails(initialFormData)
    }

    const handleChange = (e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLSelectElement>) => {

        const { name, value } = e.target

        setSessionCompletionDetails(() => ({ ...sessionCompletionDetails, [e.target.name]: e.target.value }))
        let message;
        if (isValidFieldToCheckNumberInput(name)) {
            message = IsContainsOnlyNumbers(value.toString())
        }
        if (message) {
            setValidationMessage(message, name)
        }
    }

    const setValidationMessage = (message: string, name: string) => {
        if (message) {
            setFeedback(() => ({ isValid: true, errorMessage: message, inputFieldName: name }))
        }

    }

    const isValidFieldToCheckNumberInput = (name: string) => {
        switch (name) {
            case "sessionId": return true
            case "totalSessionCovered": return true
            case "sessionDuration": return true
            default: return false
        }
    }

    return (
        <>
            <MyOffCanvas
                show={showModal}
                onHide={onHide}
                canvasTitle="Please provide below Details"
                canvasBody={
                    <>
                        <ReusableForm onSubmit={handleSubmit} formData={sessionCompletionDetails} setFormData={setSessionCompletionDetails}>
                            <div className="m-auto ">
                                <FormInput feedback={feedback} setFeedback={setFeedback} label="Session Id" name="sessionId" type="text" value={sessionId} onChange={handleChange} disabled={true} />
                                <FormInput feedback={feedback} setFeedback={setFeedback} label="No. of Session Covered"
                                    name="totalSessionCovered"
                                    type="text"
                                    value={sessionCompletionDetails.totalSessionCovered===0?"":sessionCompletionDetails.totalSessionCovered}
                                    onChange={handleChange} />
                                <FormInput feedback={feedback} setFeedback={setFeedback} label="Time Duration for each session" name="sessionDuration" type="text" value={sessionCompletionDetails.sessionDuration===0?"":sessionCompletionDetails.sessionDuration} onChange={handleChange} />
                                <FormInput feedback={feedback} setFeedback={setFeedback} label="Topic Covered" name="sessionTopic" type="string" value={sessionCompletionDetails.sessionTopic} onChange={handleChange} />
                                <FormInput feedback={feedback} setFeedback={setFeedback} label="Session Start Date" name="startDate" type="date" value={sessionCompletionDetails.startDate} onChange={handleChange} />
                                <Button className='d-flex mt-4 SessionDetailsSubmit' type="submit" >Submit</Button>
                            </div>
                        </ReusableForm>
                    </>
                }
            />
        </>
    )
}

export default SessionDetailsPopUp;


