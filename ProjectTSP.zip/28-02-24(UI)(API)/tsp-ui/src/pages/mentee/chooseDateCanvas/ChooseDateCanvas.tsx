
import { ReactNode, useEffect, useState } from "react";
import * as React from 'react';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import DateTimePicker from "../../../components/DateAndTimePicker/DateAndTimePicker";
import "./ChooseDateCanvas.css";
import Input from "../../../components/input/Input";
import Form from 'react-bootstrap/Form';
import Button from "../../../components/button/Button";
import { teamsBlockRequestBody } from "../../../utility/models/menteeSessionManagement/MenteeSessionHistoryRequest";
import { MentorShipSessionManagement } from "../../../apis/MentorShipSessionManagement";
import formatDateToDateTime from "../../../utility/DateConversions/DateConversions";
import convertStringToDate from "../../../utility/DateConversions/StringToDateConversion";
import ResponseDisplay from "../../../components/responseMessage/ResponseMessage";


interface datesToChooseProps {
  date_1:string;
  date_2:string;
  sessionId:number;
  setShowChoosedateCanvas:(show:boolean)=>void
  setApiSuccess:(message:string)=>void
  setApiError:(message:string)=>void
}

const ChooseDate = ({ date_1, date_2, sessionId ,setShowChoosedateCanvas,setApiSuccess,setApiError}: datesToChooseProps) => {

  const [selectedDate, setSelectedDate] = React.useState<string>('');
  const [dates, setDates] = React.useState<string[]>([]); // State to manage the selected date
  const [teamsBlockRequest, setTeamsBlockRequest] = useState<teamsBlockRequestBody>({ sessionId: 0, sessionScheduledDate: 'option1' });
  const [selectedDate1, setSelectedDate1] = useState<Date | null>(null);
  const [selectedDate2, setSelectedDate2] = useState<Date | null>(null);
  const [isValidOrExpiredDate, setIsValidOrExpiredDate] = useState<{ optionOne: boolean, optionTwo: boolean }>({ optionOne: false, optionTwo: false })
  const [showSuccessResponse, setShowSuccessResponse] = useState<boolean>(false);
  const [showFailureResponse, setShowFailureResponse] = useState<boolean>(false);
  // const [apiErrors, setApiError] = useState<string>("");
  const [apiSuccessMessage, setApiSuccessMessage] = useState<string>("");



  const handleOptionChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedOption = event.target.value;
    setSelectedDate(selectedOption === 'option1' ? formatDateToDateTime(date_1) : formatDateToDateTime(date_2));
    setTeamsBlockRequest(prevState => ({ ...prevState, sessionScheduledDate: selectedOption, sessionId: sessionId }));
  };

  const handleBlockingCalender = async () => {
    try {
      const promise = await MentorShipSessionManagement.blockTeamsCalender({ sessionId: sessionId, sessionScheduledDate: selectedDate });
      const response = promise.data;
      if (response) {
        setShowSuccessResponse(true);
        setApiSuccess(response.payLoad);
      }
      setShowChoosedateCanvas(false)
    }
    catch (error: any) {
      setApiError(error?.response?.message);
      setShowChoosedateCanvas(false)
    }
  }

  useEffect(() => {
    const isValidDate1 = isValidDates(date_1);
    const isValidDate2 = isValidDates(date_2);

    setIsValidOrExpiredDate({
      optionOne: isValidDate1,
      optionTwo: isValidDate2
    });
  }, [date_1, date_2]);

  const isValidDates = (givenDate: string) => {
    const givenDateConverted = new Date(givenDate);
    const localdate = new Date()
    return givenDateConverted < localdate;
  }

  return (
    <div>
      <FormControl component="fieldset">
        <FormLabel component="legend" className="MentorsDates">Mentor suggested time & date for session​</FormLabel>
        <RadioGroup
          row
          aria-label="date"
          name="controlled-radio-buttons-group"
          value={teamsBlockRequest.sessionScheduledDate}
          onChange={handleOptionChange}
        >
          <FormControlLabel
            // key={index}
            value={"option1"}
            control={<Radio disabled={isValidOrExpiredDate.optionOne} />}
            label={<>
              <div className={`   ${isValidOrExpiredDate.optionOne ? "disabled"
                : ""
                }`}>
                <div>Option 1</div>
                <DateTimePicker
                  selected={convertStringToDate(date_1)}
                  onChange={() => { }}
                  disabled={true}
                  dateFormat={"dd-MM-yyyy HH:mm:ss"}
                />
              </div>
              {isValidOrExpiredDate.optionOne && <div className="text-danger mt-0">Given slot expired</div>}
            </>}
          />
          <FormControlLabel
            value={"option2"}
            control={<Radio disabled={isValidOrExpiredDate.optionTwo} />}
            label={<>
              <div className={`   ${isValidOrExpiredDate.optionTwo ? "disabled"
                : ""
                }`}>
                <div>Option 2</div>
                <DateTimePicker
                  selected={convertStringToDate(date_2)}
                  onChange={() => { }}
                  disabled={true}
                  dateFormat={"dd-MM-yyyy HH:mm:ss"}
                />
              </div>
                {isValidOrExpiredDate.optionTwo && <div className="text-danger">Given slot expired</div>}
              </>
            }
          />

        </RadioGroup>
        <Button
          className={`ResponseButtons   ${isValidOrExpiredDate.optionOne && isValidOrExpiredDate.optionTwo ? "disabled"
            : ""
            }`}
          type='button' onClick={handleBlockingCalender}>Submit</Button>

      </FormControl>

      {/*<ResponseDisplay
        className={"success"}
        responseData={apiSuccessMessage}
        showMessage={showSuccessResponse}
        onClose={() => {
          setShowSuccessResponse(false);
        }}
      />

      <ResponseDisplay
        className={"error"}
        responseData={apiErrors}
        showMessage={showFailureResponse}
        onClose={() => { setShowFailureResponse(false); }} />
      */}
    </div>
  );
}

export default ChooseDate;
