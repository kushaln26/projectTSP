import React from 'react'
import Button from '../../../components/button/Button'
import { Link } from 'react-router-dom'
import TabComponent from '../../../components/tabs/TabComponent'
import SearchMentor from '../searchMentor/SearchMentor'
import MenteeSessionHistory from '../sessionHistory/MenteeSessionHistory'
import { useSelector } from 'react-redux'
import { RootState } from '../../../store/rootReducer'
import UserProfile from '../../pagesCommon/userProfile/UserProfile'

function MenteeDashboard() {
  const user = useSelector((state: RootState) => state.user.user);
  const userEmailId:string = user ? user.emailId : ''; 
  const tabsProps = [
    {
      label: 'Profile',
      content: <div className="m-3"><UserProfile /></div>,
    },
    {
      label: 'Request for Mentorship Session',
      content: <div className="m-3"><SearchMentor/></div>,
    }, 
    {
      label: 'Mentorship Session History',
      content: <div className="m-3"><MenteeSessionHistory/></div>,
    }
  ]
  return (
    <>
      
      <div className='p-4'>
        <TabComponent dashboardOf={"Mentee"} tabs={tabsProps} />
      </div>
    </>

  )
}

export default MenteeDashboard