import { useEffect, useState } from 'react';
import axios from 'axios';
import { ArrayOfUserProjectExperienceDto, ViewProfileResponseModal } from '../../../utility/models/ViewProfile/viewProfileResponse';
import './ViewMenteeProfile.css';
import profile from '../../../images/noProfilePic2.png';
import badge from '../../../images/Badge.png'
import BackNavigate from '../../../components/backNavigation/backNavigate';
import userProfileApi from '../../../apis/userProfileManagement';
import MediaServiceApi from '../../../apis/MediaServiceManagement'
import DataTable from '../../../components/pagination/TablePage';
import { GridColDef } from '@mui/x-data-grid';
import { useNavigate } from 'react-router-dom';
import { ConvertToCamelCase } from '../../../utility/CaseConversions/CaseConversions';
import MediaServiceEndpoints from '../../../constants/MediaServiceEndpoints';


interface ViewProfileProps {
  userEmailId: string | undefined; 
}

export interface projectsTableHeader {
    id: number,
    projectName: string
    role: string ,
    roleDescription:string,
    duration: number,
    toolsAndFramework: string,
    client: string 
}

export interface ArrayOfMentorshipTableData {
  projectsTableDataValues: projectsTableHeader[]
}

const columns:GridColDef[] = [
  { field: 'projectName',headerName:'Project',flex:1 },
  { field: 'roleDescription', headerName: 'Description',flex:1 },
  { field: 'role', headerName: 'Role',flex:1  },
  { field: 'duration', headerName:'Duration',flex:1},
  { field: 'toolsAndFramework', headerName: 'Tools and Framework', flex:1  },
  { field: 'client', headerName:'Client',flex:1}
];

function ViewProfile({ userEmailId }: ViewProfileProps) {
  const initialUserProfileData: ViewProfileResponseModal = {
    emailId:"",
    empId:0,
    firstName:"",
    lastName:"",
    managerName:"",
    userGroup:"",
    businessUnit:"",
    professionalSummary:"",
    designation:"",
    totalExperience:0,
    profileStatus:false,
    skillCategory:"",
    managerMailId:"",
    technicalSkillList:[],
    userProjectExperienceList:[],
    domainList:[]
};
  const [userProfileData, setUserProfileData] = useState<ViewProfileResponseModal>(initialUserProfileData);
  const [projectTableData, setProjectTableData] = useState<ArrayOfUserProjectExperienceDto>({ projectsArray: [] });
  const navigate = useNavigate();
  const [profilePhoto, setProfilePhoto] = useState('');
  const [loading, setLoading] = useState(true);

  const generateProjectIds = (projects: projectsTableHeader[]) => {
    return projects.map((project, index) => ({
      ...project,
      projectId: index + 1
    }));
  };

  const fetchUserData = async () => {
    try {
      const promise = await userProfileApi.fetchUserProfileByMailId(userEmailId);
      const response = await promise.data.payLoad;
      const projectsWithIds = generateProjectIds(response.userProjectExperienceList);
      setUserProfileData({ ...response, userProjectExperienceList: projectsWithIds });
    }
    catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  const fetchProfilePhoto = async() =>
  {
    try {
      const response = await MediaServiceApi.getProfilePhoto(userEmailId);
      if (response.data) {
        setProfilePhoto(URL.createObjectURL(response.data));
      } else {
        setProfilePhoto(profile);
      }
      setLoading(false);
    } catch (error) {
      console.error('Error fetching user data:', error);
      setLoading(false);
    }
  }

  const handleUpdateClick = ()=>
  {
    navigate("/user-profile");
  }

  useEffect(() => {
    fetchUserData();
    fetchProfilePhoto();
    return () => {
      if (profilePhoto) {
        URL.revokeObjectURL(profilePhoto);
      }
    };
  }, [userEmailId]);

  if (!userProfileData) {
    return <div>Loading...</div>;
  }
  else{


return (

  <div className='Profile-Page'>
    <div className="user-profile">
      <div className='profile-head'>
        <div className="profile-picture profile-head_child">
          <div className="profile-picture profile-head_child">
              {loading ? (
                <p className='profile-pic-loading'>Loading...</p>
              ) : (
                <img className='profile-pic' src={profilePhoto || profile} alt="Profile" />
              )}
          </div>
          
        </div>
        <div className='profile-brief profile-head_child'>
          <div className='nameAndStatus'>
            <div style={{ display: 'flex',height:'50px' }}>
              <p className='profileName'>{userProfileData.firstName} {userProfileData.lastName}</p>
              <img src={badge} style={{ width: '35px', height: '35px',marginTop:'10px' }} />
            </div>
            <div style={{ display: 'flex' }}>
              <div className="userStatus">
                {userProfileData.profileStatus?
                 <><div className="onlineIcon"></div><div className="onlineStatus">Available</div></>:<><div className="offlineIcon"></div><div className="onlineStatus">Unavailable</div></>
                }
              </div>
              <p className="userGroup">{ConvertToCamelCase(userProfileData.userGroup)}</p>
            </div>
          </div>
          <p className='professionalSummary'>{userProfileData.professionalSummary}</p>
          <p className='updateProfile' onClick={handleUpdateClick}>Edit Profile</p>
        </div>
      </div>

      <div className='profile-details'>
        <div className='employeeInfo'>
          <p className='mainHeaders'>Employee Info</p>

          <div className='infoBlock'>
            <p className='infoHeaders'>Employee ID</p>
            <p className='infoResponse'>{userProfileData.empId}</p>
          </div>

          <div className='infoBlock'>
            <p className='infoHeaders'>Reports To</p>
            <p className='infoResponse'>{userProfileData.managerName}</p>
          </div>

          <div className='infoBlock'>
            <p className='infoHeaders'>Email Id</p>
            <p className="headline infoResponse">{userProfileData.emailId}</p>
          </div>

          <div className='infoBlock'>
            <p className='infoHeaders'> Designation </p>
            <p className='infoResponse'>{userProfileData.designation!==null ? userProfileData.designation : ''}</p>
          </div>
        </div>

        <p className='mainHeaders'>Experience and Skills</p>
        <div className='infoBlock'>
          <p className='infoHeaders'>Overall Experience</p>
          <p className='infoResponse'>{userProfileData.totalExperience!==null ? userProfileData.totalExperience : '' } years</p>
        </div>
        <div className="skills">
          <p className='infoHeaders'>Domain Experience</p>
          <ul >
            {userProfileData.domainList!==null && userProfileData.domainList.map((skill, index) => (
              <li key={index}><p className='infoHeaders'>{ConvertToCamelCase(skill)}</p></li>
            ))}
          </ul>
        </div>
        <div className="skills">
          <h6 className='infoHeaders'>Skills</h6>
          <ul >
            {userProfileData.technicalSkillList!==null && userProfileData.technicalSkillList.map((skill, index) => (
              <li key={index}><p className='infoHeaders'>{ConvertToCamelCase(skill)}</p></li>
            ))}
          </ul>
        </div>

        <p className='mainHeaders'>Key Projects</p>

        <div className='mt-2'>
            <DataTable 
            getRowId={(row) => row.projectId}
            columns={columns} 
            rows={userProfileData.userProjectExperienceList!==null ?userProfileData.userProjectExperienceList : []} 
            checkboxSelection={false}
              /> 
        </div>

      </div>
    </div>
  </div>

)};
};

export default ViewProfile;