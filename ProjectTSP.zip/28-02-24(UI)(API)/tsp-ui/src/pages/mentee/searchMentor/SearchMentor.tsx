import React, { ReactNode, useEffect, useState } from 'react'
import Input from '../../../components/input/Input';
import DataTable from '../../../components/pagination/TablePage';
import { MentorList } from '../../../utility/models/mentorListBySkillResponse/MentorListBySkillResponse';
import { MenteeSessionManagement } from '../../../apis/MenteeSessionManagement';
import Button from '../../../components/button/Button';
import { GridColDef } from '@mui/x-data-grid';
import userProfileApi from '../../../apis/userProfileManagement';
import { useSelector } from 'react-redux';
import { RootState } from '../../../store/rootReducer';
import Modal from '../../../components/modal/Modal';
import ViewProfile from '../ViewMenteeProfile/ViewProfile';
import Profile from '../../pagesCommon/profile/Profile';
import "./searchMentor.css"
import ErrorMessage from '../../../components/error/ErrorMessage';
import ResponseDisplay from '../../../components/responseMessage/ResponseMessage';

function SearchMentor() {
    const menteeEmailId = useSelector((state: RootState) => { return state.user.user?.emailId! });
    const [selectedMentorMailId, setSelectedMentorMailId] = useState<string>('')
    const [modalShow, setModalShow] = useState<boolean>(false)
    const [isRequested, setRequested] = useState<boolean>(false)
    const [skills, setSkills] = useState<string>("");
    const [mentorsData, setMentorsData] = useState<MentorList[]>([]);
    const [mentorProfile, setMentorProfile] = useState<MentorList | null>(null);
    const [tranformArrayMentors, setTranformArrayMentors] = useState<{ email: string, skills: string, mentorshipRequest: ReactNode }[]>([]);
    const [mentorsRequested, setMentorsRequested] = useState<string[]>([]);
    const [apiErrors, setApiError] = useState<string>("");
    const [apiSuccess, setApiSuccess] = useState<string>("");

    const isMentorRequested = (emailId: string): boolean => {
        return mentorsRequested.includes(emailId);
    }


    useEffect(() => {
        setTranformArrayMentors(transformArray)
    }, [mentorsData])

    const handleSubmit = async () => {
        
        setMentorsData([]);
        setApiError("")
        setApiSuccess("")
        try {
            const promise = await MenteeSessionManagement.fetchMentorsBySkill(skills)
            const response = await promise?.data;
            setMentorsData(response?.payLoad)
        } catch (error: any) {
            console.log(error?.response?.data?.payLoad);
            setApiError(error?.response?.data?.payLoad);
        }
    }

    const getProfileByEmailId = async (mentorEmailId: string) => {
        setSelectedMentorMailId(mentorEmailId);
    }

    const transformArray = mentorsData.map(mentor => {
        return {
            name: mentor.emailId.split("@")[0], email: mentor.emailId, skills: mentor.technicalSkillList.join(", "),
            mentorshipRequest: (<>
                <div className="mentorshipStatus ">
                    <button className={`p-2 span-button-styles`} onClick={() => { setModalShow(true); getProfileByEmailId(mentor.emailId) }}>View Profile</button>
                    <button disabled={isMentorRequested(mentor.emailId)} className='p-2 span-button-styles' onClick={() => { sendMentorRequest(mentor.emailId) }}>{isMentorRequested(mentor.emailId) ? "Requested" : "Mentorship"}</button>
                </div>
            </>)
        }
    })

    const columns: GridColDef[] = [
        { field: 'name', headerName: "Name", width: 300 },
        { field: 'email', headerName: "Email", width: 300 },
        { field: 'skills', headerName: "Skills", width: 300 },
        { field: 'mentorshipRequest', headerName: "Mentorship Status", width: 300, renderCell: (params) => (<div>{params.value}</div>) }
    ]

    const sendMentorRequest = async (mentorEmailId: string) => {
        setApiError("");
        setApiSuccess("")
        try {
            if (!skills || !mentorEmailId || !menteeEmailId) return;
            const request = {
                mentorEmailId: mentorEmailId,
                menteeEmailId: menteeEmailId,
                sessionTopic: skills
            };
            const promise = await MenteeSessionManagement.sendMentorRequest(request);
            const response = await promise.data
            setApiSuccess(response.payLoad)
            setMentorsRequested((prevRequestedMentors) => [...prevRequestedMentors, mentorEmailId]);
        }
        catch (error: any) {
            console.log(error.response?.data?.payLoad);
            setApiError(error.response?.data?.payLoad);
        }
    }

    const onClickOnClosePopup=()=>{
        setApiError("");
        setApiSuccess("");
    }
    return (
        <div>
            <div className='m-auto'>

                <div className=' mt-2 container '>
                    <div className='d-flex justify-content-between mb-4'>
                        <Input label="Skill name" name="skillName" type="text" value={skills} onChange={(e) => { setSkills(e.target.value); }} />
                        <div className='d-flex justify-content-end button-style-get-mentors' style={{ height: "6.5vh" }}><Button className='' type="submit" onClick={() => { setMentorsData([]); handleSubmit() }}>Get Mentors</Button></div>
                    </div>

                    {tranformArrayMentors.length > 0 &&
                        <div className=''>
                            <DataTable getRowId={(rows) => rows.email} columns={columns} rows={tranformArrayMentors} checkboxSelection={false} />
                        </div>
                    }
                    {apiSuccess &&
                        <ResponseDisplay responseData={apiSuccess} onClose={onClickOnClosePopup} showMessage={true} className={"success"} />
                    }
                    {apiErrors &&
                        <ResponseDisplay responseData={apiErrors} onClose={onClickOnClosePopup} showMessage={true} className={"error"} />
                    }
                </div>
            </div>
            <Modal
                show={modalShow}
                onHide={() => { setModalShow(false) }}
                backdrop="static"
                keyboard={true}
                fullscreen={true}
                modalBody={<ViewProfile userEmailId={selectedMentorMailId} />}
            />
        </div>
    )
}

export default SearchMentor