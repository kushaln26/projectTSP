import { Link } from "react-router-dom";
import Button from "../../../components/button/Button";
import ViewProfile from "../../mentee/ViewMenteeProfile/ViewProfile";
import MentorShipRequests from "../MentorShipRequests/MentorShipRequests";
import MentorSessionRecord from "../mentorSessionRecord/MentorSessionRecord";
import TabComponent from "../../../components/tabs/TabComponent";
import { useSelector } from "react-redux";
import { RootState } from "../../../store/rootReducer";
import UserProfile from "../../pagesCommon/userProfile/UserProfile";



function Mentor() {
  const user = useSelector((state: RootState) => state.user.user);
  const userEmailId:string = user ? user.emailId : ''; 

  const tabsProps = [
    {
      label: 'Profile',
      content: <div className="m-3"><UserProfile/></div>,
    },
    {
      label: 'Mentorship Session Requests',
      content: <div className="m-3"><MentorShipRequests/></div>,
    }, {
      label: 'Mentorship Session Record',
      content: <div className="m-3"><MentorSessionRecord/></div>,
    }
  ]

  return (
    <>
      
      <div className='p-4'>
        <TabComponent dashboardOf={"Mentor"} tabs={tabsProps} />
      </div>
    </>
  );
}

export default Mentor;
