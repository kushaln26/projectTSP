import React, { useState, useEffect, ReactNode } from 'react'
import { ArrayOfMentorshipResponse, mentorshipResponse } from '../../../utility/models/mentorshipResponse/mentorshipResponse';
import { MentorSessionRequestManagement } from '../../../apis/MentorSessionRequestManagement';
import { useSelector } from 'react-redux';
import axios, { AxiosResponse } from 'axios';
import { RootState } from '../../../store/rootReducer';
import CustomizedTables from '../../../components/table/reusableTable';
import { ColumnProps } from '../../../components/table/reusableTable';
import Pagination from '../../../components/pagination/Pagination';
import { useNavigate } from 'react-router-dom';
import Modal from '../../../components/modal/Modal';
import { Validation } from '../../../utility/models/validation/Validation';
import { Button as BootButton, Button } from 'react-bootstrap';
import FormInput from '../../../components/input/Input';
import { BASE_URL } from '../../../apis/baseUrl';
import Form from '../../../components/form/Form';
import MyOffCanvas from '../../../components/offCanvas/MyOffCanvas';
import "./Mentor.css"
import Loader from '../../../components/loader/Loader';

export interface mentorshipTableHeader {
    name: string;
    sessionTopic: string;
    menteeProfile: ReactNode;
    sessionStatus: ReactNode;
}

export interface ArrayOfMentorshipTableData {
    mentorshipTableDataValues: mentorshipTableHeader[]
}

export interface RejectionComment {
    sessionId: number,
    mentorComments: string
}

export default function MentorShipRequests1() {
    const [mentorshipResponseData, setMentorshipResponseData] = useState<ArrayOfMentorshipResponse>({ mentorshipRequests: [] });
    const [mentorshipTableData, setMentorshipTableData] = useState<ArrayOfMentorshipTableData>({ mentorshipTableDataValues: [] });
    const user = useSelector((state: RootState) => state.user.user);
    const [showModal, setShowModal] = useState(false);
    const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" });
    const [acceptClicked, setAcceptClicked] = useState(true);
    const [declineClicked, setDeclineClicked] = useState(true);
    const [loading, setLoading] = useState(false);

    const [rejectionComment, setRejectionComment] = useState<RejectionComment>({ sessionId: 0, mentorComments: "" });

    const [apiErrors, setApiError] = useState<string>("");
    const [apiSuccessMessage, setApiSuccessMessage] = useState<string>("");

    const emailId = user?.emailId;
    const navigate = useNavigate();

    const handleViewProfile = (mailId: string) => {
        navigate('/ViewMenteeProfile');
    }

    const handleResponseClick = (selectedSessionId: number) => {
        setShowModal(true);
        setRejectionComment(prevState => ({ ...prevState, sessionId: selectedSessionId }));
    };

 
    const handleAccept = async () => {
        
    }

    const handleDecline = async () => {
        setAcceptClicked(false);
    }

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setRejectionComment({ ...rejectionComment, [e.target.name]: e.target.value })
    }


    const handleSubmit = async () => {
       
    }

    useEffect(() => {

        const fetchData = async () => {
            try {
                
                const promise = await MentorSessionRequestManagement.getMentorSessionRequest(user?.emailId);
                const response = await promise.data;
                
                setMentorshipResponseData((prevMentorshipResponseData) => ({ ...prevMentorshipResponseData, mentorshipRequests: response.payLoad }));
               

            } catch (error) {
                console.error("Error fetching mentorship requests:", error);
            }
        };

        fetchData();
    }, []);

    useEffect(() => {
        const transformedData = mentorshipResponseData.mentorshipRequests.map((response) => ({
            name: response.name,
            sessionTopic: response.sessionTopic,
            menteeProfile: (<>
                <Button onClick={() => { handleViewProfile(response.menteeMailId) }} type="button">View Profile</Button>
            </>),
            sessionStatus: (
                <>
                    {
                        response.mentorApproval === false &&
                        <Button onClick={() => handleResponseClick(response.sessionId)} type="button" >
                            Response to Session Request
                        </Button>
                    }
                    {
                        response.mentorApproval === true &&
                        <Button type="button" disabled={true}>
                            Approved
                        </Button>
                    }
                </>
            )
        }));
        setMentorshipTableData((prevMentorshipTableData) => ({ ...prevMentorshipTableData, mentorshipTableDataValues: transformedData }));
    }, [mentorshipResponseData]);

    const columns: ColumnProps[] = [
        {
            key: 'name',
            title: 'Name'
        },
        {
            key: 'sessionTopic',
            title: 'Session Topic'
        },
        {
            key: 'menteeProfile',
            title: 'View Profile'
        },
        {
            key: 'sessionStatus',
            title: 'Session Status'
        }
    ];

    return (
        <>
            <h1 className='d-flex justify-content-center '>Mentorship Requests</h1>
            <div className='d-flex justify-content-center '>
                <Pagination data={mentorshipTableData.mentorshipTableDataValues} columns={columns} />
            </div>

            
            <MyOffCanvas
            show= {showModal}
            onHide={() => { setShowModal(false) }}
            canvasTitle="Response to Mentorship"
            canvasBody=
            {
                <>
                 <Form onSubmit={handleSubmit} formData={rejectionComment} setFormData={setRejectionComment}>
                    <FormInput feedback={feedback} setFeedback={setFeedback} label="Comments" name="mentorComments" type="text" value={rejectionComment.mentorComments} onChange={handleChange} />
                        <div className='d-flex mt-3'>
                        <Button className="ResponseButtons Approve" type="button" onClick={() => { handleAccept() }}>Approve</Button>
                        <Button className="ResponseButtons Decline" type='submit'>Reject</Button>
                        </div>
                </Form>
        
                </> 
            }
            />
        </>
    )
}


