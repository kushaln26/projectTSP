import { Link } from 'react-router-dom';
import Modal from '../../../components/modal/Modal';
import './DownloadMSForm.css'

interface DownloadMSFormProps {
  show: boolean;
  onHide: () => void;
  downloadLink: string;
}

function DownloadMSForm({ show, onHide, downloadLink }: DownloadMSFormProps) {
  return (
    <>
      {show && (

        <Modal
          modalBodyStyles={"custom-body"}
          modalHeaderStyles={"custom-header"}
          modalFooterStyles={"custom-footer"}
          modalContainerStyles={"custom-container"}
          centered={true}
          show={show}
          onHide={onHide}
          backdrop="static"
          keyboard={true}
          modalBody={
            <div className='modal-content1'>

              <p>Please provide your mentorship session feedback {' '}<br></br>

                <a href={downloadLink} target="_blank" rel="noopener noreferrer" download>
                  click-here
                </a>{' '}
              </p>


            </div>

          }
        />


      )}
    </>
  );
}

export default DownloadMSForm;
