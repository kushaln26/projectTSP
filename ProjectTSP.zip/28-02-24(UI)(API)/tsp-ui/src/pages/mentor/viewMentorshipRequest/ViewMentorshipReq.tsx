import CustomizedTables, { ColumnProps } from '../../../components/table/reusableTable';
import { mentorshipResponse } from '../../../utility/models/mentorshipResponse/mentorshipResponse';
import { useLocation } from 'react-router-dom';



export default function MentorshipRequestHeader(): JSX.Element {
   
    const location = useLocation();

    const { mentorshipTableData }: { mentorshipTableData: mentorshipResponse[] } = location.state;
   
    

    const columns: ColumnProps[] = [
        {
            key: 'name',
            title: 'Name'
        },
        {
            key: 'sessionTopic',
            title: 'Session Topic'
        },
        {
            key: 'menteeMailId',
            title: 'Mentee Mail Id'
        },
       
    ];

    return (
        <CustomizedTables data={mentorshipTableData} columns={columns} />
    );
}
