import React, { useEffect, useState } from 'react';
import axios from 'axios';
import * as yup from 'yup';
import { BASE_URL } from '../../../apis/baseUrl';
import { ArchiveRequest } from '../../../utility/models/archive/ArchiveRequest'
import { GenerateExcelReport } from '../../../utility/validations/GenerateExcelReport';
import DateRange from '../../../components/dateRange/DateRange';
import { useSelector } from 'react-redux';
import { RootState } from '../../../store/rootReducer';
import { GridColDef } from '@mui/x-data-grid';
import { MentorSessionRequestManagement } from '../../../apis/MentorSessionRequestManagement';
import DataTable from '../../../components/pagination/TablePage';
import { ArrayOfSessionHistoryOfMentorResponse, SessionHistoryOfMentorRequest } from '../../../utility/models/MentorDashboard/MentorshipHistory.tsx/SessionHistoryForMentorRequest';
import { ConvertToCamelCase } from '../../../utility/CaseConversions/CaseConversions';
import Loader from '../../../components/loader/Loader';
import { EmptyInputValidate } from '../../../utility/validations/EmptyInputValidate';
import { Validation } from '../../../utility/models/validation/Validation';


export interface SessionHistoryOfMentorTableData {
  // sessionId:number
  mentorShipSession: number,
  topic: string,
  menteeName: string,
  date: string,
  requestStatus: string,
  sessionStatus: string
}

export interface ArrayOfSessionHistoryOfMentorTableData {
  mentorshipHistoryTableDataValues: SessionHistoryOfMentorTableData[]
}

function MentorSessionRecord() {

  const mailId = useSelector((state: RootState) => state.user.user?.emailId);
  const [sessionDateRange, setSessionDateRange] = useState<SessionHistoryOfMentorRequest>({ localStartDate: "", localEndDate: "", mailId: mailId })
  const [sessionHistoryOfMentorResponse, setSessionHistoryOfMentorResponse] = useState<ArrayOfSessionHistoryOfMentorResponse>({ mentorshipHistoryRequests: [] })
  const [sessionHistoryDataOfMentorForTable, setSessionHistoryDataOfMentorForTable] = useState<ArrayOfSessionHistoryOfMentorTableData>({ mentorshipHistoryTableDataValues: [] })
  const [apiErrors, setApiError] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" })
  const [recordsAvailable, setRecordsAvailable] = useState<boolean>(true)


  const columns: GridColDef[] = [
    { field: 'mentorShipSession', headerName: "Mentorship Session", flex: 1 },
    { field: 'topic', headerName: "Topic", flex: 1 },
    { field: 'menteeName', headerName: "Mentee Name", flex: 1 },
    { field: 'date', headerName: "Date", flex: 1 },
    { field: 'requestStatus', headerName: "Request Status", flex: 1 },
    { field: 'sessionStatus', headerName: "Session Status", flex: 1 }
  ]
  useEffect(() => {
    const transformedData = sessionHistoryOfMentorResponse.mentorshipHistoryRequests.map((response) => ({
      mentorShipSession: response.sessionId,
      topic: response.sessionTopic,
      menteeName: response.menteeName,
      date: response.updatedDate,
      requestStatus: response.requestStatus,
      sessionStatus: response.sessionStatus
    }));
    setSessionHistoryDataOfMentorForTable((prevMentorshipTableData) => ({ ...prevMentorshipTableData, mentorshipHistoryTableDataValues: transformedData }));
  }, [sessionHistoryOfMentorResponse.mentorshipHistoryRequests])

  const handleSubmit = async (data: SessionHistoryOfMentorRequest) => {

    const localStartDate = EmptyInputValidate(sessionDateRange.localStartDate);
    const localEndDate = EmptyInputValidate(sessionDateRange.localEndDate);
    if (localStartDate && localStartDate !== null) {
      setFeedback(() => ({ isValid: true, errorMessage: localStartDate, inputFieldName: "localStartDate" }))
    }
    else if (localEndDate && localEndDate !== null) {
      setFeedback(() => ({ isValid: true, errorMessage: localEndDate, inputFieldName: "localEndDate" }))
    }
    else {
      setLoading(true);
      setRecordsAvailable(true)
      try {

        const promise = await MentorSessionRequestManagement.fetchSessionRecordHistory(data);
        const response = await promise.data;

        if (response.payLoad.length <= 0) {
          setRecordsAvailable(false)
        }


        setSessionHistoryOfMentorResponse((prevMentorshipResponseData) => ({ ...prevMentorshipResponseData, mentorshipHistoryRequests: response.payLoad }));
        const requestStatus = ConvertToCamelCase(response.requestStatus);
        const sessionStatus = ConvertToCamelCase(response.sessionStatus);
        ConvertToCamelCase(response.sessionStatus);

      }
      catch (error) {
        console.error('Error downloading file:', error);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <>
      <DateRange
        includeDropdown={false}
        handleSubmission={handleSubmit}
        formData={sessionDateRange}
        setFormData={setSessionDateRange}
        feedback={feedback}
        setFeedback={setFeedback}

      />
      <Loader loading={loading} />
      {sessionHistoryDataOfMentorForTable.mentorshipHistoryTableDataValues.length > 0 && (
        <div className='mt-5'>
          <DataTable
            sortingField={"mentorShipSession"}
            getRowId={(rows: SessionHistoryOfMentorTableData) => rows.mentorShipSession}
            columns={columns}
            rows={sessionHistoryDataOfMentorForTable.mentorshipHistoryTableDataValues}
            checkboxSelection={false} />
        </div>
      )}

      {!recordsAvailable &&
        <>
          <div className='mt-5 text-danger'>
            There are no record available
          </div>
        </>
      }

    </>
  );
};

export default MentorSessionRecord;