import { Button } from "react-bootstrap";
import Form from "../../../components/form/Form"
import FormInput from '../../../components/input/Input';
import { ApprovalPostRequest } from "./MentorShipRequests";
import { useEffect, useState } from "react";
import { Validation } from "../../../utility/models/validation/Validation";
import { MentorSessionRequestManagement } from "../../../apis/MentorSessionRequestManagement";
import { AxiosResponse } from "axios";
import { useNavigate } from "react-router-dom";
import MyOffCanvas from "../../../components/offCanvas/MyOffCanvas";
import DateTimePicker from "../../../components/DateAndTimePicker/DateAndTimePicker";
import formatDateToDateTime from "../../../utility/DateConversions/DateConversions";
import ResponseDisplay from "../../../components/responseMessage/ResponseMessage";
import { EmptyInputValidate } from "../../../utility/validations/EmptyInputValidate";
 
interface requestApprovalProps
{
    approvalData:ApprovalPostRequest;
    hideApproveOrRejectModal: () => void;
    givingDatesModal:boolean;
    setGivingDatesModal:(isShow:boolean) => void;
}
 
function MentorShipRequestApproval({approvalData,hideApproveOrRejectModal,givingDatesModal, setGivingDatesModal}:requestApprovalProps)
{
    const navigate = useNavigate();
    const [commentData,setCommentData ] = useState<string>('');
    const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" });
    const [approvalDataNew,setApprovalDataNew] = useState<ApprovalPostRequest>(approvalData);
    const [apiErrors, setApiError] = useState<string>("");
    const [apiSuccessMessage, setApiSuccessMessage] = useState<string>("");
    const [disableAccept, setDisableAccept] = useState<boolean>(false);
    const [disableDecline, setDisableDecline] = useState<boolean>(false);
    const [showModal, setShowModal]= useState<boolean>(false);
    const [successBottomModal,setSuccessBottomModal] = useState<boolean>(false);
    const [showFailureBottomModal, setFailureShowBottomModal] = useState<boolean>(false);
    const [errorMessage1, setErrorMessage1] = useState('');
    const [errorMessage2, setErrorMessage2] = useState('');
    const [submitErrorMessage, setSubmitErrorMessage] = useState('');

    const [selectedDate, setSelectedDate] = useState<Date | null>(new Date());

    const handleCommentChange = (e: React.ChangeEvent<HTMLInputElement>) =>
    {
        setCommentData(e.target.value);
        const { name, value } = e.target;
        setApprovalDataNew({ ...approvalDataNew, [name]: value });
    };
 
    useEffect(() => {
        if (approvalDataNew.actionBy === "MENTOR_ACCEPT" && approvalDataNew.optionDate1 && approvalDataNew.optionDate2) {
            sendMentorApprovalRequest();
        }
        else if(approvalDataNew.actionBy === "MENTOR_REJECT")
        {
            console.log("mentor rejection:: ",);
            sendMentorApprovalRequest();
        }
    }, [approvalDataNew.actionBy,approvalData.optionDate1,approvalData.optionDate2]);
 
    const handleAccept = () =>
    {
        setApprovalDataNew({...approvalDataNew , approvalstatus: true,actionBy:'MENTOR_ACCEPT'});
        
        setGivingDatesModal(true);
        setDisableAccept(true);
        setDisableDecline(true);
    }
 
    const handleReject = () =>
    {
        const comments = EmptyInputValidate(approvalDataNew.comments);

        if (comments && comments !== null) {
            setFeedback(() => ({ isValid: true, errorMessage: comments, inputFieldName: "comments" }))
        }
        else{
        setApprovalDataNew({...approvalDataNew , approvalstatus: false,actionBy:'MENTOR_REJECT'});
        console.log("approvalData New inside handleReject::"+approvalDataNew);
        setDisableAccept(true);
        setDisableDecline(true);
        hideApproveOrRejectModal();
        }
    }
 
    const sendMentorApprovalRequest = async () => {
        try
        {
            const promise: AxiosResponse = await MentorSessionRequestManagement.mentorShipApproval(approvalDataNew);
            const response: any = await promise.data;
            
            if(response)
            {
                setSuccessBottomModal(true);
                setApiSuccessMessage(response.payLoad);
            }
        }
        catch (error: any) {
            
            setFailureShowBottomModal(true);
            setApiError(error?.message);
        }
    }

    
    
    const handleDateChange1 = (date: Date) => {
        const now = new Date();
            if (date < now) {
            setErrorMessage1('Please select a future date and time.');
            // Reset to current date and time
            } 
            else {
            setErrorMessage1('');
            
            const formattedDate = formatDateToDateTime(date);
            setApprovalDataNew({ ...approvalDataNew, optionDate1:date ? formattedDate : '' });
            console.log("approval date :: ",approvalDataNew.optionDate1);
            }
        };
    
    const handleDateChange2 = (date: Date) => {
        const now = new Date();
        if (date < now) {
          setErrorMessage2('Please select a future date and time.');
           // Reset to current date and time
        } else {
          setErrorMessage2('');
          
        
        const formattedDate = formatDateToDateTime(date);
        setApprovalDataNew({ ...approvalDataNew, optionDate2: date ? formattedDate : '' });
        console.log("approval date :: ",approvalDataNew.optionDate2);
        }
    };

    const handleApproveWithDates = () =>
    {
        if (!errorMessage1 && !errorMessage2) {
        sendMentorApprovalRequest();
        setSubmitErrorMessage('');
        }
        else
        {
            setSubmitErrorMessage('Please ensure both dates are valid.');
            console.error('One or both dates are invalid');
        }
        // hideApproveOrRejectModal();
        // setGivingDatesModal(false)
    }

    const handleCloseGivingDatesModal = () => {
        setGivingDatesModal(false)
    }

    return(
        <>
                
                <FormInput feedback={feedback} setFeedback={setFeedback} label="Comments" name="comments" type="text" value={commentData} onChange={handleCommentChange} />
                <div className="d-flex mt-3"><span className="requiredValueStar pt-0 mr-2">*</span><p className="declineDisclaimer">If your wish to decline please provide comment</p></div>
                <div className='d-flex mt-1'>
                    <Button className="ResponseButtons Approve" type="button" onClick={handleAccept} disabled={disableAccept}>Approve</Button>
                    <Button className="ResponseButtons Decline" type="submit" onClick={handleReject} disabled={disableDecline}>Reject</Button>
                </div>
                
            <MyOffCanvas
                show={givingDatesModal}
                onHide={handleCloseGivingDatesModal}
                canvasTitle={
                    <>
                        <div className="CanvasHeader" >Response to Mentorship</div>
                        <div className="CanvasPara">Please provide date and time for approval</div>
                    </>
                }
                canvasBody=
                {
                    <>
                            <p className="DateOption">Option 1</p>


                            <DateTimePicker
                                selected={new Date()}
                                onChange={handleDateChange1}
                                dateFormat={"dd-MM-yyyy HH:mm:ss"}
                                minDate={new Date() }
                                disableTimeSelection={false}
                                disabled={false}
                                timeFormat="HH:mm:ss"
                                timeIntervals={30}
                                placeholderText="dd-MM-yyyy HH:mm:ss"
                                
                            />
                             {errorMessage1 && <div style={{ color: 'red' }}>{errorMessage1}</div>}

                            <p className="DateOption">Option 2</p>


                            <DateTimePicker
                                selected={new Date()}
                                onChange={handleDateChange2}
                                dateFormat={"dd-MM-yyyy HH:mm:ss"}
                                minDate={new Date()}
                                disableTimeSelection={false}
                                disabled={false}
                                timeFormat="HH:mm:ss"
                                timeIntervals={30}
                                placeholderText="dd-MM-yyyy HH:mm:ss"
                                
                            />          
                             {errorMessage2 && <div style={{ color: 'red' }}>{errorMessage2}</div>}
                             {submitErrorMessage && <div style={{ color: 'red' }}>{submitErrorMessage}</div>}
                            <Button className="ResponseButtons" type='button' onClick={handleApproveWithDates}>Submit</Button>
                                
                    </>
                }
            />
            <ResponseDisplay
                    className={"success"}
                    responseData={apiSuccessMessage}
                    showMessage={successBottomModal}
                    navigateTo={'/mentor-dashboard'}
                    onClose={() => { setSuccessBottomModal(false);  hideApproveOrRejectModal();
                        setGivingDatesModal(false)}} 
            />

                <ResponseDisplay
                    className={"error"}
                    responseData={apiErrors}
                    showMessage={showFailureBottomModal}
                    navigateTo={'/mentor-dashboard'}
                    onClose={() => { setFailureShowBottomModal(false);hideApproveOrRejectModal();
                        setGivingDatesModal(false) }} />
        </>
    )
}
 
export default MentorShipRequestApproval;