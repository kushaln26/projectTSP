import React, { ChangeEvent, useEffect, useState } from "react";
import Input from "../../../components/input/Input";
import DropdownSelection from "../../../components/dropdown/dropdownSelection";
import { Validation } from "../../../utility/models/validation/Validation";
import { StaticData, UpdateProfileStaticData } from "../../../utility/models/staticData/staticData";
import { Button, Col, Row } from "react-bootstrap";
import "./UserProfile.css";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../../store/rootReducer";
import { UserProfileDetails, ViewProfileResponseModal, UserProjectExperience, UserModel } from "../../../utility/models/ViewProfile/viewProfileResponse";
import userProfileApi from "../../../apis/userProfileManagement";
import { setUserProfile } from "../../../store/userProfileReducer/userProfileAction";
import MultiSelect from "../../../components/multiSelectDropDown/multiSelectDropDown";
import { Avatar } from "@mui/material";
import MediaServiceApi from "../../../apis/MediaServiceManagement";
import profile from '../../../images/noProfilePic2.png';
import { projectsTableHeader } from "../../mentee/ViewMenteeProfile/ViewMenteeProfile";
import { MultiValue } from "react-select";
import Form from "../../../components/form/Form";
import { EmptyInputValidate } from "../../../utility/validations/EmptyInputValidate";
import { staticDataFetch } from "../../../apis/staticDataFetch";
import { MasterDataResponse } from "../../../utility/models/masterData/MasterDataResponse";
import ResponseDisplay from "../../../components/responseMessage/ResponseMessage";

interface FileState {
  file: File | null;
}

function UserProfile() {

  const initialUserProfileData: UserModel = {
    emailId: "",
    empId: 0,
    firstName: "",
    lastName: "",
    managerName: "",
    userGroup: "",
    professionalSummary: "",
    designation:"",
    totalExperience: 0,
    profileStatus: false,
    skillCategory: "",
    managerMailId: "",
    technicalSkillList: [],
    userProjectExperienceList: [],
    domainList: []
  }

  const newProject: UserProjectExperience = {
    id: 0,
    projectName: "",
    role: "",
    roleDescription: "",
    duration: 0,
    toolsAndFramework: "",
    client: ""
  };

  const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "", });
  const [dropDownData, setDropDownData] = useState<UpdateProfileStaticData>({ technicalskills: [], domains: [], skillcategories: [] });
  const [projects, setProjects] = useState<UserProjectExperience[]>([]);
  const [updateProfileFormData, setUpdateProfileFormData] = useState<UserModel>(initialUserProfileData);

  const [profilePhoto, setProfilePhoto] = useState('');
  const [loading, setLoading] = useState(true);
  const [selectedTechnicalSkills, setSelectedTechnicalSkills] = useState<MultiValue<{ value: string; label: string }>[]>([]);
  const [selectedDomains, setSelectedDomains] = useState<{ value: string; label: string }[]>([]);
  const [selectedStatus, setSelectedStatus] = useState<string>('');

  const [fileState, setFileState] = useState<FileState>({
    file: null
  });
  const [apiErrors, setApiError] = useState<string>("");
  const [apiSuccessMessage, setApiSuccessMessage] = useState<string>("");
  const [showSuccessBottomModal, setSuccessShowBottomModal] = useState<boolean>(false);
  const [showFailureBottomModal, setFailureShowBottomModal] = useState<boolean>(false);
  // const [userProfileData, setUserProfileData] = useState<UpdateProfileResponseModal>(initialUserProfileData);

  const user = useSelector((state: RootState) => state.user.user);
  const bu = user?.businessUnit;

  useEffect(() => {
    if (user?.emailId) {
      fetchUserData();
      fetchProfilePhoto();
    }
  }, []);


  useEffect(() => {
    setUpdateProfileFormData(prevData => ({
      ...prevData,
      userProjectExperienceList: projects
    }));
  }, [projects]);

  useEffect(()=>{
    console.log("updateProfileFormData>>",updateProfileFormData);
    
  },[updateProfileFormData])

  const fetchUserData = async () => {
    try {
      console.log("inside fetch profile data");
      const promise = await userProfileApi.fetchUserProfileByMailId(user?.emailId);
      const response = await promise.data.payLoad;
      console.log("response>>",response);
      
      const projectsWithIds :UserProjectExperience[]= generateProjectIds(response.userProjectExperienceList??[]);
      setProjects(projectsWithIds)
      // setUpdateProfileFormData({ ...response, userProjectExperienceList: projectsWithIds });
      // console.log("profile Data fetched :: ", response);
      setUpdateProfileFormData({...response, businessUnit: user?.businessUnit, userProjectExperienceList: projectsWithIds});
      console.log("setUpdateProfileFormData:: ", updateProfileFormData);

      // setUpdateProfileFormData((prevData) => ({ ...prevData, businessUnit: user?.businessUnit }));
    }
    catch (error) {
      console.error('Error fetching user data:', error);
    }
  };

  const fetchProfilePhoto = async () => {
    try {
      const response = await MediaServiceApi.getProfilePhoto(user?.emailId);
      
      // if (response.data) {
      //   setPreviewUrl(URL.createObjectURL(response.data));
      // } 
      // else {
      //   setPreviewUrl();
      // }
      
      if (response.status === 200 && response.data) {
        setPreviewUrl(URL.createObjectURL(response.data));
      } else {
        setPreviewUrl(profile);
    }
    setLoading(false);


    } 
    catch (error) {
      console.error('Error fetching profile Photo:', error);
      setLoading(false);
      setPreviewUrl(profile);
    }
  }

  const dispatch = useDispatch();
  const userProfile = useSelector(
    (state: RootState) => state.userProfile.userProfile
  );

  useEffect(() => {
    dropdownSelectionItems();
  }, [])

  const transformedArray = (data: Array<any>) => {
    if (!data) return []; 
    else{
    return data.map(item => ({
      label: item,
      value: item
    }))
  }
  }
  const setData = async (promise: any) => {
    const response = await promise;
    const res: MasterDataResponse = await response.data.payLoad;
    console.log("technical Skills and domain data:: ", res);
    const technicalskills = res.technicalskills;
    setDropDownData((prevDropDownData) => ({ ...prevDropDownData, technicalskills: transformedArray(technicalskills) }))
    const domains = res.domains;

    setDropDownData((prevDropDownData) => ({ ...prevDropDownData, domains: transformedArray(domains) }))
    const skillcategories = res.skillcategories;
    setDropDownData((prevDropDownData) => ({ ...prevDropDownData, skillcategories: transformedArray(skillcategories) }))
  }

  const dropdownSelectionItems = async () => {
    try {
      const promise = await staticDataFetch.getAllProfileMasterData();
      console.log("dropdowns of technical skills", promise);
      await setData(promise);
    } catch (error: any) {
      setApiError(error?.message)
    }
  }

  const handleAddProject = () => {
    setProjects([...projects, newProject]); // Add a new project to the projects array
  };

  const handleRemoveProject = (indexToRemove: number) => {
    setProjects(prevProjects => prevProjects.filter((_, index) => index !== indexToRemove));
  };


  const handleSubmit = async () => {
    try {
      const promise = await userProfileApi.userProfileUpdate(updateProfileFormData);
      const responseData = await promise.data;
      const responseDataPayload = await promise.data.payLoad;

      if (responseData) {
        setSuccessShowBottomModal(true);
        setApiSuccessMessage(responseData.message);
        console.log("success Bottom modal::", showSuccessBottomModal);
      }
      dispatch(setUserProfile(responseDataPayload));
    }
    catch (error: any) {
      const message = error.response?.data?.payLoad;
      if (typeof message === 'string') {
        setFailureShowBottomModal(true);
        setApiError(message);
      }
      else {
        setFailureShowBottomModal(true);
        setApiError(message?.createdBy || message?.emailId);
      }
    }
  };

  const [selectedSkills, setSelectedSkills] = useState<{ value: string; label: string }[]>([]);
  const [imageUrl, setImageUrl] = useState(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const handleRemoveImage = () => {
    setImageUrl(imageUrl);
  }

  const handleUploadPhoto = async (event: any) => {
    const photoFile = event.target.files[0];

    if (event.target.files && event.target.files[0]) {
      const selectedFile: File = event.target.files[0];
      setFileState({ file: selectedFile });
    }
    if (photoFile) {
      const reader = new FileReader();
      reader.onload = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(photoFile);

      UploadPhotoApi(photoFile);
    }
  };

  const UploadPhotoApi = async (file: File) => {
    try {
      const formData = new FormData();
      formData.append('file', file);
      const response = await MediaServiceApi.updateProfilePhoto(user?.emailId, formData);
      if (!response) {
        throw new Error('Failed to upload image');
      }
      const data = await response.data;
      const uploadedImageUrl = data.imageUrl;
      setImageUrl(uploadedImageUrl);
      if (response) {
        setSuccessShowBottomModal(true);
        setApiSuccessMessage(response?.data?.message);
      }
    }
    catch (error) {
      console.error('Error uploading image:', error);
    }
  }



  const generateProjectIds = (projects: projectsTableHeader[]) => {
    return projects.map((project, index) => ({
      ...project,
      projectId: index + 1
    }));
  };


  const technicalSkillsOptions: { value: string; label: string }[] = Object.values(userProfile?.technicalSkill ? userProfile.technicalSkill.join(', ') : '').map(skill => ({
    value: skill,
    label: skill,
  }));


  const handleTechnicalSkillChange = (selectedOptions: any
  ) => {
    const selectedSkills = selectedOptions.map((option: { value: any; }) => option.value);
    setUpdateProfileFormData((prevData) => ({
      ...prevData,
      technicalSkillList: selectedSkills,
    }));
    console.log("technical skills updated handleTechnicalSkillChange:: ", updateProfileFormData);
  };


  const handleDomainChange = (selectedOptions: any) => {
    const selectedDomainSkills = selectedOptions.map((option: { value: any; }) => option.value);
    setSelectedDomains(selectedOptions);
    setUpdateProfileFormData((prevData) => ({
      ...prevData,
      domainList: selectedDomainSkills,
    }));
    console.log("technical skills updated handleTechnicalSkillChange:: ", updateProfileFormData);
  };

  const handleStatusChange = (e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLSelectElement>) => {
    const selectedValue = e.target.value;
    setSelectedStatus(selectedValue);
  };

  useEffect(() => {
    const newValue = selectedStatus === "available" ? true : false;
    setUpdateProfileFormData(prevFormData => ({
      ...prevFormData,
      profileStatus: newValue
    }));
    console.log("setUpdateProfileFormData status value  :; ", updateProfileFormData);
  }, [selectedStatus]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement> | React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    // Check if value is null and assign empty string instead
    const sanitizedValue = value !== null ? value : '';
    setUpdateProfileFormData({ ...updateProfileFormData, [name]: sanitizedValue });
    console.log("value of field:: ", updateProfileFormData);
  }

  const handleProjectChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;

    const index = parseInt(name.split("-")[1]);

    const newProjects = [...projects];
    newProjects[index] = { ...newProjects[index], [name.split("-")[0]]: value };

    console.log("updatedProjects::", newProjects);
    
    if(updateProfileFormData.userProjectExperienceList!=null){
    const updatedUserProjectExperienceList = [
      ...updateProfileFormData.userProjectExperienceList ?? [], ...newProjects
    ];
    

    const updatedProfileInfo = {
      ...updateProfileFormData,
      userProjectExperienceList: updatedUserProjectExperienceList
    };

    
    console.log("updatedUserProjectExperienceList", updatedUserProjectExperienceList);
    console.log("updatedProfileInfo", updatedProfileInfo);

    setProjects(newProjects);
    console.log("updatedProjects::", newProjects);

    setUpdateProfileFormData(updatedProfileInfo);


    console.log("userProfile with new project Details", updateProfileFormData.userProjectExperienceList);
  }
  };


  const onCloseResponseMessage = () => {
    setApiError("");
    setApiSuccessMessage("")
    setSuccessShowBottomModal(false);
    setFailureShowBottomModal(false)
    fetchUserData();
    fetchProfilePhoto();
  }

  const onCloseFailureResponseMessage = () => {
    setApiError("");
    setApiSuccessMessage("")
    setFailureShowBottomModal(false);
    // fetchUserData();
    // fetchProfilePhoto();
  }


  return (
    <>
      <Form onSubmit={handleSubmit}
        formData={updateProfileFormData}
        setFormData={setUpdateProfileFormData}
      >
        <div className="d-flex flex-wrap justify-content-front">
          <div style={{ position: 'relative' }}>
            <Row>
              {previewUrl && (
                <Col>
                  <img src={previewUrl} alt="Preview" className="profileImage" style={{ width: 100, height: 100 }} />
                </Col>
              )}
            </Row>
            <Row>
              <Col>
                <label htmlFor="upload-photo" className="btn_upload_photo">
                  Update the Photo
                  <input
                    id="upload-photo"
                    type="file"
                    accept="image/*"
                    onChange={handleUploadPhoto}
                    style={{ display: 'none' }} 
                  />
                </label>
              </Col>
            </Row>
          </div>
          <div>
            <div className="mb-2 p-2">
              <div className="heading_label_styles heading-align d-flex justify-content-start">
                Personal Info
              </div>
              <Row>
                <Col xs={6}>
                  <Input
                    feedback={feedback}
                    setFeedback={setFeedback}
                    label="Professional Summary"
                    name="professionalSummary"
                    type="text"
                    value={updateProfileFormData?.professionalSummary ?? ""}
                    onChange={handleChange}
                    isRequired
                  />
                </Col>
              </Row>
              <Row>
                <Col xs={4}>
                  <Input
                    feedback={feedback}
                    setFeedback={setFeedback}
                    label="First Name"
                    name="firstName"
                    type="text"
                    value={updateProfileFormData.firstName}
                    onChange={handleChange}
                    isRequired
                  />
                </Col>
                <Col xs={4}>
                  <Input
                    feedback={feedback}
                    setFeedback={setFeedback}
                    label="Last Name"
                    name="lastName"
                    type="text"
                    value={updateProfileFormData.lastName}
                    onChange={handleChange}
                    isRequired
                  />
                </Col>
                <Col xs={4}>


                  <DropdownSelection feedback={feedback} setFeedback={setFeedback}
                    isRequired={true}
                    label="Status"
                    name="status"
                    value={selectedStatus}
                    options={
                      [{ value: "available", label: "available" },
                      { value: "unavailable", label: "unavailable" }
                      ]}
                    onChange={handleStatusChange} />
                </Col>
              </Row>
            </div>

            <div className="mb-2 p-2">
              <div className="heading_label_styles heading-align d-flex justify-content-start">
                Employee Info
              </div>
              <Row>
                <Col xs={4}>
                  <Input
                    feedback={feedback}
                    setFeedback={setFeedback}
                    label="Employee ID"
                    name="employeeId"
                    type="text"
                    value={updateProfileFormData.empId}
                    onChange={handleChange}
                    readOnly
                    isRequired
                  />
                </Col>
                <Col xs={4}>
                  <Input
                    feedback={feedback}
                    setFeedback={setFeedback}
                    label="Reports to"
                    name="reportsTo"
                    type="text"
                    value={updateProfileFormData?.managerName ?? ""}
                    onChange={handleChange}
                    readOnly
                    isRequired
                  />
                </Col>
                <Col xs={4}>
                  <Input
                    feedback={feedback}
                    setFeedback={setFeedback}
                    label="Email ID"
                    name="emailId"
                    type="email"
                    value={updateProfileFormData.emailId}
                    onChange={handleChange}
                    readOnly
                    isRequired
                  />
                </Col>
                <Col xs={4}>
                  <Input
                    feedback={feedback}
                    setFeedback={setFeedback}
                    label="Designation"
                    name="designation"
                    type="text"
                    value={updateProfileFormData?.designation ?? ""}
                    onChange={handleChange}
                    isRequired
                  />
                </Col>
              </Row>
            </div>

            <div className="mb-2 p-2">
              <div className="heading_label_styles heading-align d-flex justify-content-start">
                Experience And Skills
              </div>

              <Row>
                <Col xs={4}>
                  <Input
                    feedback={feedback}
                    setFeedback={setFeedback}
                    label="Overall experience"
                    name="totalExperience"
                    type="number"
                    value={updateProfileFormData?.totalExperience ?? 0}
                    onChange={handleChange}
                    isRequired
                  />
                </Col>
              </Row>
              <Row>
                <Col xs={4}>
                  <DropdownSelection feedback={feedback} setFeedback={setFeedback}
                    isRequired={true}
                    label="SkillCategory"
                    name="skillCategory"
                    value={updateProfileFormData?.skillCategory ?? ""}
                    options={dropDownData?.skillcategories}
                    onChange={handleChange} />
                </Col>
              </Row>

              <Row>
                <Col xs={6}>
                  <MultiSelect
                    label="Domain Experience"
                    name="domainExperience"
                    options={dropDownData?.domains}
                    value={transformedArray(updateProfileFormData?.domainList ?? [])}
                    isRequired={true}
                    onChange={handleDomainChange}
                  />
                </Col>

                <Col xs={6}>
                  <MultiSelect
                    label="Technical Skills"
                    name="technicalSkills"
                    options={dropDownData?.technicalskills}
                    value={transformedArray(updateProfileFormData?.technicalSkillList ?? [])}
                    isRequired={true}
                    onChange={handleTechnicalSkillChange}
                  />
                </Col>
              </Row>
            </div>

            <div className="mb-2 p-2">
              <div className="d-flex justify-content-between heading_label_styles">
                <div>Key Projects</div>
                <div
                  className="add-project-tag-styles"
                  onClick={() => {
                    handleAddProject();
                  }}
                >
                  + Add Project
                </div>
              </div>
              {projects.map((project, index) => (
                <div key={index} className='d-flex mt-1 flex-wrap justify-content-end'>
                  <button
                    className="btn-close"
                    onClick={() => handleRemoveProject(index)} // Call handleRemoveProject with index
                    aria-label="Close"
                  ></button>
                  <Row key={index}>
                    <Col xs={4}>
                      <Input
                        feedback={feedback}
                        setFeedback={setFeedback}
                        label={`Project ${index + 1}`}
                        name={`projectName-${index}`} // Use index in the name for dynamic naming
                        type="text"
                        value={project.projectName}
                        onChange={handleProjectChange}
                        isRequired
                      />
                    </Col>
                    <Col xs={4}>
                      <Input
                        feedback={feedback}
                        setFeedback={setFeedback}
                        label="Description"
                        name={`roleDescription-${index}`} // Use index in the name for dynamic naming
                        type="text"
                        value={project.roleDescription}
                        onChange={handleProjectChange}
                        isRequired
                      />
                    </Col>
                    <Col xs={4}>
                      <Input
                        feedback={feedback}
                        setFeedback={setFeedback}
                        label="Role"
                        name={`role-${index}`} // Use index in the name for dynamic naming
                        type="text"
                        value={project.role}
                        onChange={handleProjectChange}
                        isRequired
                      />
                    </Col>
                    <Col xs={4}>
                      <Input
                        feedback={feedback}
                        setFeedback={setFeedback}
                        label="Duration"
                        name={`duration-${index}`} // Use index in the name for dynamic naming
                        type="text"
                        value={project.duration}
                        onChange={handleProjectChange}
                        isRequired
                      />
                    </Col>
                    <Col xs={4}>
                      <Input
                        feedback={feedback}
                        setFeedback={setFeedback}
                        label="Tools and Framework"
                        name={`toolsAndFramework-${index}`} // Use index in the name for dynamic naming
                        type="text"
                        value={project.toolsAndFramework}
                        onChange={handleProjectChange}
                        isRequired
                      />
                    </Col>
                    <Col xs={4}>
                      <Input
                        feedback={feedback}
                        setFeedback={setFeedback}
                        label="Client"
                        name={`client-${index}`} // Use index in the name for dynamic naming
                        type="text"
                        value={project.client}
                        onChange={handleProjectChange}
                        isRequired
                      />
                    </Col>
                  </Row>
                </div>
              ))}
            </div>

            <div className='d-flex mt-5 flex-wrap justify-content'>
              <Button type="submit">Save Changes</Button>
            </div>
          </div>
        </div>
      </Form>

      <ResponseDisplay
        className={"success"}
        responseData={apiSuccessMessage}
        showMessage={showSuccessBottomModal}
        onClose={onCloseResponseMessage}
      />

      <ResponseDisplay
        className={"error"}
        responseData={apiErrors}
        showMessage={showFailureBottomModal}
        onClose={onCloseFailureResponseMessage}
      />
    </>
  );
}
export default UserProfile;

