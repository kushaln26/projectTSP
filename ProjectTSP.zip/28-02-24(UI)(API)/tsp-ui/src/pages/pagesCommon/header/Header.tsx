import React, { MouseEventHandler, useEffect, useRef, useState } from 'react';
import { Navbar, Container, Nav, Button, Offcanvas } from 'react-bootstrap';
import './header.css';
import Modal from '../../../components/modal/Modal';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../../../store/rootReducer';
import { clearUser } from '../../../store/userReducer/userActions';
import { useNavigate } from 'react-router-dom'
import logout from '../../../images/logout_filled_2.png';
import turnOff from '../../../images/turn-off.png'
import WhiteLogout from '../../../images/logoutIcon3.png';
import profile from '../../../images/profile2.png';
import tspLogo from '../../../images/white_TSP_logo.png';
import DropdownSelection from '../../../components/dropdown/dropdownSelection';
import { AnyARecord } from 'dns';
import OffCanvas from '../../../components/offCanvas/OffCanvas';
import Overlay from 'react-bootstrap/Overlay';
import Popover from 'react-bootstrap/Popover';
import ReusableForm from '../../../components/form/Form';
import { AxiosResponse } from 'axios';
import userProfileApi from '../../../apis/userProfileManagement';
import { UserProfileStatus } from '../../../utility/models/userProfile/UserProfilemodel';
import Switch from '@mui/material/Switch';
import MyOffCanvas from '../../../components/offCanvas/MyOffCanvas';



function Header() {
  const user = useSelector((state: RootState) => state.user.user);

  const [showProfileModal, setShowProfileModal] = useState(false);
  const [clickInfo, setClickInfo] = useState({ target: null });
  const [status, setStatus] = useState<UserProfileStatus>({ emailId: user?.emailId, status: 'available' });
  const [apiError, setApiError] = useState<string>('');
  const ref = useRef(null);
  const [checked, setChecked] = useState(false);
  const dispatch = useDispatch()
  const navigate = useNavigate()


  const handleLogin = () => {
    dispatch(clearUser());
    navigate('/login')
  }


  const handleProfileClick = (event: { target: any; }) => {
    setShowProfileModal(true);
  };

  const handleCloseProfileModal = () => {
    setShowProfileModal(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const isChecked = !checked;
    setStatus({ ...status, [e.target.name]: isChecked ? 'unavailable' : 'available' });
    setChecked(isChecked);
    handleSubmit(status);
  };

  const handleRouting = () => {
    const userGroupName = user?.userGroup
    if(user === null)
    {
      navigate('/login')
    }
    else{
    switch (userGroupName) {
      case "ADMIN": navigate('/admin');
        break;

      case "MENTOR": navigate('/mentor-dashboard');
        break;

      case "MENTEE ": navigate('/mentee-dashboard');
        break;

      case "MANAGER": navigate('/manager-dashboard');
        break;
      // default: navigate(0);
    }
  }
  }

  const handleSubmit = async (status: UserProfileStatus) => {
    try {
      
      const promise: AxiosResponse = await userProfileApi.userStatusSet(status);
      const res: string = await promise.data;
    }
    catch (error: any) {
      console.log(error);
      const message = error.response?.data?.payLoad;
      if (typeof message === 'string') {
        setApiError(message);
      }
    }
  }

  return (
    <>
      <Navbar expand="lg" className="custom-navbar">
        <Container className='navContainer'>
          <Navbar.Brand className='textProps' onClick={() => { handleRouting() }}>
            <img src={tspLogo} width="80" height="30" className="d-inline-block align-top" alt="Your Logo" />
          </Navbar.Brand>

          
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="miniProfileRight">

              {user?.emailId &&
                <>
                  <div ref={ref} className="userInfoAndLogout">
                    <div className="userInfo">
                      <Navbar.Brand className='userFirstNameHeader textProps'> {user?.firstName} {user?.lastName} </Navbar.Brand>
                
                      <br/>
                     
                    </div>
                    <Nav.Link className='textProps left-right'>
                      <img src={turnOff} width="22" height="22" className="d-inline-block align-top" alt="Your Logo" onClick={handleLogin} />
                    </Nav.Link>
                    
                     
                  </div>
                </>
              }

            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </>
  );
};

export default Header;