import React from 'react'
import BackNavigate from '../../../components/backNavigation/backNavigate'
import profile from '../../../images/profile_grey.jpg'
import badge from '../../../images/Badge.png'
import { UserProfileDetailmodel } from '../../../utility/models/userProfile/UserProfilemodel'
import { useLocation } from 'react-router-dom'
import { MentorList } from '../../../utility/models/mentorListBySkillResponse/MentorListBySkillResponse'


interface ProfileProps {
  profileData: MentorList | null;
}


function Profile({ profileData }: ProfileProps) {
  return (
    <div className='Profile-Page'>
      <div className="user-profile">
        <div className='profile-head'>
          <div className="profile-picture profile-head_child">
            <img src={profile} />
          </div>
          <div className='profile-brief profile-head_child'>
            <div className='nameAndStatus'>
              <div style={{ display: 'flex' }}>
                <h3>{profileData?.emailId.split("@")[0]}</h3>
                <img src={badge} style={{ width: '40px', height: '40px' }} />
              </div>
              <div style={{ display: 'flex' }}>
                <div className="userStatus">
                  <div className="onlineIcon"></div>
                  <div className="onlineStatus">{profileData?.profileStatus ? "Active" : "Inactive"}</div>
                </div>
              </div>
            </div>
            <p>{profileData?.professionalSummary}</p>
          </div>
        </div>

        <div className='profile-details'>
          <div className='employeeInfo'>
            <h5>Employee Info</h5>
            <h6>Reports To</h6>
            <p>{profileData?.managerMailId}</p>
            <h6>Email Id</h6>
            <p className="headline">{profileData?.emailId}</p>
            <h6> Designation </h6>
            <p>{profileData?.designation}</p>
          </div>

          <h5>Experience and Skills</h5>
          <div className="skills">
            <h6>Skills</h6>
            <ul >
              {profileData?.technicalSkillList?.map((skill, index) => (
                <li key={index}>{skill}</li>
              ))}
            </ul>
          </div>

          <h6>Key Projects</h6>
          <table className='projectsDisplay'>
            <thead className='projectHeader'>
              <tr>
                <th className='projectHead'>Project</th>
                <th className='projectHead'>Description</th>
                <th className='projectHead'>Role</th>
                <th className='projectHead'>Duration</th>
                <th className='projectHead'>Tools And Framework</th>
                <th className='projectHead'>Client</th>
              </tr>
            </thead>
            <tbody>
              {profileData?.userProjectExperienceList?.map((project, index) => (
                <tr className='projectRow' key={index}>
                  <td className='projectData'>{project.projectName}</td>
                  <td className='projectData'>{project.roleDescription}</td>
                  <td className='projectData'>{project.role}</td>
                  <td className='projectData'>{project.duration}</td>
                  <td className='projectData'>{project.toolsAndFramework}</td>
                  <td className='projectData'>{project.client}</td>
                </tr>
              ))}
            </tbody>
          </table>

        </div>
      </div>
    </div>
  )
}

export default Profile