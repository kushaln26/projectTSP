import React, { useState } from 'react';
import './login.css';
import Form from '../../../components/form/Form';
import FormInput from '../../../components/input/Input';
import Button from '../../../components/button/Button';
import userApi from '../../../apis/userManagement';
import { useDispatch } from 'react-redux';
import { setUser } from '../../../store/userReducer/userActions';
import { Link, useNavigate } from 'react-router-dom'
import { LoginUser } from '../../../utility/models/login/LoginUser';
import { Validation } from '../../../utility/models/validation/Validation';
import { EmptyInputValidate } from '../../../utility/validations/EmptyInputValidate';
import ErrorMessage from '../../../components/error/ErrorMessage';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import { Image } from 'react-bootstrap';
import { LoginResponseObject } from '../../../utility/models/login/LoginResponseObject';
import Loader from '../../../components/loader/Loader'; 

function Login() {
  const initialFormData = { emailId: '', password: '' }
  const [loginCredentials, setFormData] = useState<LoginUser>(initialFormData);
  const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" });
  const [apiErrors, setApiError] = useState<string>("");

  const [loading, setLoading] = useState(false); 

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogin = async (loginCredentials: LoginUser) => {

    setLoading(true); 

    const mailIdMessage = EmptyInputValidate(loginCredentials.emailId);
    const passwordMessage = EmptyInputValidate(loginCredentials.password)
    if (mailIdMessage && mailIdMessage !== null) {
      setFeedback((feedback) => ({ isValid: true, errorMessage: mailIdMessage, inputFieldName: "emailId" }))
    }
    else if (passwordMessage && passwordMessage !== null) {
      setFeedback(() => ({ isValid: true, errorMessage: passwordMessage, inputFieldName: "password" }))
    }
    else {
      try {
        const promise = await userApi.loginUser(loginCredentials);
        console.log("promise>>>", promise);
        const response = await promise.data;
        console.log("response>>>", response);
        const loginResponse: LoginResponseObject = response.payLoad;

        const token = promise.data.token;
        localStorage.setItem('token',token);

        dispatch(setUser(loginResponse));
        if (loginResponse.passwordReset) {
          navigate('/reset');
        } else {
          switch (loginResponse.userGroup.toLocaleLowerCase()) {
            case "admin": navigate('/admin');
              break;
            case "mentor": navigate('/mentor-dashboard');
              break;
            case "mentee": navigate('/mentee-dashboard');
              break;
            case "manager": navigate('/manager-dashboard');
              break;
            default: navigate('/dashboard');
          }
        }
      } catch (error: any) {
        const message = error.response?.data?.payLoad;
        console.log("error", error);

        if (typeof message === 'string') {
          setApiError(message);
        } else {
          setApiError(message?.password);
        }
      } finally {
        setLoading(false); 
      }
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...loginCredentials, [e.target.name]: e.target.value })
    setApiError("");
  }

  return (
    <>
      <Container fluid>
        <Row className='p-0 d-flex ' lg={12} >
          <Col xs={12} md={6} className='p-0' >
            <Image rounded style={{ height: '100vh', width: '100vw' }} src="bluescreen.png" fluid />
          </Col>
          <Col xs={12} md={6} className='' >
            <div className='d-flex flex-column align-items-center'>

              <Row style={{ height: "90vh" }}>
                <div className='d-flex flex-column justify-content-center'>

                  <div>
                    <div> {apiErrors && <ErrorMessage message={apiErrors} />}</div>
                    <div className='d-flex flex-column align-items-start p-3 pb-0'>
                      <span className='login-hello_text font-color-family'>Hello !</span>
                      <span className='login-wellcome_tag_text font-color-family'>Welcome to Talent Share Portal</span>
                    </div>
                    <div className='p-0'>
                      <Form onSubmit={handleLogin} formData={loginCredentials} setFormData={setFormData}>
                        <div className='input-field-1'>
                          <FormInput feedback={feedback} className='userEmail-styles' setFeedback={setFeedback} label="User Email" name="emailId" type="text" value={loginCredentials.emailId} onChange={handleChange} />
                        </div>
                        <div className='input-field-2'>
                          <FormInput feedback={feedback} className='password-styles' setFeedback={setFeedback} label="Password" name="password" type="password" value={loginCredentials.password} onChange={handleChange} />
                        </div>
                        <div className='d-flex justify-content mt-5 '>
                          <Button type="submit" className='login-button'>Login</Button>
                          <Link to="/forgot-password" ><a type="button" className='p-1 forgot-password-link' style={{ alignItems: 'center' }}>Forgot password</a></Link>
                        </div>
                      </Form>
                    </div>
                  </div>
                </div>
              </Row>
              <Row >
                <div className='p-0 m-0 '>
                  <Image className='p-0 m-0 maveric-logo' src="mavericLogo.png" />
                  <p className='p-0 m-0 font-color-family terms-style'>Copyrights © 2023. Maveric Systems Limited | <a href='https://maveric-systems.com/privacy-policy/' target='_blank'>Privacy Policy</a></p>
                </div>
              </Row>
            </div>
          </Col>
        </Row>
      </Container>
    </>
  );
}

export default Login;
