import React, { useState } from 'react';
import Form from '../../../components/form/Form';
import Button from '../../../components/button/Button';
import FormInput from '../../../components/input/Input';
import './changePassword.css';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../../../store/rootReducer';
import userApi from '../../../apis/userManagement';
import { ResetResponseObject } from '../../../utility/models/changePassword/ChangePasswordResponseObject';
import { clearUser } from '../../../store/userReducer/userActions';
import { AxiosResponse } from 'axios';
import { ChangePasswordModel } from '../../../utility/models/changePassword/ChangePasswordModel';
import { EmptyInputValidate } from '../../../utility/validations/EmptyInputValidate';
import { ValidatePassword } from '../../../utility/validations/ValidatePassword';
import { Validation } from '../../../utility/models/validation/Validation';
import { Col, Container, Row } from 'react-bootstrap';
import { Image } from 'react-bootstrap';
import ErrorMessage from '../../../components/error/ErrorMessage';
import ResponseDisplay from '../../../components/responseMessage/ResponseMessage';
import Loader from '../../../components/loader/Loader'; 


function ChangePassword() {
    const user = useSelector((state: RootState) => state.user.user);
    const initialFormData = {
        emailId: user?.emailId,
        newPassword: '',
        confirmPassword: '',
    };
    const navigate = useNavigate();
    const dispatch = useDispatch()
    const [apiErrors, setApiError] = useState<string>("")
    const [apiSuccessMessage, setApiSuccessMessage] = useState<string>("")
    const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" });
    const [showResponseBottomModal, setShowResponseBottomModal] = useState<boolean>(false);
    const [loading, setLoading] = useState(false);

    const [newPasswordDetails, setNewPasswordDetails] = useState<ChangePasswordModel>(initialFormData);

    const handleResetSubmit = async (formData: ChangePasswordModel) => {
        setLoading(true); 
        const newPasswordEmpty = EmptyInputValidate(formData.newPassword);
        const confirmPasswordEmpty = EmptyInputValidate(formData.confirmPassword);

        if (newPasswordEmpty || confirmPasswordEmpty) {
            if (newPasswordEmpty && newPasswordEmpty !== null) {
                setFeedback((feedback) => ({ isValid: true, errorMessage: newPasswordEmpty, inputFieldName: "newPassword" }));
            }
            else if (confirmPasswordEmpty && confirmPasswordEmpty !== null) {
                setFeedback(() => ({ isValid: true, errorMessage: confirmPasswordEmpty, inputFieldName: "confirmPassword" }));
            }
            return;
        }

        const passwordError = ValidatePassword(formData.newPassword);
        if (passwordError) {
            setFeedback({ isValid: true, errorMessage: passwordError, inputFieldName: 'newPassword' });
            return;
        }

        if (formData.newPassword !== formData.confirmPassword) {
            setFeedback({ isValid: true, errorMessage: 'Passwords not matching', inputFieldName: 'confirmPassword' });
            return;
        }

        if (user?.emailId) {
            setNewPasswordDetails({
                ...formData,
                emailId: user.emailId,
            });
        }
        try {
            const promise: AxiosResponse = await userApi.changePassword(newPasswordDetails);
            const response: ResetResponseObject | any = await promise.data;
            if(response){
                setShowResponseBottomModal(true); 
                setApiSuccessMessage(response.payLoad);
            }
            
            dispatch(clearUser());
            
        } catch (error: any) {
            
        }finally {
            setLoading(false); 
          }

    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setNewPasswordDetails({
            ...newPasswordDetails,
            [e.target.name]: e.target.value,
        });
    };



    return (
        <>
        <Loader loading={loading} />
            <Container fluid>
                <Row className='p-0 d-flex ' lg={12} >
                    <Col xs={12} md={6} className='p-0' ><Image rounded style={{ height: '100vh', width: '100vw' }} src="bluescreen.png" fluid /></Col>
                    <Col xs={12} md={6} className='' >
                        <div className='d-flex flex-column align-items-center'>
                            <Row style={{ height: "90vh" }}>
                                <div className='d-flex flex-column justify-content-center'>
                                    <div>
                                        <div> {apiErrors && <ErrorMessage message={apiErrors} />}</div>
                                        <div className='d-flex flex-column align-items-start p-3 pb-0 password-heading'>
                                            <h5>Please set your password</h5>
                                        </div>
                                        <div className='p-1'>
                                            <Form onSubmit={handleResetSubmit} formData={newPasswordDetails} setFormData={setNewPasswordDetails}>
                                                <div className='newPassword-styles'>
                                                    <FormInput feedback={feedback} className='password-font-size' setFeedback={setFeedback} label='Password' name='newPassword' type='password' value={newPasswordDetails.newPassword} onChange={handleChange} />
                                                </div>
                                                <div className='confirmPassword-styles'>
                                                    <FormInput feedback={feedback} className='password-font-size' setFeedback={setFeedback} label='Confirm Password' name='confirmPassword' type='password' value={newPasswordDetails.confirmPassword} onChange={handleChange} />
                                                </div>
                                                <div className='custom-button'><Button className='button-inside' type='submit'>Submit</Button></div>
                                            </Form>
                                        </div>
                                    </div>
                                </div>
                            </Row>
                            <Row >
                                <div className='p-0 m-0 '>
                                    <Image className='p-0 m-0 maveric-logo' src="mavericLogo.png" />
                                    <p className='p-0 m-0 font-color-family terms-style'>Copyrights © 2023. Maveric Systems Limited | <a href='https://maveric-systems.com/privacy-policy/' target='_blank'>Privacy Policy</a></p>
                                </div>
                            </Row>
                        </div>
                    </Col>
                </Row>
            </Container>
            <ResponseDisplay
                responseData={apiSuccessMessage}
                className={'success'}
                showMessage={showResponseBottomModal}
                onClose={() => setShowResponseBottomModal(false)}
                navigateTo={'/login'} />
        </>

    );
}

export default ChangePassword;
