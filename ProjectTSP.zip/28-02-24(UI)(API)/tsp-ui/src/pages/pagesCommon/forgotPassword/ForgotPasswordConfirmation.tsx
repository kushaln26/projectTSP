import React from 'react';
import { Button } from 'react-bootstrap';
import Modal from '../../../components/modal/Modal';
import { useNavigate } from 'react-router-dom';

interface ForgotPasswordConfirmationProps {
  showModal: boolean;
  onHide: () => void;
  emailId: string;
}

function ForgotPasswordConfirmation({
  showModal,
  onHide,
  emailId,
}: ForgotPasswordConfirmationProps) {

  const navigate = useNavigate();
  return (
    <>
      <Modal
        show={showModal}
        onHide={onHide}
        backdrop="static"
        keyboard={true}
        modalTitle="Forget Password Confirmation"
        modalBody=
        {
          <>
            <div className="alert alert-info">We have reset your password for the first login and its shared to your mail ID, please change your own password once you login to the portal.</div>
          </>
        }
        modalFooter=
        {
          <>
            <Button variant="primary" onClick={() => { onHide(); navigate('/login'); }}>OK</Button>
          </>
        }
      />
    </>
  );
}

export default ForgotPasswordConfirmation;
