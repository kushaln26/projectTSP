import React, { useState } from 'react';
import './forgotPassword.css';
import Loader from '../../../components/loader/Loader'; 
import Form from '../../../components/form/Form';
import FormInput from '../../../components/input/Input';
import Button from '../../../components/button/Button';
import { useNavigate } from 'react-router-dom'
import ForgotPasswordConfirmation from './ForgotPasswordConfirmation';
import { EmptyInputValidate } from '../../../utility/validations/EmptyInputValidate';
import { Validation } from '../../../utility/models/validation/Validation';
import ErrorMessage from '../../../components/error/ErrorMessage';
import userApi from '../../../apis/userManagement';
import { Container, Row, Col } from 'react-bootstrap';
import { Image } from 'react-bootstrap';
import ResponseDisplay from '../../../components/responseMessage/ResponseMessage';


const ForgotPassword = () => {

  const [email, setEmail] = useState<string>('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [feedback, setFeedback] = useState<Validation>({ isValid: false, errorMessage: "", inputFieldName: "" });
  const [apiErrors, setApiError] = useState<string>("");
  const [EmailId, setEmailId] = useState<string>("");
  const [showResponseBottomModal,setShowResponseBottomModal] = useState<boolean>(false);
  const [responseMessage, setResponseMessage] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false); 

  const navigate = useNavigate();

  const forgotPassword = async (emailId: string) => {
    setLoading(true); 
    try {
      const promise = await userApi.forgotPassword(emailId);
      const response = await promise.data.payLoad;

      if (response) {
        setShowResponseBottomModal(true);
        setResponseMessage(promise.data.message);
      }
    } catch (error: any) {
      const message = error.response?.data?.payLoad;
      if (typeof message === 'string') {
        setApiError(message);
      }
    } finally {
      setLoading(false); 
    }
  };

  const handleSubmit = async () => {
    const mailIdMessage = EmptyInputValidate(email);
    if (mailIdMessage && mailIdMessage !== null) {
      setFeedback((feedback) => ({ isValid: true, errorMessage: mailIdMessage, inputFieldName: "email" }))
    } else {
      forgotPassword(email);
    }
  };

  return (
    <>
    
    <Container fluid>
      <Row className='p-0 d-flex ' lg={12} >
        <Col xs={12} md={6} className='p-0' ><Image rounded style={{ height: '100vh', width: '100vw' }} src="bluescreen.png" fluid /></Col>
        <Col xs={12} md={6} className='' >
          <div className='d-flex flex-column align-items-center'>
            <Row style={{ height: "90vh" }}>
              <div className='d-flex flex-column justify-content-center'>
              <Loader loading={loading} /> 
                <div>
                  <div> {apiErrors && <ErrorMessage message={apiErrors} />}</div>
                  <div className='d-flex flex-column align-items-start pb-2'>
                    <span className='forgot_password_text font-color-family'>Forgot Your Password?</span>
                    <span className='enter_usernam_tag_text font-color-family'>Enter your username and we will send </span>
                    <span className='enter_usernam_tag_text font-color-family'> you a link to reset your password. </span>
                  </div>
                  <div className='feedback-form-label'>
                  <FormInput feedback={feedback} className='feedback-form' setFeedback={setFeedback} label='User name' name='email' type='email' value={email} onChange={(e) => { setEmail(e.target.value) }} />

                  </div>
                  <div className='customContinueButton'><Button className="btn btn-primary btn-sm continue-button" type='button' onClick={handleSubmit}>Continue</Button></div>
                </div>
              </div>
            </Row>
            <Row >
              <div className='p-0 m-0 '>
                <Image className='p-0 m-0 maveric-logo' src="mavericLogo.png" />
                <p className='p-0 m-0 font-color-family terms-style'>Copyrights © 2023. Maveric Systems Limited | <a href='https://maveric-systems.com/privacy-policy/' target='_blank'>Privacy Policy</a></p>
              </div>
            </Row>
          </div>
        </Col>
      </Row>
    </Container>
     <ResponseDisplay  
          responseData = {responseMessage}
          className={'success'} 
          showMessage={showResponseBottomModal}
          onClose={()=>{setShowResponseBottomModal(false)}} 
          navigateTo={'/login'}/>
    
    </>

  );
};

export default ForgotPassword;
