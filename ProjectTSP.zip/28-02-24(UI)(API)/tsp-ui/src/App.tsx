import './App.css';
import { BrowserRouter as Router } from 'react-router-dom'
import { Provider } from 'react-redux';
import { store, persistor } from './store/store';
import 'bootstrap/dist/css/bootstrap.min.css';
import CustomeRoutes from './routing/CustomeRoutes';
import { PersistGate } from 'redux-persist/integration/react';
import localforage from 'localforage';
import { LoginResponseObject } from './utility/models/login/LoginResponseObject';
import { rehydrateUser } from './store/userReducer/userActions';


function App() {

 
  const retrievePersistedUserData = async () => {
    try {
      const persistedUserData = await localforage.getItem('root'); 
      return (persistedUserData as { user?: { user: LoginResponseObject } })?.user?.user || null;
    } catch (error) {
      console.error('Error retrieving persisted user data:', error);
      return null;
    }
  };
  
  retrievePersistedUserData().then((persistedUserData) => {
    store.dispatch(rehydrateUser(persistedUserData));
  });

  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
        <div className="App">
          <Router>
            <CustomeRoutes />
          </Router>
        </div>
      </PersistGate>
    </Provider>
  );
}

export default App