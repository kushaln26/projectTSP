import { useEffect, useState } from 'react';
import jwtToken from './jwtToken';
import { useNavigate } from 'react-router-dom';
import ResponseDisplay from '../components/responseMessage/ResponseMessage';


const TokenInterceptor = () => {
    const navigate = useNavigate();
    const [showFailureBottomModal, setFailureShowBottomModal] = useState<boolean>(false);
   
    const defaultErrorMessage = "Session timeout. Please log in again.";

    useEffect(() => {
        const interceptor = jwtToken.interceptors.response.use(
            (response) => response,
            (error) => {
                if (error.response?.status === 401) {
                    setFailureShowBottomModal(true);
                    navigate('/login');
                }
                return Promise.reject(error);
            }
        );

        return () => {
            jwtToken.interceptors.response.eject(interceptor);
        };
    }, [navigate]);

    // const onCloseResponseMessage=()=>{
    //     setApiResponseMessages({success:"", error:""})
    // }
    return (
        <ResponseDisplay
            className={"error"}
            responseData={defaultErrorMessage}
            showMessage={showFailureBottomModal}
            navigateTo={'/login'}
            onClose={() => { setFailureShowBottomModal(false); }}
        />
    );
};

export default TokenInterceptor;
