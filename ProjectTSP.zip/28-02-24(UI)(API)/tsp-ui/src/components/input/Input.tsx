import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { Validation } from '../../utility/models/validation/Validation';
import './input.css';
import 'react-datepicker/dist/react-datepicker.css';

interface InputProps {
  label?: string;
  name: string;
  type: string;
  value: string | number;
  feedback?: Validation;
  isRequired?: boolean,
  setFeedback?: any,
  onChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  readOnly?: boolean;
  disabled?: boolean;
  placeHolder?:string
  className?:string;
}

function Input({ label, name, type, value, onChange, feedback, setFeedback, isRequired, readOnly, placeHolder, className }: InputProps) {

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (setFeedback) {
      setFeedback({ ...feedback, isValid: false, inputFieldName: e.target.name, errorMessage: "" })
    }
    onChange(e);
  };

  return (
    <>
      <Form.Group as={Row} controlId={name} className={className} onChange={handleChange}>
        {label && <Form.Label column sm={12} className='text-start text-nowrap input_label_styles'>{label}</Form.Label>}
        <Col sm={12}>
          <Form.Control
            type={type}
            name={name}
            value={value}
            onChange={onChange}
            placeholder={label? `Enter ${label}`: placeHolder}
            isInvalid={feedback?.isValid && name === feedback.inputFieldName}
            readOnly={readOnly}
            autoComplete="off"
            className={`custom-input-style ${className}`}
          />
          {name === feedback?.inputFieldName && <Form.Control.Feedback  type='invalid'>{feedback?.errorMessage}</Form.Control.Feedback>}
        </Col>

      </Form.Group>
    </>
  );
};

export default Input;