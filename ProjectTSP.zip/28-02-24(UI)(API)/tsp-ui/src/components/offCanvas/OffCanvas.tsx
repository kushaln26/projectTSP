import { useState } from 'react';
import React, { ReactNode } from 'react'
import Button from 'react-bootstrap/Button';
import Offcanvas from 'react-bootstrap/Offcanvas';
import { Interface } from 'readline';

interface OffCanvasProperties
{
  show: boolean,
  onHide: () => void,
  placement:'start' | 'end' | 'top' | 'bottom'| undefined;
  canvasHeader?: ReactNode,
  canvasTitle?: ReactNode,
  canvasBody?: ReactNode
}

function OffCanvas({ show,onHide,placement,canvasHeader,canvasTitle,canvasBody}:OffCanvasProperties) {

  return (
    <>
      <Button variant="primary"  className="me-2">
      </Button>
      <Offcanvas show={show} onHide={onHide} placement={placement}>
        <Offcanvas.Header closeButton>
            {canvasTitle && <Offcanvas.Title>{canvasTitle}</Offcanvas.Title>}
        </Offcanvas.Header>
        <Offcanvas.Body>
            {canvasBody}
        </Offcanvas.Body> 
      </Offcanvas>
    </>
  );
}

export default OffCanvas;

