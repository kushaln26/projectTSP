import { ReactNode, useState } from 'react';
import { Offcanvas, Button } from 'react-bootstrap';

interface OffCanvasProperties
{
  show: boolean,
  onHide: () => void,
  canvasHeader?:ReactNode,
  canvasTitle?: ReactNode,
  canvasBody?: ReactNode
  headerStyle?:string
  titleStyle?:string
  bodyStyle?:string

}

function MyOffCanvas({ show, onHide,canvasHeader,canvasTitle,canvasBody,headerStyle,titleStyle, bodyStyle}:OffCanvasProperties) {
  return (
    <>
      <Offcanvas show={show} onHide={onHide} placement="end">
        <Offcanvas.Header className={`${headerStyle}`} closeButton>
          <Offcanvas.Title className={`${titleStyle}`}>{canvasTitle}</Offcanvas.Title>
        </Offcanvas.Header>
        <Offcanvas.Body className={`${bodyStyle}`}>
          {canvasBody}
        </Offcanvas.Body>
      </Offcanvas>
    </>
  );
}

export default MyOffCanvas;