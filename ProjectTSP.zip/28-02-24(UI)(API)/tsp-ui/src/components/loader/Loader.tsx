import React from 'react';
import { Spinner } from 'react-bootstrap';

interface LoaderProps {
  color?: string; 
  loading?: boolean; 
}

const Loader = ({ color = 'black', loading = true }: LoaderProps) => {
  if (!loading) {
    return null; 
  }

  return (
    <div className="loader-container">
      <Spinner/>
    </div>
  );
};

export default Loader;
