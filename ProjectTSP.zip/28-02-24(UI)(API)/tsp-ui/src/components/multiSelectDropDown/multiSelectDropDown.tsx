import { useEffect, useState } from "react";
import { Form, Row, Col } from "react-bootstrap"
import Select, { ActionMeta, MultiValue } from 'react-select';


interface MultiSelectProps {
  label: string;
  name: string;
  options: { value: string; label: string }[];
  value: { value: string; label: string }[];
  isRequired?: boolean;
  onChange: (
    selectedOptions: MultiValue<{ value: string; label: string }>,
  ) => void;
}

const MultiSelect: React.FC<MultiSelectProps> = ({ label, name, options, value, isRequired, onChange }) => {
  const [selectedOptions, setSelectedOptions] = useState<{ value: string; label: string }[]>([]);

  useEffect(() => {
    setSelectedOptions(value)
  }, [value])

  // console.log("multiselect>>>", value);

  const handleChange = (
    selectedOptions: MultiValue<{ value: string; label: string }>,
    actionMeta: ActionMeta<{ value: string; label: string }>
  ) => {
    setSelectedOptions(selectedOptions as { value: string; label: string }[]);
    onChange(selectedOptions);
  };

  return (
    <Form.Group as={Row} controlId={name} className='mb-3'>
      <Form.Label column sm={4} className='text-start text-nowrap'>{label}</Form.Label>
      <Col sm={8}>
        <Select
          isMulti
          options={options}
          value={selectedOptions}
          onChange={handleChange}
        />
      </Col>
    </Form.Group>
  )
};

export default MultiSelect;