import * as React from 'react';
import { useState } from 'react';
import { DataGrid, DataGridProps, GridColDef, GridRowIdGetter, GridValueGetterParams } from '@mui/x-data-grid';
import "./pageTable.css"


interface DataTableProps {
  rows: any[];
  columns: GridColDef[];
  getRowId?: GridRowIdGetter<any> | undefined
  handleSelectionChange?: (selectionModel: any) => void;
  setSelectedRowIds?: React.Dispatch<React.SetStateAction<string[]>>;
  checkboxSelection?: boolean
  sortingField?:string
}

export default function DataTable({ sortingField, rows, columns, getRowId, handleSelectionChange, setSelectedRowIds, checkboxSelection }: DataTableProps) {

  return (
    <div style={{ height: '80vh', width: '100%' }}>
      <DataGrid style={{ border: "none" }}
        getRowId={getRowId}
        rows={rows}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: { page: 0, pageSize: 5 },
          },
        }}
       
        // sortingOrder={['desc']}
        sortModel={[{ field: sortingField?sortingField:"", sort: 'desc' }]}
        className=''
        autoHeight={true}
        columnHeaderHeight={40}
        density='standard'
        showCellVerticalBorder={false}
        showColumnVerticalBorder={false}
        pageSizeOptions={[5, 10]}
        checkboxSelection={checkboxSelection}
        onRowSelectionModelChange={handleSelectionChange}
      />

    </div>
  );
}