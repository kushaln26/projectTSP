import React, { ReactNode } from 'react'
import BModal, { ModalProps } from "react-bootstrap/Modal"
import './model.css'


interface ModelProps {
  show: boolean,
  onHide: () => void,
  modalHeader?: ReactNode,
  modalTitle?: ReactNode,
  modalBody?: ReactNode,
  modalFooter?: ReactNode
  fullscreen?: boolean,
  modalTitleStyles?: string
  modalBodyStyles?: string
  modalFooterStyles?: string
  modalHeaderStyles?: string
  modalContainerStyles?: string
  centered?:boolean
}


function Modal({ show, onHide, modalHeader, modalTitle, modalBody, modalFooter, fullscreen,centered, modalTitleStyles, modalFooterStyles, modalBodyStyles, modalHeaderStyles, modalContainerStyles , size}: ModalProps) {
  return (
    <>
      <BModal  className='radiusChange' centered={centered} animation size={size} show={show} onHide={onHide} fullscreen={fullscreen} backdrop="static" keyboard={false}>
        <BModal.Header id="contained-modal-title-vcenter" className={`${modalHeaderStyles} ${modalContainerStyles}`} closeButton>
          {modalTitle && <BModal.Title id="contained-modal-title-vcenter" className={`${modalTitleStyles} ${modalContainerStyles}`}>{modalTitle}</BModal.Title>}
        </BModal.Header>
        {modalBody && <BModal.Body className={`${modalBodyStyles} ${modalContainerStyles}`}>{modalBody}</BModal.Body>}
        {modalFooter && <BModal.Footer className={`${modalFooterStyles} ${modalContainerStyles}`}>{modalFooter}</BModal.Footer>}
      </BModal>
    </>
  )
}

export default Modal