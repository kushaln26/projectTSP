import React, { useState } from 'react';
import Button from "../button/Button"
import Modal from './Modal';
import userApi from '../../apis/userManagement';
import { useNavigate } from 'react-router-dom';
import './DeleteConfirmation.css';

interface DeleteProps {
  showModal: boolean;
  onHide: () => void;
  emailId: string;
}

function handleDelete(emailId: string, onHide: any, setShowSuccessModal: any) {
  userApi
    .deleteUser(emailId)
    .then((res) => {
      setShowSuccessModal(true);
    })
    .catch((error) => { })
    .finally(() => {
      onHide();
    });
}

function DeleteConfirmation({ showModal, onHide, emailId }: DeleteProps) {
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const navigate = useNavigate();

  return (
    <>

      <Modal

        modalBodyStyles={"custom-body"}
        modalHeaderStyles={"custom-header"}
        modalFooterStyles={"custom-footer"}
        modalContainerStyles={"custom-container"}
        centered={true}
        show={showModal}
        onHide={onHide}
        backdrop="static"
        keyboard={true}
  
        modalBody={
          <>
            
              <div className="delete-popup">
                <h5> Are you sure, You want to delete the user?</h5><p>If you delete the user, it will not be possible to recover again to the portal.</p>
              </div>
              <>
                <div className='custom_button'>
                  <Button type='button' className='yesButton' onClick={() => handleDelete(emailId, onHide, setShowSuccessModal)}> Yes </Button>
                  <Button type="button" className='noButton' onClick={onHide}> No </Button>
                </div>
              </>
            
          </>
        }
        
      />


      <Modal
        show={showSuccessModal}
        onHide={() => setShowSuccessModal(false)}
        backdrop="static"
        keyboard={true}
        modalTitle="User Deleted Successfully"
        modalBody={<><div>The user has been deleted successfully!</div></>}
        modalFooter={
          <>
            <Button type='button' onClick={() => { setShowSuccessModal(false); navigate(0) }}> OK </Button>
          </>
        }
      />
    </>
  );
}

export default DeleteConfirmation;