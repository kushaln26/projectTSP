import React, { useState, useEffect } from 'react';
import './ResponseMessage.css';
import CloseIcon from '@mui/icons-material/Close';
import { useNavigate } from 'react-router-dom';
import { constants } from 'buffer';

interface ResponseDisplayProps {
  responseData: string;
  className: string;
  showMessage :boolean;
  navigateTo? :string;
  onClose?:()=>void;
}

const ResponseDisplay = ({ responseData, className, showMessage,navigateTo,onClose }: ResponseDisplayProps) => {
 
 
  useEffect(()=>{

    
  },[])


  const navigate = useNavigate();

  const handleClose =() =>
  {

    if(onClose){
      onClose();
    }
    if(navigateTo){
      navigate(navigateTo);
    }
    if(!responseData){
      showMessage=false
    }
  }

  return (
    <>
      {showMessage && (
        <>
        <div className='response-message'>
          <div className={className}></div>
          <div className='message-content'>
            <div className='text-size'>{responseData}</div>
            <div className="close-symbol" onClick={handleClose}>
              <CloseIcon style={{ fontSize: '24px' }} />
            </div>
          </div>
          </div>
        </>
      )}
    </>
  );
};

export default ResponseDisplay;
