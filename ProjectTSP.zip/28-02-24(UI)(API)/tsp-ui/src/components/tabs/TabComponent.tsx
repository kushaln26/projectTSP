import React, { ReactNode } from 'react';
import { Tabs, Tab, Typography, Box } from '@mui/material';
import { color } from '@mui/system';
import "./TabComponent.css";

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function CustomTabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

interface TabComponentProps {
  dashboardOf?: string
  tabs: { label: string; content: React.ReactNode }[];
}
function TabComponent({ tabs, dashboardOf }: TabComponentProps) {
  const [value, setValue] = React.useState(0);

  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  return (
    <>
    
      <div className='typography-styles d-flex justify-content-start mb-2 '>
        <Typography sx={{ color: '#444444', fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif", fontSize: 'xx-large', fontWeight: "500" }}>Dashboard</Typography>
        <Typography sx={{ color: '#444444', fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif", paddingTop: 2, marginLeft: 1, fontSize: "medium", fontWeight: "500" }} >[{dashboardOf}]</Typography>
      </div>
      <div className='table-data-style'>
        <Box sx={{ borderBottom: 1, borderColor: 'rgba(0, 0, 0, 1)' }}>
          <Tabs value={value} onChange={handleChange} aria-label="tabs">
            {tabs.map((tab, index) => (
              <Tab sx={{ color: '#444444', fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" }} key={index} label={tab.label} id={`tab-${index}`} />
            ))}
          </Tabs>
        </Box>
        {tabs.map((tab, index) => (
          <CustomTabPanel key={index} value={value} index={index}>
            {tab.content}
          </CustomTabPanel>
        ))}
      </div>
    </>

  );
};

export default TabComponent;