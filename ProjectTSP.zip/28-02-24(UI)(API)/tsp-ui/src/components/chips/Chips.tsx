import * as React from 'react';
import { styled } from '@mui/material/styles';
import Chip from '@mui/material/Chip';
import Paper from '@mui/material/Paper';
import TextField from '@mui/material/TextField';
import IconButton from '@mui/material/IconButton';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';

interface ChipData {
    key: string;
    label: string;
}

const ListItem = styled('li')(({ theme }) => ({
    margin: theme.spacing(0.5),
}));

export default function Chips() {
    const [chipData, setChipData] = React.useState<readonly ChipData[]>([
        { key: "Angular", label: 'Angular' },
        { key: 'jQuery', label: 'jQuery' },
        { key: 'Polymer', label: 'Polymer' },
        { key: 'React', label: 'React' },
        { key: 'Vue.js', label: 'Vue.js' },
    ]);
    const [newChipLabel, setNewChipLabel] = React.useState('');

    const handleDelete = (chipToDelete: ChipData) => () => {
        setChipData((chips) => chips.filter((chip) => chip.key !== chipToDelete.key));
    };

    React.useEffect(() => {
        console.log("chipData", chipData);
    }, [chipData])

    const handleEdit = (chipToEdit: ChipData) => () => {
        const newLabel = prompt('Enter new label:', chipToEdit.label);
        if (newLabel) {
            setChipData((chips) =>
                chips.map((chip) =>
                    chip.key === chipToEdit.key ? { ...chip, label: newLabel } : chip
                )
            );
        }
    };

    const handleAddChip = () => {
        if (newChipLabel.trim() !== '') {
            setChipData((chips) => [
                ...chips,
                { key: newChipLabel.trim(), label: newChipLabel.trim() }
            ]);
            setNewChipLabel('');
        }
    };

    return (
        <Paper
            sx={{
                display: 'flex',
                justifyContent: 'center',
                flexWrap: 'wrap',
                listStyle: 'none',
                p: 0.5,
                m: 0,
            }}
            component="ul"
        >

            {chipData.map((data) => (
                <ListItem key={data.key}>
                    <Chip
                        label={data.label}
                        onDelete={handleDelete(data)}
                        onClick={handleEdit(data)}
                    />
                </ListItem>
            ))}
            <ListItem>
                <TextField
                    style={{ borderColor: "none" }}
                    value={newChipLabel}
                    onChange={(e) => setNewChipLabel(e.target.value)}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                            handleAddChip();
                        }
                    }}
                />
            </ListItem>
        </Paper>
    );
}
