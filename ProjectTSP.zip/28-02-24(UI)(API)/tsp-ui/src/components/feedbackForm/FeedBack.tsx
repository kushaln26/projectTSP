import React from 'react';
import './feedback.css';



interface FeedbackProps{
    MSFormLink:string
}

function Feedback({MSFormLink}:FeedbackProps) {
    return (
        <div className="d-flex justify-content-center feedback-container">
          <div className="  feedback-text-container">
                <p className="feedback-text">
                    Please <a href={MSFormLink} target="_blank" rel="noopener noreferrer">click here</a> to download MS-Form.
                </p>
            </div>
        </div>
    );
}

export default Feedback;
