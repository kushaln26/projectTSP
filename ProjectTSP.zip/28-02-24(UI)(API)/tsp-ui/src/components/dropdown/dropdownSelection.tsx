import React from 'react';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { Validation } from '../../utility/models/validation/Validation';

interface DropdownProps {
    children?: React.ReactNode;
    options: Array<{ label: string | number; value: string }>;
    name?: string,
    value?: {},
    label: string,
    isRequired?: boolean,
    onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void,
    feedback?:Validation,
    setFeedback?:any
    className?:string;
    labelStyles?:string
    inputStyles?:string
    optionStyles?:string
}

function dropdownSelection({ options, onChange, name, value, label, isRequired, feedback, setFeedback,className,labelStyles, inputStyles, optionStyles }: DropdownProps) {

    return (
        <>
            <Form.Group as={Row} controlId={name} className={`${className}`}>
                <Form.Label className={`text-start text-nowrap input_label_styles ${labelStyles}`}>{label}</Form.Label>
                <Col >
                    <Form.Select isInvalid={feedback?.isValid && name===feedback.inputFieldName}  name={name} value={value !== undefined ? String(value) : ''} aria-label="Default select example" onChange={onChange} className={`custom-input-style ${inputStyles}`}>
                        <option value="" className={`${optionStyles}`} disabled>Choose </option>
                        {options.map(option => (
                            <option key={option.value} value={option.value} className={`${optionStyles}`}>{option.label}</option>
                        ))}
                    </Form.Select>
                    {name === feedback?.inputFieldName && <Form.Control.Feedback type='invalid'>{feedback?.errorMessage}</Form.Control.Feedback>}
                </Col>
            </Form.Group>
        </>
    )
}

export default dropdownSelection