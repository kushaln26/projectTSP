import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
// import 'react-datepicker/dist/react-datepicker.css';
 import './DateAndTimePicker.css';
import convertStringToDate from '../../utility/DateConversions/StringToDateConversion';

interface DateTimeInputProps {
  selected: Date ;
  onChange: (date: Date) => void;
  dateFormat?: string;
  timeFormat?:string;
  timeIntervals?:number;
  placeholderText?: string;
  disabled?:boolean;
  minDate?:Date;
  maxDate?:Date;
  disableTimeSelection?:boolean;
  
}

const DateTimePicker: React.FC<DateTimeInputProps> = ({ selected, onChange, dateFormat,timeFormat,timeIntervals, placeholderText,disabled,minDate, maxDate,disableTimeSelection }) => {
  // const selectedDate = convertStringToDate(selected);
  const [selectedDateTime, setSelectedDateTime] = useState<Date | null >(selected);

  const handleDateChange = (date: Date) => {
    setSelectedDateTime(date);
    onChange(date);
  };

  return (
    
      <DatePicker
        selected={selectedDateTime}
        onChange={handleDateChange}
        timeFormat={timeFormat}
        timeIntervals={timeIntervals}
        dateFormat={dateFormat}
        timeCaption="Time"
        placeholderText={placeholderText}
        disabled={disabled}
        minDate={minDate}
        maxDate={maxDate}
        showTimeSelect={!disableTimeSelection}
      />
   
  );
};

export default DateTimePicker;
