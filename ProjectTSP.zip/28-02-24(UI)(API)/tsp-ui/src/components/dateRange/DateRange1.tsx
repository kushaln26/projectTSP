import React, { useEffect, useState } from 'react';
// import Button from '../../components/button/Button';
import DropdownSelection from '../dropdown/dropdownSelection';
import Form from '../form/Form';
import FormInput from '../input/Input';
import { staticDataFetch } from '../../apis/staticDataFetch';
import './DateRange.css';
import { Button } from 'react-bootstrap';
import { Formik } from 'formik';
import * as yup from 'yup';
import { ArchiveRequest } from '../../utility/models/archive/ArchiveRequest';
import { MasterDataResponse } from '../../utility/models/masterData/MasterDataResponse';
import { StaticData } from '../../utility/models/staticData/staticData';
import { log } from 'console';
import { Validation } from '../../utility/models/validation/Validation';

interface dateRangeProps {
    includeDropdown: boolean,
    formData: any;
    setFormData: React.Dispatch<React.SetStateAction<any>>;
    handleSubmission: (formData: any) => void;
    feedbackProp?:Validation;
}

function DateRange1({ includeDropdown, handleSubmission, formData, setFormData}: dateRangeProps) {
    const [bussinessUnits, setBussinessUnits] = useState<StaticData>({ userGroups: [], bussinessUnits: [] })
    const [apiErrors, setApiError] = useState<string>("");

    useEffect(() => {
        dropdownSelectionItems();
    }, [])

    const transformedArray = (data: Array<any>) => {
        return data.map(item => ({
            label: item,
            value: item
        }))
    }

    const setData = async (promise: any) => {
        const response = await promise;
        const res: MasterDataResponse = await response.data.payLoad;
        const bussinessUnits = res.businessUnits;
        setBussinessUnits((prevDropDownData) => ({ ...prevDropDownData, bussinessUnits: transformedArray(bussinessUnits) }))
    }


    const dropdownSelectionItems = async () => {
        try {
            const promise = await staticDataFetch.getMaterData()
            await setData(promise);
        } catch (error: any) {
            setApiError(error?.message)
            console.log("error", error);
            
        }
    }

   
    const handleOnChange = (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({
            ...formData,
            [event.target.name]: event.target.value,
        });
        console.log(event.target.value);
    }

    


    return (
        <>
            <div>

                <div className="date-range-container">
                    <div className="date-range-input-container">
                        <div className='date-input'>
                            <FormInput
                                className='dateRangeInput dateChild'
                                label="From Date"
                                type="date"
                                value={formData?.localStartDate}
                                onChange={handleOnChange}
                                name='localStartDate'
                            />
                            
                            <FormInput
                                className='dateRangeInput dateChild'
                                label="To Date"
                                type="date"
                                value={formData?.localEndDate}
                                onChange={handleOnChange}
                                name='localEndDate'
                            />
                        </div>
                        {includeDropdown &&
                            <DropdownSelection
                                className='dateRangeInput dateChild bu'
                                label="BU"
                                name="departmentUnit"
                                value={formData?.departmentUnit}
                                options={bussinessUnits.bussinessUnits}
                                onChange={handleOnChange}
                            />
                        }
                    </div>
                    <Button className='searchButton' type='button' onClick={handleSubmission}>Search</Button>
                </div>
                {apiErrors && <p>{apiErrors}</p>}
            </div>
        </>

    );
}

export default DateRange1;
