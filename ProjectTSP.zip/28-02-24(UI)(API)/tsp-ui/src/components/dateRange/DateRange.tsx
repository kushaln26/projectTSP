import React, { useEffect, useState } from 'react';
// import Button from '../../components/button/Button';
import DropdownSelection from '../../components/dropdown/dropdownSelection';
import Form from '../../components/form/Form';
import FormInput from '../../components/input/Input';
import { staticDataFetch } from '../../apis/staticDataFetch';
import './DateRange.css'; 
import { Button } from 'react-bootstrap';
import { Formik } from 'formik';
import * as yup from 'yup';
import { ArchiveRequest } from '../../utility/models/archive/ArchiveRequest';
import DateTimePicker from '../DateAndTimePicker/DateAndTimePicker';
import { Validation } from '../../utility/models/validation/Validation';
import { MasterDataResponse } from '../../utility/models/masterData/MasterDataResponse';
import { StaticData } from '../../utility/models/staticData/staticData';

interface dateRangeProps
{
    includeDropdown: boolean,
    formData: any;
    setFormData: React.Dispatch<React.SetStateAction<any>>; 
    handleSubmission: (formData: any) => void;
    feedback:Validation;
    setFeedback:React.Dispatch<React.SetStateAction<any>>; 
}

function DateRange({includeDropdown,handleSubmission,formData, setFormData,feedback,setFeedback}:dateRangeProps) {

  
    const [bussinessUnits, setBussinessUnits] = useState<StaticData>({ userGroups: [], bussinessUnits: [] })
    const [apiErrors, setApiError] = useState<string>("");

   
    useEffect(() => {
        dropdownSelectionItems();
    }, [])

    const transformedArray = (data: Array<any>) => {
        return data.map(item => ({
            label: item,
            value: item
        }))
    }

    const setData = async (promise: any) => {
        const response = await promise;
        const res: MasterDataResponse = await response.data.payLoad;
        const bussinessUnits = res.businessUnits;
        setBussinessUnits((prevDropDownData) => ({ ...prevDropDownData, bussinessUnits: transformedArray(bussinessUnits) }))
    }


    const dropdownSelectionItems = async () => {
       
        try {
            const promise = await staticDataFetch.getMaterData()
            await setData(promise);
        } catch (error: any) {
            setApiError(error?.message)
            console.log("error", error);
            
        }
    }

    const handleOnChange = (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData(null)
        setFormData({
            ...formData,
            [event.target.name]: event.target.value,
        });
    }

    const handleStartDateChange = (event:React.ChangeEvent<HTMLInputElement>)=>
    {
        const { name, value } = event.target;
        setFormData((prevFormData:any) => ({
            ...prevFormData,
            localStartDate: value,
        }));
    }

    const handleEndDateChange = (event:React.ChangeEvent<HTMLInputElement>)=>
    {
        const { name, value } = event.target;
        setFormData((prevFormData:any) => ({
            ...prevFormData,
            localEndDate: value,
        }));
    }

    const handleDropdownChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
        setFormData({ ...formData, [event.target.name]: event.target.value });
    };


    return (
        <>
        <div>
           
            <Form onSubmit={handleSubmission} formData={formData} setFormData={setFormData}>
    
                <div className="date-range-container">
                    <div className="date-range-input-container">
                        <div className='date-input'> 
                            <FormInput
                                feedback={feedback} 
                                setFeedback={setFeedback}
                                className='dateRangeInput dateChild'
                                label="From Date"
                                type="date"
                                value={formData.localStartDate}
                                onChange={handleOnChange}
                                name={'localStartDate'}
                            />
                            <FormInput
                                feedback={feedback} 
                                setFeedback={setFeedback}
                                className='dateRangeInput dateChild'
                                label="To Date"
                                type="date"
                                value={formData.localEndDate}
                                onChange={handleOnChange}
                                name={'localEndDate'}
                            />
                        </div> 
                       {includeDropdown && 
                        <DropdownSelection
                            className='dateRangeInput dateChild bu'
                            label="BU"
                            name="departmentUnit"
                            value={formData.departmentUnit}
                            options={bussinessUnits.bussinessUnits}
                            onChange={handleOnChange}
                        />
                         }  
                    </div>
                    <Button className='searchButton' type='submit'>Search</Button>   
                </div>
            </Form>
                {apiErrors && <p>{apiErrors}</p>}
            </div>
        </>

    );
}

export default DateRange;
