import React, { useState } from "react";
import { Button, View } from "react-native";
import DateTimePickerModal from "react-native-modal-datetime-picker";

const MyDateTimePickerModal = () => {
  const [isDateTimePickerVisible, setDateTimePickerVisibility] = useState(false);
  const [selectedDateTime, setSelectedDateTime] = useState(new Date());

  const showDateTimePicker = () => {
    setDateTimePickerVisibility(true);
  };

  const hideDateTimePicker = () => {
    setDateTimePickerVisibility(false);
  };

  const handleConfirm = (date: React.SetStateAction<Date>) => {
    console.warn("A date has been picked: ", date);
    setSelectedDateTime(date);
    hideDateTimePicker();
  };

  return (
    <>
      <View>
        <Button title="Show Date and Time Picker" onPress={showDateTimePicker} />
        <DateTimePickerModal
          isVisible={isDateTimePickerVisible}
          mode="datetime" 
          date={selectedDateTime}
          onConfirm={handleConfirm}
          onCancel={hideDateTimePicker}
        />
      </View>
    </>
  );
};

export default MyDateTimePickerModal;
