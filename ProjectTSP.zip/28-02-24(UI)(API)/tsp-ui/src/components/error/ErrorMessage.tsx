import React from 'react'

interface ErrorProps {
    message: string;
    success?:boolean
}

function ErrorMessage({message, success}: ErrorProps) {
    return (
        <>
            <div className={success?'text-success':"text-danger"}>
                {message}
            </div>
        </>
    )
}

export default ErrorMessage