package com.maveric.tsp.UserService.utils;

public class Constants {
    public static final String PROFILE_STATUS="AVAILABLE";
}
