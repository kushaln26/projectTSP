package com.maveric.tsp.mediaService.exceptions;

public class MediaNotFoundException extends Exception{

    /**
     *
     * @param message
     */
    public MediaNotFoundException(String message){
        super(message);
    }

}
