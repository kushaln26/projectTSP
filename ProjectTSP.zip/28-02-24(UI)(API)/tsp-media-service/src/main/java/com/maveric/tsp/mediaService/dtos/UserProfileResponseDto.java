package com.maveric.tsp.mediaService.dtos;



import lombok.Data;

import java.io.Serializable;


@Data
public class UserProfileResponseDto implements Serializable {

    private String emailId;

}
