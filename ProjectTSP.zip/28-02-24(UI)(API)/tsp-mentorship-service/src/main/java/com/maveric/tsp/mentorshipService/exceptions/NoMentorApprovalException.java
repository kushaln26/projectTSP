package com.maveric.tsp.mentorshipService.exceptions;

public class NoMentorApprovalException extends RuntimeException{
    public NoMentorApprovalException(String msg){
        super(msg);
    }
}
