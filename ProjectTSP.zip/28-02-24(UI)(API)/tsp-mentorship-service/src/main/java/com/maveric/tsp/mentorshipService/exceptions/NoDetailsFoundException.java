package com.maveric.tsp.mentorshipService.exceptions;

public class NoDetailsFoundException extends RuntimeException{
    public NoDetailsFoundException(String msg){
        super(msg);
    }
}
