package com.maveric.tsp.mentorshipService.entities;

public enum SessionStatus {

    REQUESTED,

    SCHEDULED,

    COMPLETED,

    REJECTED,

    APPROVED

}
