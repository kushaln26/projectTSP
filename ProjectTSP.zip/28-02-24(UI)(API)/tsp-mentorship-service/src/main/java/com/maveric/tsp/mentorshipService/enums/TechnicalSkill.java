package com.maveric.tsp.mentorshipService.enums;


public enum TechnicalSkill {

    JAVA, REACT,SPRINGBOOT, JAVASCRIPT, MICROSERVICES;

}
