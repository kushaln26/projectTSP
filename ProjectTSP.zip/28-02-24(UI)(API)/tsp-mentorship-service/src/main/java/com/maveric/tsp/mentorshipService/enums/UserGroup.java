package com.maveric.tsp.mentorshipService.enums;

public enum UserGroup {
    ADMIN, MENTOR, MENTEE, MANAGER,
}
