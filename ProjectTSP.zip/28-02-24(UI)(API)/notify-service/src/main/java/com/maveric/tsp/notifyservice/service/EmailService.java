package com.maveric.tsp.notifyservice.service;

public interface EmailService {

}
