package com.maveric.tsp.reportService.Controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.maveric.tsp.reportService.controller.ReportController;
import com.maveric.tsp.reportService.dtos.ReportRequestDto;
import com.maveric.tsp.reportService.dtos.ResponseDto;
import com.maveric.tsp.reportService.dtos.User;
import com.maveric.tsp.reportService.service.Impl.ReportServiceImpl;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;


import static org.mockito.Mockito.verify;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@Slf4j
@WebMvcTest(ReportController.class)
class ReportControllerTest {


    @Autowired
    private MockMvc mvc;

    @MockBean
    private ReportServiceImpl reportService;

    private static ObjectMapper objectMapper=new ObjectMapper();

    private static ReportRequestDto reportRequestDto;
    private static User user;


    private static final String BASE_URI="/report";

    @BeforeAll
    public static void setUp(){
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
        objectMapper.registerModule(new JavaTimeModule());
        try {
             reportRequestDto=objectMapper.readValue(new File("src/test/resources/ReportRequest.json"),ReportRequestDto.class);
        } catch (IOException e) {
            log.info("Json Parsing Exception:"+e.getMessage());
        }
    }

    @Test
    void test_fetchAllUsers() throws Exception {
        String uri = BASE_URI+"/fetchAllUsers";
        ArrayList<User> userList = new ArrayList<>();
        userList.add(user);
        when(reportService.getDataDownloaded(Mockito.any(ReportRequestDto.class))).thenReturn(userList);
        ResponseDto<ArrayList<User>> responseDto = new ResponseDto<>();
        responseDto.setCode(200);
        responseDto.setMessage("Users Data fetched");
        responseDto.setStatus("200 OK");
        responseDto.setPayLoad(userList);
                mvc.perform(post(uri)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(objectMapper.writeValueAsString(reportRequestDto)))
                        .andExpect(status().isOk())
                        .andExpect(content().json(objectMapper.writeValueAsString(responseDto), true));
        verify(reportService).getDataDownloaded(reportRequestDto);
    }
    }

