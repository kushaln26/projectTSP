import {
    CREATE_CUSTOMER_URL
  } from "../../configBase";
 
  export const onCreateCustomer = (callback, requestParam) => {
    onCreateCustomer(CREATE_CUSTOMER_URL, callback, requestParam);
  };