package com.maveric.cms_case_details.constants;

public class Constants{
    public static String caseNotFoundMsg = "Case details not found!";
}