package com.maveric.cms_case_details.dto.request;

public class GetCaseCategoriesRequest {
    private String caseType;
}
