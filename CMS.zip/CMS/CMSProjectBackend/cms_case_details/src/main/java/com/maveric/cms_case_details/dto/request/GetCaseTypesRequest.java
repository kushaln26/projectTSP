package com.maveric.cms_case_details.dto.request;

public class GetCaseTypesRequest {
}
