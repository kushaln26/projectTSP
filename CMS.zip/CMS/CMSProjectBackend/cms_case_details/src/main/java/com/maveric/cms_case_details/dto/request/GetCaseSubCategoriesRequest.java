package com.maveric.cms_case_details.dto.request;

public class GetCaseSubCategoriesRequest {
    private String caseType;
    private String category;
}
