package com.maveric.cms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CmsGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(CmsGatewayApplication.class, args);
	}

}
