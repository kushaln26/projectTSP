package com.maveric.cms.exception;

public class InvalidPwdException extends RuntimeException{

    public InvalidPwdException(String message) {
        super(message);
    }
}
