package com.maveric.cms.exception;


public class PasswordIncorectException extends RuntimeException{

    public PasswordIncorectException(String message) {
        super(message);
    }
}
