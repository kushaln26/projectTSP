package com.maveric.cms.exception;

public class AgentIsPresentException extends RuntimeException{

    public AgentIsPresentException(String message) {
        super(message);
    }
}
