package com.maveric.cms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class CmsAgentApplicationTest {
    @Test
    void contextLoads() {
    }
}
