package com.maveric.cms_audit_event.exception;

public class AuditEventsNotFoundexception extends RuntimeException{
    public AuditEventsNotFoundexception(String message) {
        super(message);
    }
}
