package com.maveric.cms_agent_note;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmsAgentNoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
