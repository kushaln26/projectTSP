package com.maveric.cms_agent_note.exception;

public class NotesNotFoundexception extends RuntimeException{
    public NotesNotFoundexception(String message) {
        super(message);
    }
}
