package com.maveric.cms_agent_note.exception;

public class CaseNotFound extends RuntimeException{
    public CaseNotFound(String message) {
        super(message);
    }
}
