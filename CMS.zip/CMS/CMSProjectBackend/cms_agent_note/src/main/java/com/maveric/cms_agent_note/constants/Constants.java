package com.maveric.cms_agent_note.constants;

//New password and confirm password is not matching !
// Password must contain one special character, one lower case one upper case character!
//Sorry your details are not present in the database! please register!
//User not found
//User name invalid
//Password must contain one special character, one lower case one upper case character!